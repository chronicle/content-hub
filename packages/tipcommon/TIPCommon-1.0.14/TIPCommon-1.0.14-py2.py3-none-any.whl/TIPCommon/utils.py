
import sys
import inspect

from .consts import (
    _CAMEL_TO_SNAKE_PATTERN1,
    _CAMEL_TO_SNAKE_PATTERN2,
    SIEM_ID_ATTR_KEY
)


def is_test_run(sys_argv):
    """
    Return a boolean value that indicates whether the connector's execution state.

    Args:
        sys_argv (_type_): _description_

    Returns:
        _type_: _description_
    """
    return not (len(sys_argv) < 2 or sys_argv[1] == 'True')


def clean_result(value):
    """
    Strip the value from unnecessary spaces before or after the value.

    Args:
        value (str): The value to clean.

    Returns:
        str: A cleaned version of the original value.

    """
    try:
        return value.strip()
    except Exception:
        return value


def is_python_37():
    """
    Check if the python version of the system is 3.7 or above.

    Args:
        None.

    Returns:
        bool: True if the current python version is at least 3.7.

    """
    return sys.version_info >= (3, 7)


def platform_supports_db(siemplify):
    """
    Check if the platform supports database usage.

    Args:
        siemplify (object): The siemplify SDK object.

    Returns:
        bool: True if the siemplify SDK object has an attribute called "set_connector_context_property".

    """

    if hasattr(siemplify, 'set_connector_context_property'):
        return True
    return False


def is_empty_string_or_none(data):
    """
    Check if the data is an 'empty string' or 'None'.

    Args:
        data (str): The data to check.

    Returns:
        bool: True if the supplied data is 'None', or if it only contains an empty string "".

    """

    if data is None or data == "":
        return True
    return False


def cast_keys_to_int(data):
    """
    Cast the keys of a dictionary to integers.

    Args:
        data (dict): The data whose keys will be cast to ints.

    Returns:
        dict: A new dict with its keys as ints.

    """
    return {int(k): v for k, v in data.items()}


def none_to_default_value(value_to_check, value_to_return_if_none):
    """
    Check if the current value is None. If it is, replace it with another value. If not, return the original value.

    Args:
        value_to_check (dict/list/str): The value to check.
        value_to_return_if_none (dict/list/str): The value to return if `value_to_check` is None.

    Returns:
        dict/list/str: The original value of `value_to_check` if it is not None, or `value_to_return_if_none` if it is None.

    """
    if value_to_check is None:
        value_to_check = value_to_return_if_none
    return value_to_check


def camel_to_snake_case(string):
    """
    Convert a camel case string to snake case
    :param string: (str) the string to convert
    :return: (str) the converted string
    """
    string = string.replace(' ', '')
    string = _CAMEL_TO_SNAKE_PATTERN1.sub(r'\1_\2', string)
    return _CAMEL_TO_SNAKE_PATTERN2.sub(r'\1_\2', string).lower()


def is_overflowed(siemplify, alert_info, is_test_run):
    """
    Checks if overflowed.
    
    Args:
        siemplify: (obj) An instance of the SDK `SiemplifyConnectorExecution` class
        alert_info: (AlertInfo)
        is_test_run: (bool) Whether test run or not.
    
    Returns:
        `True` if the alert is overflowed, `False` otherwise.
    """
    params = {
        'environment': alert_info.environment,
        'alert_identifier': alert_info.ticket_id,
        'alert_name': alert_info.rule_generator,
        'product': alert_info.device_product
    }

    #   Check if 'siem_alert_id' is a valid argument in the SDK overflow method
    #   un-coupled from SDK version


    try:
        method_args = get_function_arg_names(siemplify.is_overflowed_alert)
        if SIEM_ID_ATTR_KEY in method_args:
            params[SIEM_ID_ATTR_KEY] = getattr(alert_info, SIEM_ID_ATTR_KEY, None)

    except Exception as e:
        siemplify.LOGGER.error(
            'Error {e}. {arg_} argument will not be used in Overflow check for alert {alert_id}.'.format(
                arg_=SIEM_ID_ATTR_KEY, e=e, alert_id=alert_info.ticket_id)
        )

    try:
        return siemplify.is_overflowed_alert(**params)

    except Exception as err:
        siemplify.LOGGER.error(
            'Error validation connector overflow, ERROR: {}'.format(err)
        )
        siemplify.LOGGER.exception(err)
        if is_test_run:
            raise

    return False

def get_function_arg_names(func):
    """Retrieves all of the argument names of a specific function.

    Args:
        func: (Callable) The function or method to analyze

    Returns:
        list: All of the argument keys defined in the given fucntion
    """
    if is_python_37():
        method_args = inspect.getfullargspec(func)[0]
    else:   
        # Python 2.7 as it is the only other python version supported in 
        # SOAR integrations virtual envs. 

        method_args = inspect.getargspec(func)[0]
    return method_args
