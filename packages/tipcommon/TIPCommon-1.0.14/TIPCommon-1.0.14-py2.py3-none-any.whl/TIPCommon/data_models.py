"""
data_models
===========

This module contains data classes for representing: 
- Alerts
- Variable containers 
- General parameters 
- Connector parameters.

"""

from enum import Enum


class BaseAlert:
    """Represents a base alert. It has the following properties:

    Attributes:
        raw_data: The raw data for the alert.
        alert_id: The ID of the alert.

    The `to_json` method converts the alert to JSON format as returned from 
    `json.loads()`.

    Example:
        >>> from data_models import BaseAlert
        >>> alert = BaseAlert({'foo': 'bar'}, 100)
        >>> alert.raw_data
        {'foo': 'bar'}
        >>> alert.alert_id
        100
        >>> alert.to_json()
        {'foo': 'bar'}
    """


    def __init__(self, raw_data, alert_id):
        self.raw_data = raw_data
        self.alert_id = alert_id

    def to_json(self):
        return self.raw_data


class Container:
    """Represents a container for variables. 

    Examples:
        >>> from data_models import Container
        >>> container = Container()
        >>> container.one = 1
        >>> container.one
        1
    """

    def __init__(self):
        self._params = {}

    def __get__(self, ins, instype=None):
        return self._params.get(ins)

    def __set__(self, ins, value):
        self._params[ins] = value


class Parameter:
    """A Parent class representing a parameter. 
    
    It has the following properties:

    raw_data: The raw data for the parameter.

    Example:
        >>> from data_models import Parameter
        >>> p = Parameter({'foo': 'bar'})
        >>> print(p)
        Parameter(raw_data={'foo': 'bar'})
    """

    def __init__(self, raw_param):
        self._raw_data = raw_param

    @property
    def raw_data(self):
        return self._raw_data


class ConnectorParameter(Parameter):
    """Represents a connector parameter. It has the following properties:

    name: The name of the parameter.
    value: The value of the parameter.
    type: The type of the parameter (according to `ConnectorParamTypes`).
    mode: The mode of the parameter.
    is_mandatory: Whether the parameter is mandatory.

    Example:
        >>> from data_models import ConnectorParameter, ConnectorParamTypes
        >>> p = ConnectorParameter({
            'param_name': 'api_root', 
            'type': ConnectorParamTypes.STRING, 
            'param_value': 'http://foo.bar',
            'is_mandatory': True,
            'mode': 0
            })
        >>> print(p)
        ConnectorParameter(name='api_root', value='http://foo.bar', type=2, mode=0, is_mandatory=True)
        
    """

    def __init__(self, raw_param):
        super().__init__(raw_param)
        self._name = raw_param.get('param_name', '')
        self._value = raw_param.get('param_value', '')
        self._type = ConnectorParamTypes(raw_param.get('type', -1))
        self._mode = raw_param.get('mode', '')
        self._is_mandatory = raw_param.get('is_mandatory', '')

    @property
    def name(self):
        return self._name

    @property
    def value(self):
        return self._value

    @property
    def type(self):
        return self._type

    @property
    def mode(self):
        return self._mode

    @property
    def is_mandatory(self):
        return self._is_mandatory


class ConnectorParamTypes(Enum):
    """Represents the types of connector parameters. The possible values are:

    * BOOLEAN: A Boolean parameter.
    * INTEGER: An integer parameter.
    * STRING: A string parameter.
    * PASSWORD: A password parameter.
    * IP: An IP address parameter.
    * HOST: A host name parameter.
    * URL: A URL parameter.
    * DOMAIN: A domain name parameter.
    * EMAIL: An email address parameter.
    * NULL: Invalid parameter type.
    """

    BOOLEAN = 0
    INTEGER = 1
    STRING = 2
    PASSWORD = 3
    IP = 4
    HOST = 5
    URL = 6
    DOMAIN = 7
    EMAIL = 8
    NULL = -1
