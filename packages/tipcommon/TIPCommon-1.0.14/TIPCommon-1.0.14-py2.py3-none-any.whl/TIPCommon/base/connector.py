from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import timedelta

from EnvironmentCommon import EnvironmentHandle, GetEnvironmentCommonFactory
from SiemplifyConnectors import SiemplifyConnectorExecution
from SiemplifyConnectorsDataModel import AlertInfo
from SiemplifyUtils import from_unix_time, output_handler, unix_now, utc_now

from .utils import nativemethod, is_native
from ..consts import (
    NONE_VALS,
    TIMEOUT_THRESHOLD,
    UNIX_FORMAT,
    DATETIME_FORMAT,
)
from ..data_models import BaseAlert, ConnectorParamTypes, Container
from ..exceptions import ConnectorSetupError
from ..extraction import extract_connector_param, get_connector_detailed_params
from ..smp_time import get_last_success_time, is_approaching_timeout, save_timestamp
from ..utils import camel_to_snake_case, is_overflowed, platform_supports_db
from ..validation import ParameterValidator


class Connector(ABC):
    """A Unified Generic infrastructure implementation for Chroniclal SOAR 
    (Formerly 'Siemplify') Connector developement.

    The ``Connector`` base class provides template abstract methods to override 
    in the inheritted connector classes, generic properties, and genreal flows 
    as methods that will be executed when calling the connector's `start` method.

    Note:
        THIS CLASS IS NOT SUPPORTED WITH PYTHON 2!

    Args:
        script_name (str): The name of the script that is using this connector.
        is_test_run (bool): Whether this is a test run or not.

    Attributes:
        siemplify (SiemplifyConnectorExecution): The Siemplify connector execution object.
        script_name (str): The name of the script that is using this connector.
        connector_start_time (int): The time at which the connector started.
        logger (str): The logger for this connector.
        is_test_run (bool): Whether this is a test run or not.
        params (Container): The parameters container for this connector.
        context (Container): The context data container for this connector.
        vars (Container): The runtime variables container used by the connector.
        env_common (str): The environment common handle object.
        error_msg (str): The error message the connector will display in case of a generic failure.

    Abstract Methods:
        - validate_params(self): Validate the parameters for this connector.
        - read_context_data(self): Read the context data for this connector.
        - write_context_data(self, processed_alerts): Write the context data for this connector.
        - init_managers(self): Initialize the managers for this connector.
        - store_alert_in_cache(self, alert): Store the alert in the cache.
        - get_alerts(self): Get the alerts from the manager.
        - create_alert_info(self, alert): Create an alert info object.

    Additional Methods:
        ** These are methods that are called during the connector execution and affect the alerts processing phase, but are not mandatory to override. **

        - get_last_success_time(self, max_backwords_param_name, metric, padding_period_param_name, padding_period_metric, time_format, print_value, microtime): Calculates the connector last successful timestamp.
        - max_alerts_processed(self, processed_alerts): Return True if reached the maximum alerts to process limit in the connector execution.
        - pass_filters(self, alert): Boolean method to check if alert passes connector filters.
        - filter_alerts(self, alerts): Filter alerts from manager and return list of filtered alerts.
        - process_alert(self, alert): Additional alert processing (like events enrichment).

    Examples::

            import time
            import TIPCommon
            from TIPCommon.base import Connector
            from TIPCommon.data_models import BaseAlert
            from SiemplifyConnectorsDataModel import AlertInfo
 
            class FakeAlert(BaseAlert):
                def __init__(self, raw_data):
                    super().__init__(raw_data, raw_data.get('Id'))
                    start_time = raw_data.get('StartTime')
                    end_time = raw_data.get('EndTime')

                    
            class FakeConnector(Connector):
                def validate_params(self):
                    self.params.user_email = self.param_validator.validate_email(
                        'User Email', 
                        self.params.user_email
                    )
                    
                def read_context_data(self):
                    self.context.ids = TIPCommon.read_ids(self.siemplify)

                def init_managers(self):
                    self.manager = FakeManager(self.params.user_email)

                def get_alerts(self):
                    raw_alerts = self.manager.get_alerts()
                    parsed_alerts = []
                    for alert in raw_alerts:
                        parsed_alerts.append(FakeAlert(alert))
                    return parsed_alerts

                def store_alert_in_cache(self, alert):
                    self.context.ids.append(alert.alert_id)

                def create_alert_info(self, alert):
                    alert_info = AlertInfo()
                    alert_info.ticket_id = alert.alert_id
                    alert_info.display_id = alert.alert_id
                    alert_info.name = "Fake Alert"
                    alert_info.device_vendor = "Fake Device Vendor"
                    alert_info.device_product = "Fake Device Product"
                    alert_info.start_time = alert.start_time
                    alert_info.end_time = alert.end_time
                    alert_info.environment = self.env_common.get_environment(
                        TIPCommon.dict_to_flat(alert.to_json())
                    )
                    return alert_info

                def write_context_data(self):
                    TIPCommon.write_ids(self.siemplify, self.context.ids)

                def get_last_success_time():
                    return super().get_last_success_time(
                        max_backwards_param_name="max_days_backwards",
                        metric="days",
                        padding_period_param_name="padding_period",
                        padding_period_metric="hours"
                    )

            if __name__ == '__main__':
                script_name = "MyFakeConnector"
                is_test = TIPCommon.is_test_run(sys.argv)
                connector = FakeConnector(script_name, is_test)
                connector.start()
                  
    """

    def __init__(self, script_name, is_test_run):
        self._siemplify = SiemplifyConnectorExecution()
        self._siemplify.script_name = script_name
        self._script_name = script_name
        self._connector_start_time = unix_now()
        self._logger = self._siemplify.LOGGER
        self._is_test_run = is_test_run
        self.detailed_params = get_connector_detailed_params(self._siemplify)
        self.param_validator = ParameterValidator(self._siemplify)
        self._params = Container()
        self._context = Container()
        self._vars = Container()
        self._error_msg = "Got exception on main handler."
        self._env_common = None
        self._perspectives()

    ###################### Connector Properties ######################
    @property
    def siemplify(self) -> SiemplifyConnectorExecution:
        return self._siemplify

    @property
    def script_name(self) -> str:
        return self._script_name

    @property
    def connector_start_time(self) -> int:
        return self._connector_start_time

    @property
    def logger(self) -> str:
        return self._logger

    @property
    def is_test_run(self) -> bool:
        return self._is_test_run

    @property
    def params(self) -> Container:
        return self._params

    @property
    def context(self) -> Container:
        return self._context

    @property
    def vars(self) -> Container:
        return self._vars

    @property
    def env_common(self) -> str:
        if not self._env_common:
            self.load_env_common()
        return self._env_common

    @property
    def error_msg(self) -> str:
        return self._error_msg

    @error_msg.setter
    def error_msg(self, val: str) -> None:
        self._error_msg = val

    ###################### Abstract Methods ######################

    @abstractmethod
    def validate_params(self) -> None:
        """
    Validate connector parameters.

    Note:
        Use validation `self.param_validator` methods for easier
        one-line validation for connector parameters. 
    
    Examples::

        Class MyConnector(Connector)

            # method override
            def validate_params(self):
                self.params.user_email = self.param_validator.validate_email(
                    param_name='User Email', 
                    email=self.params.user_email
                )

    Raises:
        ConnectorSetupError: If any of the parameters are invalid.
    """

    @abstractmethod
    def init_managers(self) -> None:
        """Create manager instance objects.

        Examples::

            Class MyConnector(Connector)

                # method override
                def init_managers(self):
                    self.params.manager = MyManager(...)

        Raises:
            ConnectorSetupError: If there is an error creating the manager instance objects.
        """

    @abstractmethod
    def get_alerts(self) -> list[BaseAlert]:
        """
        Get alerts from the manager and return a list of alerts.

        Raises:
            ConnectorSetupError: If there is an error getting the alerts.
        """

    @abstractmethod
    def create_alert_info(self, alert: BaseAlert) -> AlertInfo:
        """
        Create alert info object.

        Args:
            alert: The alert to create the alert info object for.

        Raises:
            ConnectorSetupError: If there is an error creating the alert info object.
        """

    ###################### Native Methods ######################
    @nativemethod
    def extract_params(self) -> None:
        """Extracts connector parameters from UI and store them in the `params` container.

        Note:
            Parameter names will be stored in snake_case format.
            For example: `'Max Hours Backwards'` -> `'max_hours_backwards'`
        """
        for param in self.detailed_params:
            if param.type == ConnectorParamTypes.BOOLEAN:
                input_type = bool
            elif param.type == ConnectorParamTypes.INTEGER:
                input_type = int
            else:
                input_type = str
            is_password = param.type == ConnectorParamTypes.PASSWORD
            value = extract_connector_param(
                        siemplify=self.siemplify,
                        param_name=param.name,
                        input_type=input_type,
                        is_mandatory=param.is_mandatory,
                        print_value=not is_password,
                        remove_whitespaces=not is_password
                    )
            setattr(
                self.params,
                camel_to_snake_case(' '.join(
                    ' '.join(
                        word[0].upper()+word[1:] for word in param.name.split())
                    )
                ),
                input_type(value) if value not in NONE_VALS else value
            )

        self.params.whitelist = (
            self.siemplify.whitelist if isinstance(
                self.siemplify.whitelist,
                list
            )
            else [self.siemplify.whitelist]
        )

    @nativemethod
    def validate_params_wrapper(self) -> None:
        self.params.python_process_timeout = self.param_validator.validate_integer(
            param_name="Python Process Timeout",
            value=self.params.python_process_timeout
        )
        if not is_native(self.validate_params):
            self.logger.info("validating input parameters...")
            self.validate_params()

    @nativemethod
    def read_context_data(self) -> None:
        """load context data from platform data storage (DB/LFS) 
        such as alert ids.

        Examples::

        from TIPCommon import read_ids

            Class MyConnector(Connector):
                # method override
                def read_context_data(self):
                    self.context.ids = TIPCommon.read_ids(self.siemplify)

        Raises:
            ConnectorSetupError: If there is an error loading the context data.
        """
        pass

    @nativemethod
    def write_context_data(self) -> None:
        """save updated context data to platofrm data storage (DB/LFS). 

        from TIPCommon import write_ids

            Class MyConnector(Connector):
                # method override
                def read_context_data(self):
                    write_ids(self.siemplify, self.context.ids)

        Raises:
            ConnectorSetupError: If there is an error saving the context data.
        """
        pass

    @nativemethod
    def store_alert_in_cache(self, alert: BaseAlert):
        """
        Save alert id to `ids.json` or equivelant.

        Args:
            alert: The alert with id to store.

        Examples::

            Class MyConnector(Connector):
                # method override
                def store_alert_in_cache(self, alert):
                    # self.context.alert_ids here is of type list
                    self.context.alert_ids.append(alert.alert_id)
                    
        Raises:
            ConnectorSetupError: If there is an error storing the alert.
        """

    @nativemethod
    def read_context_wrapper(self):
        self.context.last_success_timestamp = self.get_last_success_time()
        if not is_native(self.read_context_data):
            self.logger.info(
                    f'Fetching context data from {self.context._location}...'
                )
            self.read_context_data()

    @nativemethod
    def write_context_wrapper(self, alerts):
        self.set_last_success_time(alerts)
        if not is_native(self.write_context_data):
            self.logger.info(
                    f'Saving context data to {self.context._location}...'
                )
            self.write_context_data(alerts)
        

    @nativemethod
    def get_last_success_time(
        self,
        max_backwards_param_name=None,
        metric="hours",
        padding_period_param_name=None,
        padding_period_metric="hours",
        time_format=DATETIME_FORMAT,
        print_value=True,
        microtime=False,
        date_time_format=None
    ):
        """
        Calculates the connector last successful timestamp 
        using "max TIME backwords" and "padding period" connector parameters, 
        where TIME is the time metric.

        Args:
            max_backwords_param_name (str):
                Parameter name for alert fetching offset time.
                If ``None`` is provided, will calculate timestamp with offset 0.
                Defaults to ``None``.
            metric (str):
                time metric to use in TIPCommon's 'get_last_success_time'.
                Defaults to "hours".
            padding_period_param_name (str, optional):
                Parameter name for padding period offset time.
                Defaults to ``None``.
            padding_period_metric (str, optional):
                time metric - similar to 'metric' parameter.
                Defaults to "hours".
            time_format (int):
                Which time format to return the last success time in.
                Defaults to DATETIME_FORMAT.
            print_value (bool, optional):
                Whether log the value or not. Defaults to True.
            microtime (bool, optional):
                If time format is UNIX, convert the stored timestamp
                from miliseconds to seconds.
                Defaults to False.
            date_time_format(str, optional):
                Return the last success time as a formatted datetime string.
                If ``time_format`` is not ``DATETIME_FORMAT`` this parameter will be ignored.

        Note:
            This is a special method that needs to be overriden and call to the
            original `get_last_success_time` with the appropriate parameters, 
            in case you need to provide different parameters.

        Example::

            #overriden
            def get_last_success_time():
                return super().get_last_success_time(
                    max_backwards_param_name="max_days_backwards",
                    metric="days",
                    padding_period_param_name="padding_period",
                    padding_period_metric="hours"
                )

        Returns:
            (any, int): last success time in DATETIME or UNIX format.
        """
        offset = (
            getattr(self.params, max_backwards_param_name) 
            if max_backwards_param_name else 0
        )
        last_success_time = get_last_success_time(
            siemplify=self.siemplify,
            offset_with_metric={metric: offset},
            time_format=time_format,
            print_value=print_value,
            microtime=microtime
        )

        if padding_period_param_name:
            padding_time_with_metric = {
                padding_period_metric: getattr(
                    self.params,
                    padding_period_param_name
                )
            }
            dt_last_success_time = (
                from_unix_time(last_success_time) if time_format == UNIX_FORMAT
                else last_success_time
            )
            padding_time = utc_now() - timedelta(**padding_time_with_metric)
            if dt_last_success_time > padding_time:
                last_success_time = padding_time
                self.logger.info(
                    "Last success time is greater than provided padding period: "
                    f"{getattr(self.params, padding_period_param_name)}. "
                    f"{last_success_time} will be used as last success time."
                )
                
        last_success_time = (
            last_success_time.strftime(date_time_format)
            if time_format == DATETIME_FORMAT and date_time_format is not None
            else last_success_time
        )
        return last_success_time

    @nativemethod
    def set_last_success_time(
        self,
        alerts: list[BaseAlert],
        timestamp_key: str = None,
        incrementation_value=0,
        log_timestamp=True,
        convert_timestamp_to_micro_time=False,
        convert_a_string_timestamp_to_unix=False
    ):
        """Gets the timestamp of the most recent alert from `alerts` using `timestamp_key`
        where `alerts` is a list of all alerts the connector has tried or 
        completed processing, and stores this timestamp in the LFS / DB.

        Args:
            alerts (list[BaseAlert]): list of all alerts the connector has tried or completed processing
            timestamp_key (str, optional): timestamp attribute name for each alert. Defaults to None.
            incrementation_value (int, optional): The value to increment last timestamp by milliseconds. Defaults to 0.
            log_timestamp (bool, optional): Whether log timestamp or not. Defaults to True.
            convert_timestamp_to_micro_time (bool, optional): timestamp * 1000 if True. Defaults to False.
            convert_a_string_timestamp_to_unix (bool, optional): If the timestamp in the raw data is in the form of a 
                string - convert it to unix before saving it. Defaults to False.

        Note:
            * If `timestamp_key` is None, last success timestamp will not be saved!
            * In order to save it, override this method and provide it with `timestamp_key`!

        Example::

            Class MyAlert(BaseAlert):
                def __init__(self, raw_data, alert_id):
                    super().__init__(raw_data, alert_id)
                    self.timestamp = raw_data.get('DetectionTime')

            Class MyConnector(Connector):
                # method override
                def set_last_success_time(self, alerts):
                    super().set_last_success_time(
                        alerts=alerts,
                        timestamp_key='timestamp'
                    )
        """
        if timestamp_key is not None:
            save_timestamp(
                siemplify=self.siemplify,
                alerts=alerts,
                timestamp_key=timestamp_key,
                incrementation_value=incrementation_value,
                log_timestamp=log_timestamp,
                convert_timestamp_to_micro_time=convert_timestamp_to_micro_time,
                convert_a_string_timestamp_to_unix=convert_a_string_timestamp_to_unix
            )

    @nativemethod
    def load_env_common(self) -> EnvironmentHandle:
        """
        loads environment handle object from EnvironementCommon module
        depending on Siemplify platform deployment.

        Note:
            If needed, override this method to load environment handle object 
            from EnvironementCommon module.

        Raises:
            ConnectorSetupError: if couldn't create environment handle object

        Returns:
            EnvironmentHandle: Environment handle object
        """
        try:
            self._env_common = (
                GetEnvironmentCommonFactory.create_environment_manager(
                    self.siemplify,
                    self.params.environment_field_name,
                    self.params.environment_regex_pattern
                )
            )
        except Exception as e:
            raise ConnectorSetupError(
                f"Failed to create environment handle object: {e}"
            ) from e

    @nativemethod
    def max_alerts_processed(self, processed_alerts) -> bool:
        """Return True if reached the maximum alerts to process limit in 
        the connector execution.

        Args:
            processed_alerts: A list of processed alerts.

        Returns:
            True if the maximum alerts to process limit has been reached, 
            False otherwise.
        """
        return False

    @nativemethod
    def pass_filters(self, alert) -> bool:
        """Boolean method to check if alert passes connector filters

        Args:
            alert: The alert to check.

        Returns:
            True if the alert passes the filters, False otherwise.
        """
        return True

    @nativemethod
    def filter_alerts(self, alerts: list[BaseAlert]) -> list[BaseAlert]:
        """Filter alerts from manager and return list of filtered alerts

        Args:
            alerts: A list of alerts.

        Returns:
            A list of filtered alerts.
        """
        return alerts

    @nativemethod
    def process_alert(self, alert: BaseAlert) -> BaseAlert:
        """Extensive alert processing (like events enrichment)

        Args:
            alert: The alert to process.

        Returns:
            The processed alert.
        """
        return alert

    @nativemethod
    def _perspectives(self) -> None:
        self.context._location = (
            "DB" if platform_supports_db(self.siemplify)
            else f"Local File System: {self.siemplify.run_folder}"
        )

    @nativemethod
    def process_alerts(
        self,
        filtered_alerts: list[BaseAlert],
        timeout_threshold: float = TIMEOUT_THRESHOLD
    ) -> tuple[list[AlertInfo], list[BaseAlert]]:
        """Main alert processing loop.
        Steps for each alert object:

        1. Check if connector is approaching timeout
        2. Check max alert count for test run
        3. Check max alert count for commercial run (override)
        4. Check if alert pass filters
        5. Process alert (override)
        6. Store alert in cache (id.json etc) (override)
        7. Create AlertInfo object
        8. Check is alert overflowed
        9. append alert to processed alerts

        Args:
            filtered_alerts (list[BaseAlert]):list of filtered BaseAlert objects
            timeout_threshold (float, optional): timeout threshold for connector execution. Defaults to 0.9

        Note:
            To provide other value for timeout threshold, 
            you can override this method as follows::

                my_threshold = 0.9
                def process_alerts(self, filtered_alerts, timeout_threshold):
                    return super().process_alerts(filtered_alerts, my_threshold)

        Returns:
            tuple containing a list of AlertInfo objects, 
            and a list of BaseAlert objects
        """
        all_alerts = []
        processed_alerts = []

        for alert in filtered_alerts:
            try:
                if is_approaching_timeout(
                    connector_starting_time=self.connector_start_time,
                    python_process_timeout=self.params.python_process_timeout,
                    timeout_threshold=timeout_threshold
                ):
                    self.logger.info(
                        'Timeout is approaching. Connector will gracefully exit'
                    )
                    break

                if self.is_test_run and processed_alerts:
                    self.logger.info(
                        'Maximum alert count (1) for test run reached!'
                    )
                    break

                if self.max_alerts_processed(processed_alerts):
                    self.logger.info(
                        f'Maximum alert count {len(processed_alerts)} '
                        f'for connector execution reached!.'
                    )
                    break

                self.logger.info(f'Starting to process alert {alert.alert_id}')
                if not self.pass_filters(alert):
                    self.logger.info(
                        f'Alert {alert.alert_id} did not pass filters. '
                        'Skipping...'
                    )
                    continue

                processed_alert = self.process_alert(alert)
                self.logger.info(
                    f'Alert {alert.alert_id} processed successfully'
                )

                self.store_alert_in_cache(processed_alert)
                all_alerts.append(alert)

                alert_info = self.create_alert_info(processed_alert)
                self.logger.info(
                    f'Created AlertInfo object for alert {alert.alert_id}'
                )

                if is_overflowed(self.siemplify, alert_info, self.is_test_run):
                    self.logger.info(
                        f'{alert_info.rule_generator}-{alert_info.ticket_id}-'
                        f'{alert_info.environment}-{alert_info.device_product} '
                        'found as overflow alert. Skipping.'
                    )
                    # If is overflowed we should skip
                    continue

                processed_alerts.append(alert_info)
                self.logger.info(
                    f'Finished processing {alert.alert_id}'
                )

            except Exception as e:
                self.logger.error(
                    f'Failed to process alert with id {alert.alert_id}'
                )
                self.logger.exception(e)

                if self.is_test_run:
                    raise

        return processed_alerts, all_alerts

    ###################### Connecotr Execution ######################
    @output_handler
    def start(self) -> None:
        """
        Executes the connector logic.

        Execution steps:

            1. Extracting connctor script parameters from the SDK connector object
            2. Validate parameters values
            3. Loading the connector context data via the SDK connector object
            4. Initializing the integrations manager(s)
            5. Fetching & parsing alerts from the product via integration manager
            6. Filtering the alerts
            7. Processing the the filtered alerts into siemplify alerts
            8. Saving connector context data via the SDK connector object
            9. Sending newly created siemplify alerts to the platform

        Raises:
            ConnectorSetupError: if any of the pre prrocessing phases fail
        """
        self.logger.info(
            f'---------------- Starting connector {self.script_name} '
            'execution ----------------'
        )
        if self.is_test_run:
            self.logger.info(
                '****** This is an \"IDE Play Button\"\\\"Run Connector once\" '
                'test run ******'
            )

        self.logger.info(
            '------------------- Main - Param Init -------------------'
        )
        self.extract_params()
        self.logger.info(
            '------------------- Main - Started -------------------'
        )
        try:
            try:
                self.validate_params_wrapper()
                self.read_context_wrapper()
                self.logger.info('Initializing managers...')
                self.init_managers()
            except Exception as e:
                raise ConnectorSetupError(e) from e

            self.logger.info(
                'Fetching data from manager and starting case ingestion...'
            )
            fetched_alerts = self.get_alerts()
            self.logger.info(
                f'Fetched {len(fetched_alerts)} alerts from the manager'
            )

            filterd_alerts = self.filter_alerts(fetched_alerts)
            if not is_native(self.filter_alerts):
                self.logger.info(
                    f'Sucessfully filtered alerts. '
                    f'Filtered alerts count: {len(filterd_alerts)}'
                )

            self.logger.info('Starting to process alerts...')
            processed_alerts, all_alerts = self.process_alerts(filterd_alerts)
            if not self.is_test_run:
                self.write_context_wrapper(all_alerts)

        except Exception as e:
            self.logger.error(f'{self.error_msg}')
            self.logger.error(f'Error: {e}')
            self.logger.exception(e)

            if self.is_test_run:
                raise
        self.logger.info(
            '------------------- Main - Finished -------------------'
        )
        self.logger.info(
            f'Sending {len(processed_alerts)} new alerts back to SOAR platform.'
        )
        self.siemplify.return_package(processed_alerts)
        self.logger.info(
            f'---------------- Finished connector {self.script_name} '
            f'execution ----------------'
        )
