

def nativemethod(method):
    """Decorator that marks a method as native.

    Args:
        method (function): The method to mark as native.

    Returns:
        function: The decorated method.
    """
    method.is_native = True
    return method


def is_native(method):
    """Returns True if the method is marked as native, False otherwise.

    Args:
        method (function): The method to check.

    Returns:
        bool: True if the method is marked as native, False otherwise.
    """
    if hasattr(method, 'is_native'):
        return method.is_native
    return False