"""Provides the 1P API client implementation for interacting with Chronicle SOAR."""

# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from typing import TYPE_CHECKING

from TIPCommon.rest.custom_types import HttpMethod

from .base_soar_api import BaseSoarApi

if TYPE_CHECKING:
    import requests

    from TIPCommon.types import ChronicleSOAR


class OnePlatformSoarApi(BaseSoarApi):
    """Chronicle SOAR API client using 1P endpoints."""

    def __init__(self, chronicle_soar: ChronicleSOAR) -> None:
        """Initialize the OnePlatformSoarApi.

        Args:
            chronicle_soar: The ChronicleSOAR SDK object.

        """
        super().__init__(chronicle_soar)

    def save_attachment_to_case_wall(self) -> requests.Response:
        """Save an attachment to the case wall using 1P API."""
        payload = {
            "caseAttachment": {
                "attachmentId": 0,
                "attachmentBase64": self.params.base64_blob,
                "fileType": self.params.file_type,
                "fileName": self.params.name,
            },
            "comment": self.params.description,
            "isImportant": self.params.is_important,
        }
        if getattr(self.chronicle_soar, "alert_id", None):
            payload["alertIdentifier"] = self.chronicle_soar.alert_id

        endpoint = f"api/1p/external/v1.0/cases/{self.params.case_id}/comments"
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_entity_data(self) -> requests.Response:
        """Get entity data using 1P API."""
        payload = {
            "identifier": self.params.entity_identifier,
            "type": self.params.entity_type,
            "environment": self.params.entity_environment,
            "lastCaseType": self.params.last_case_type,
            "caseDistributionType": self.params.case_distribution_type,
        }
        endpoint = "api/1p/external/v1.0/uniqueEntities:fetchFull"
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_full_case_details(self) -> requests.Response:
        """Get full case details using 1P API."""
        endpoint = f"api/1p/external/v1.0/cases/{self.params.case_id}"
        query_params = {"expand": "tags"}
        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    def get_case_attachments(self) -> requests.Response:
        """Get case attachments using 1P API."""
        endpoint = f"api/1p/external/v1.0/cases/{self.params.case_id}/activities"
        return self._make_request(HttpMethod.GET, endpoint)
