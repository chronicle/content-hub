"""Provides the Legacy API client implementation for interacting with Chronicle SOAR."""

# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from typing import TYPE_CHECKING

from TIPCommon.rest.custom_types import HttpMethod

from .base_soar_api import BaseSoarApi

if TYPE_CHECKING:
    import requests

    from TIPCommon.types import ChronicleSOAR


class LegacySoarApi(BaseSoarApi):
    """Chronicle SOAR API client using legacy endpoints."""

    def __init__(self, chronicle_soar: ChronicleSOAR) -> None:
        """Initialize the LegacySoarApi.

        Args:
            chronicle_soar: The ChronicleSOAR SDK object.

        """
        super().__init__(chronicle_soar)

    def save_attachment_to_case_wall(self) -> requests.Response:
        """Save an attachment to the case wall using legacy API."""
        endpoint = "api/external/v1/cases/AddEvidence/"
        payload = {
            "CaseIdentifier": self.params.case_id,
            "Base64Blob": self.params.base64_blob,
            "Name": self.params.name,
            "Description": self.params.description,
            "Type": self.params.file_type,
            "IsImportant": self.params.is_important,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_entity_data(self) -> requests.Response:
        """Get entity data using legacy API."""
        endpoint = "api/external/v1/entities/GetEntityData"
        payload = {
            "entityIdentifier": self.params.entity_identifier,
            "entityType": self.params.entity_type,
            "entityEnvironment": self.params.entity_environment,
            "lastCaseType": self.params.last_case_type,
            "caseDistributionType": self.params.case_distribution_type,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_full_case_details(self) -> requests.Response:
        """Get full case details using legacy API."""
        endpoint = (
            f"api/external/v1/cases/GetCaseFullDetails/{self.params.case_id}"
        )
        query_params = {"format": "snake"}
        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    def get_case_attachments(self) -> requests.Response:
        """Get case attachments using legacy API."""
        endpoint = (
            f"api/external/v1/dynamic-cases/GetWallActivitiesV2{self.params.case_id}"
        )
        return self._make_request(HttpMethod.GET, endpoint)
