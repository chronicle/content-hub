import time
from google.auth import crypt, jwt
import json


def generate_jwt_from_sa(service_account, expiry_length=3600, audience=None):
    """Generates a Json Web Token to access GCP API resources using REST

    Args:
        service_account (str | dict):
            Google cloud project service account with the necessary IAM roles
        expiry_length (int):
            Time until token expires in seconds. Defaults to 1 hour
        audience (str):
            GCP Scope. If not provided, will fall back to
            https://www.googleapis.com/auth/cloud-platform

    Returns:
        bytes: JWT token to use in Authorization header
    """

    if isinstance(service_account, str):
        service_account = json.loads(service_account)

    if audience is None:
        audience = 'https://www.googleapis.com/auth/cloud-platform'

    sa_email = service_account.get('client_email')
    now = int(time.time())
    payload = {
        'iat': now,
        'exp': now + expiry_length,
        'iss': sa_email,
        'aud': audience,
        'sub': sa_email,
        'email': sa_email
    }

    signer = crypt.RSASigner.from_service_account_info(service_account)
    return jwt.encode(signer, payload)
