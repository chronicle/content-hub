import requests
from .auth import generate_jwt_from_sa


def get_auth_session(service_account, audience=None, verify_ssl=True):
    """Creates an Authorized HTTP session to a GCP resource API.

    Args:
        service_account (str | dict):
            Google cloud project service account with the necessary IAM roles
        audience (str):
            GCP Scope
        verify_ssl (bool):
            Whether to create session with SSL encryption

    Note:
        service_account must have the necessary IAM roles

    Returns:
        requests.Session: An authorized session object
    """
    token = generate_jwt_from_sa(
        service_account, audience=audience).decode('utf-8')
    headers = {
        'Authorization': 'Bearer {}'.format(token)
    }
    session = requests.Session()
    session.headers.update(headers)
    session.verify = verify_ssl
    return session
