# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

JOB_ID_KEY = "uniqueIdentifier"

PARAMETER_EXTRACTION_ERR_MSG = (
    "Failed to all installed job instances via API!\nHTTPError stacktrace: {error}\n"
)
JOB_INSTANCES_PARSE_ERROR_MSG = (
    'Failed to parse the "get installed job instances" response Json\n'
    "JSONDecoder stacktrace: {error}\n"
)
