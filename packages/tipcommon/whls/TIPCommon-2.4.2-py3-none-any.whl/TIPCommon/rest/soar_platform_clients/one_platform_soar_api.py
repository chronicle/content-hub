"""Provides the 1P API client implementation for interacting with Chronicle SOAR."""

# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import json
import re
from typing import TYPE_CHECKING

from requests_toolbelt.multipart.encoder import MultipartEncoder

from TIPCommon.consts import DATAPLANE_1P_HEADER, DEFAULT_1P_PAGE_SIZE
from TIPCommon.exceptions import EmptyMandatoryValues, ParameterValidationError
from TIPCommon.rest.custom_types import HttpMethod
from TIPCommon.utils import escape_odata_literal, get_sdk_api_uri, safe_json_for_204, temporarily_remove_header

from .base_soar_api import BaseSoarApi

if TYPE_CHECKING:
    import requests

    from TIPCommon.types import SingleJson


_PAGE_SIZE = 1000
_EMAIL_TEMPLATES_PAGE_SIZE = 50


class OnePlatformSoarApi(BaseSoarApi):
    """Chronicle SOAR API client using 1P endpoints."""

    def _clean_resource_name(self, resource_name: str) -> str:
        """Strips the projects/.../instances/... prefix from the resource name."""
        if not resource_name:
            return ""
        return re.sub(r"^projects/[^/]+/locations/[^/]+/instances/[^/]+/", "", resource_name)

    def save_attachment_to_case_wall(self) -> requests.Response:
        """Save an attachment to the case wall using 1P API."""
        payload = {
            "caseAttachment": {
                "attachmentId": 0,
                "attachmentBase64": self.params.base64_blob,
                "fileType": self.params.file_type,
                "fileName": self.params.name,
            },
            "comment": self.params.description,
            "isImportant": self.params.is_important,
        }
        if getattr(self.chronicle_soar, "alert_id", None):
            payload["alertIdentifier"] = self.chronicle_soar.alert_id

        endpoint = f"/cases/{self.params.case_id}/comments"
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_entity_data(self) -> requests.Response:
        """Get entity data using 1P API."""
        payload = {
            "identifier": self.params.entity_identifier,
            "type": self.params.entity_type,
            "environment": self.params.entity_environment,
            "lastCaseType": self.params.last_case_type,
            "caseDistributionType": self.params.case_distribution_type,
        }
        endpoint = "/uniqueEntities:fetchFull"
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_full_case_details(self) -> requests.Response:
        """Get full case details using explicit expand parameters.

        Expand behavior:
            - case_expand controls /cases endpoint
            - alert_expand controls /caseAlerts endpoint when case_type="alert"
        """
        case_type = self.params.case_type
        case_id = self.params.case_id

        if case_type == "alert":
            params = self._build_expand_params(getattr(self.params, "alert_expand", None))
            endpoint = f"/cases/{case_id}/caseAlerts"
        else:
            params = self._build_expand_params(getattr(self.params, "case_expand", None))
            endpoint = f"/cases/{case_id}"

        return self._make_request(HttpMethod.GET, endpoint, params=params)

    def get_case_insights(self) -> list[SingleJson]:
        """Get case insights using 1P API."""
        query_string = f"$filter=activityType eq 'CaseInsight'&pageSize={DEFAULT_1P_PAGE_SIZE}"
        endpoint = f"/cases/{self.params.case_id}/activities?{query_string}"

        return self._paginate_results(endpoint, "activities")

    def get_installed_integrations_of_environment(self) -> list[SingleJson]:
        """Get installed integrations of environment using legacy API."""
        name = "*" if self.params.environment == "Shared Instances" else self.params.environment
        query_string = f"$filter=environment eq '{escape_odata_literal(name)}'&pageSize={_PAGE_SIZE}"
        endpoint = f"/integrations/{self.params.integration_identifier}/integrationInstances?{query_string}"

        return self._paginate_results(endpoint, "integrationInstances")

    def get_connector_cards(self) -> requests.Response:
        """Get connector cards using legacy API."""
        endpoint = f"/integrations/{self.params.integration_name}/connectors/-/connectorInstances"
        return self._make_request(HttpMethod.GET, endpoint)

    def get_federation_cases(self) -> requests.Response:
        """Get federation cases using legacy API."""
        endpoint = "/legacyFederatedCases:legacyFetchCasesToSync"
        params = {"pageToken": self.params.continuation_token}
        return self._make_request(HttpMethod.GET, endpoint, params=params)

    def patch_federation_cases(self) -> requests.Response:
        """Patch federation cases using legacy API."""
        endpoint = "/legacyFederatedCases:legacyBatchPatchFederatedCases"
        headers = {"AppKey": self.params.api_key} if self.params.api_key else None
        payload = {"cases": self.params.cases_payload}

        return self._make_request(
            HttpMethod.POST,
            endpoint,
            json_payload=payload,
            headers=headers,
        )

    def get_workflow_instance_card(self) -> requests.Response:
        """Get workflow instance card using legacy API."""
        endpoint = "/legacyPlaybooks:legacyGetWorkflowInstancesCards?format=camel"
        payload = {
            "caseId": self.params.case_id,
            "alertIdentifier": self.params.alert_identifier,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def pause_alert_sla(self) -> requests.Response:
        """Pause alert sla."""
        alert = self.get_case_alerts().json()
        alert_id = alert.get("caseAlerts")[0].get("id")
        endpoint = f"/cases/{self.params.case_id}/caseAlerts/{alert_id}:pauseSla"
        payload = {
            "message": self.params.message,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def resume_alert_sla(self) -> requests.Response:
        """Resume alert sla."""
        alert = self.get_case_alerts().json()
        alert_id = alert.get("caseAlerts")[0].get("id")
        endpoint = f"/cases/{self.params.case_id}/caseAlerts/{alert_id}:resumeSla"
        payload = {
            "message": self.params.message,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def _get_case_details(self) -> SingleJson:
        """Fetch case details using explicit case_expand."""
        params = self._build_expand_params(getattr(self.params, "case_expand", None))
        case_id = self.params.case_id
        endpoint = f"/cases/{case_id}"
        return self._make_request(
            HttpMethod.GET,
            endpoint,
            params=params,
        ).json()

    def _get_case_alerts(self) -> list:
        """Fetch case alert cards using explicit alert_expand."""
        params = self._build_expand_params(getattr(self.params, "alert_expand", None))
        case_id = self.params.case_id
        endpoint = f"/cases/{case_id}/caseAlerts"
        response = self._make_request(
            HttpMethod.GET,
            endpoint,
            params=params,
        ).json()

        return response.get("caseAlerts", [])

    def get_case_overview_details(self) -> SingleJson:
        """Get full case overview including case details and alert cards.

        Expand is explicitly controlled by:
            - self.params.case_expand
            - self.params.alert_expand
        """
        case_data = self._get_case_details()
        case_data["alertCards"] = self._get_case_alerts()
        return case_data

    def remove_case_tag(self) -> requests.Response:
        """Remove case tag."""
        endpoint = f"/cases/{self.params.case_id}:removeTag"
        payload = {
            "caseId": self.params.case_id,
            "tag": self.params.tag,
            "alertIdentifier": self.params.alert_identifier,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def change_case_description(self) -> requests.Response:
        """Change case description."""
        endpoint = f"/cases/{self.params.case_id}"
        payload = {"description": self.params.description}
        return self._make_request(HttpMethod.PATCH, endpoint, json_payload=payload)

    def set_alert_priority(self) -> requests.Response:
        """Set alert priority."""
        endpoint = "/legacySdk:legacyUpdateAlertPriority"
        payload = {
            "caseId": self.params.case_id,
            "alertIdentifier": self.params.alert_identifier,
            "priority": self.params.priority,
            "alertName": self.params.alert_name,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def set_case_score_bulk(self) -> requests.Response:
        """Set case score bulk."""
        endpoint = "/legacySdk:legacyUpdateCaseScore"
        payload = {
            "caseScores": [
                {
                    "caseId": self.params.case_id,
                    "score": self.params.score,
                }
            ],
        }
        return self._make_request(HttpMethod.PATCH, endpoint, json_payload=payload)

    def get_integration_full_details(self) -> requests.Response:
        """Get integration full details."""
        endpoint = f"/marketplaceIntegrations/{self.params.integration_identifier}"
        return self._make_request(HttpMethod.GET, endpoint)

    def get_integration_instance_details_by_id(self) -> requests.Response:
        """Get integration instance details by instance id."""
        endpoint = f"/integrations/{self.params.integration_identifier}/integrationInstances/{self.params.instance_id}"

        return self._make_request(HttpMethod.GET, endpoint)

    def get_integration_instance_details_by_name(self) -> SingleJson:
        """Get integration instance details by instance name."""
        endpoint = f"/integrations/{self.params.integration_identifier}/integrationInstances"
        instance_name = escape_odata_literal(self.params.instance_display_name)
        query_params = {"$filter": f"displayName eq '{instance_name}'"}

        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    def get_users_profile(self) -> requests.Response:
        """Get users profile."""
        endpoint = "/legacySoarUsers"
        display_name = escape_odata_literal(self.params.display_name)
        query_params = {"$filter": f"displayName eq '{display_name}'"}
        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    def get_case_alerts(self) -> requests.Response:
        """Get case alerts."""
        endpoint = f"/cases/{self.params.case_id}/caseAlerts"
        query_params: dict[str, str] = {}
        if self.params.alert_identifier is not None:
            alert_identifier = escape_odata_literal(self.params.alert_identifier)
            query_params = {"$filter": f"identifier eq '{alert_identifier}'"}
        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_investigator_data(self) -> requests.Response:
        """Get investigator data."""
        case_id = self.params.case_id
        alert_data = self.get_alert_id_by_alert_identifier()
        if alert_data.status_code == 204:
            alert_data._content = b"{}"
            return alert_data

        alert_id = alert_data.json()["caseAlerts"][0].get("id")
        endpoint = f"/cases/{case_id}/caseAlerts/{alert_id}/involvedEvents:formatted"
        return self._make_request(HttpMethod.GET, endpoint)

    def get_alert_id_by_alert_identifier(self) -> requests.Response:
        """Get alert id by alert identifier."""
        endpoint = f"/cases/{self.params.case_id}/caseAlerts"
        alert_identifier = escape_odata_literal(self.params.alert_identifier)
        query_params = {"$filter": f"identifier eq '{alert_identifier}'"}
        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    # TODO : Not avialable in 1p so we will implement when api avialble
    def remove_entities_from_custom_list(self) -> requests.Response:
        """Remove entities from custom list."""
        endpoint = "/sdk/RemoveEntitiesFromCustomList"
        payload = self.params.list_entities_data
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    # TODO : Not avialable in 1p so we will implement when api avialble
    def add_entities_to_custom_list(self) -> requests.Response:
        """Add entities to custom list."""
        endpoint = "/sdk/AddEntitiesToCustomList"
        payload = self.params.list_entities_data
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def _paginate_results(self, initial_endpoint: str, root_response_key: str) -> list[SingleJson]:
        """Handles paginated API requests, managing tokens and aggregating results.
        Avoids infinite loops by using a controlled loop condition.

        Args:
            initial_endpoint (str): The initial API endpoint to fetch data from.
            root_response_key (str): The key in the response JSON where records are stored.

        Returns:
            list[SingleJson]: A list of all records retrieved across paginated responses.

        """
        all_records = []
        next_token = None
        current_endpoint = initial_endpoint

        while True if next_token is None else bool(next_token):
            endpoint_with_token = f"{current_endpoint}&pageToken={next_token}" if next_token else current_endpoint

            response_data = {}
            try:
                response = self._make_request(HttpMethod.GET, endpoint_with_token)
                response.raise_for_status()
                response_data = response.json()
            except Exception:
                break

            current_records = response_data.get(root_response_key, [])
            all_records.extend(current_records)

            next_token = response_data.get("nextPageToken")
            if not next_token:
                break

        return all_records

    def _build_tracking_list_filter_string(
        self,
        category_names: str | list[str] | None,
        entity_id: str | None,
        environment: str | None = None,
    ) -> str:
        """Builds the OData filter string for tracking list records.

        The filter structure is: [environment AND] [category OR block AND]
        [entityIdentifier].
        """
        filter_parts = []

        if environment:
            escaped_env = escape_odata_literal(environment)
            # Environments are stored as a JSON array string (e.g., '["Env X", "Env Y"]').
            # We use 'eq' for the wildcard '["*"]' and 'contains' for the specific environment.
            env_filter = f"(environments eq '[\"*\"]' or contains(environments, '\"{escaped_env}\"'))"
            filter_parts.append(env_filter)

        if category_names:
            if isinstance(category_names, str):
                category_names = [name.strip() for name in category_names.split(",")]

            if category_names:
                category_filters = [f"category eq '{name}'" for name in category_names]

                category_or_block = " or ".join(category_filters)
                category_filter_string = f"({category_or_block})"

                filter_parts.append(category_filter_string)

        if entity_id:
            filter_parts.append(f"entityIdentifier eq '{entity_id}'")

        if not filter_parts:
            return ""

        return " and ".join(filter_parts)

    def get_traking_list_record(self) -> SingleJson:
        """Get traking list record and handles pagination with combined filters.

        The filter combines environment (AND) with category (OR, grouped)
        and entityIdentifier (AND).
        """
        category_names = self.params.category_name
        entity_id = self.params.entity_id

        filter_string = self._build_tracking_list_filter_string(category_names, entity_id)

        base_endpoint = "/system/settings/customLists"

        if filter_string:
            initial_endpoint = f"{base_endpoint}?$filter={filter_string}&pageSize={_PAGE_SIZE}"
        else:
            initial_endpoint = f"{base_endpoint}?pageSize={_PAGE_SIZE}"

        return self._paginate_results(initial_endpoint=initial_endpoint, root_response_key="customLists")

    def get_traking_list_records_filtered(self) -> SingleJson:
        """Get all tracking list records, filtering by environment AND optional
        category/entity
        filters, and handles pagination.
        """
        environment = self.params.environment or self.chronicle_soar.environment

        category_names = self.params.category_name
        entity_id = self.params.entity_id

        filter_string = self._build_tracking_list_filter_string(category_names, entity_id, environment=environment)

        base_endpoint = "/system/settings/customLists"

        if filter_string:
            initial_endpoint = f"{base_endpoint}?$filter={filter_string}&pageSize={_PAGE_SIZE}"
        else:
            initial_endpoint = f"{base_endpoint}?pageSize={_PAGE_SIZE}"

        return self._paginate_results(initial_endpoint=initial_endpoint, root_response_key="customLists")

    def execute_bulk_assign(self) -> requests.Response:
        """Execute bulk assign."""
        endpoint = "/cases:executeBulkAssign"
        payload = {"casesIds": self.params.case_ids, "userName": self.params.user_name}
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def execute_bulk_close_case(self) -> requests.Response:
        """Execute bulk close case."""
        endpoint = "/cases:executeBulkClose"
        payload = {
            "casesIds": self.params.case_ids,
            "closeReason": self.params.close_reason,
            "rootCause": self.params.root_cause,
            "closeComment": self.params.close_comment,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_users_profile_cards(self) -> list[SingleJson]:
        """Get users profile cards."""
        page_size = getattr(self.params, "page_size", _PAGE_SIZE)
        endpoint = f"/legacySoarUsers?pageSize={page_size}"
        return self._paginate_results(endpoint, "legacySoarUsers")

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_security_events(self) -> requests.Response:
        """Get security events."""
        endpoint = f"/cases/{self.params.case_id}/caseAlerts/{self.params.alert_id}/involvedEvents:formatted"
        return self._make_request(HttpMethod.GET, endpoint)

    def get_entity_cards(self) -> requests.Response:
        """Get entity cards."""
        endpoint = f"/cases/{self.params.case_id}/caseAlerts/-/involvedEntities:fetchCards"
        return self._make_request(HttpMethod.GET, endpoint)

    def pause_case_sla(self, case_id: int, message: str | None = None) -> requests.Response:
        """Send an api request to pause case sla for a given case."""
        endpoint = f"/cases/{case_id}:pauseSla"
        request_payload = {"caseId": case_id}
        if message:
            request_payload["message"] = message

        return self._make_request(HttpMethod.POST, endpoint, json_payload=request_payload)

    def resume_case_sla(self, case_id: int) -> requests.Response:
        """Send an api request to resume case sla for a given case."""
        endpoint = f"/cases/{case_id}:resumeSla"
        request_payload = {"caseId": case_id}
        return self._make_request(HttpMethod.POST, endpoint, json_payload=request_payload)

    def rename_case(self) -> requests.Response:
        """Rename case."""
        endpoint = f"/cases/{self.params.case_id}"
        payload = {"displayName": self.params.case_title}
        return self._make_request(HttpMethod.PATCH, endpoint, json_payload=payload)

    def add_comment_to_entity(self) -> requests.Response:
        """Add comment to entity."""
        endpoint = "/uniqueEntities:addNote"
        payload = {
            "author": self.params.author,
            "content": self.params.content,
            "entityIdentifier": self.params.entity_identifier,
            "entityType": self.params.entity_type,
            "entityEnvironment": self.params.entity_environment,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def assign_case_to_user(self) -> requests.Response:
        """Assign case to user."""
        endpoint = "/cases:executeBulkAssign"
        payload = {"casesIds": [self.params.case_id], "userName": self.params.assign_to}
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_email_template(self) -> list[SingleJson]:
        """Get email template."""
        endpoint = f"/system/settings/emailTemplates?pageSize={_EMAIL_TEMPLATES_PAGE_SIZE}"
        return self._paginate_results(endpoint, "emailTemplates")

    def get_siemplify_user_details(self) -> list[SingleJson]:
        """Get siemplify user details."""
        page_size = getattr(self.params, "page_size", _PAGE_SIZE)
        endpoint = f"/legacySoarUsers?pageSize={page_size}"
        return self._paginate_results(endpoint, "legacySoarUsers")

    def get_domain_alias(self) -> requests.Response:
        """Get domain alias."""
        endpoint = "/system/settings/domains"
        return self._make_request(HttpMethod.GET, endpoint)

    def add_tags_to_case_in_bulk(self) -> requests.Response:
        """Add tags to case in bulk."""
        endpoint = "/cases:executeBulkAddTag"
        payload = {"casesIds": self.params.case_ids, "tags": self.params.tags}
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_installed_jobs(self) -> list[SingleJson] | requests.Response:
        """Get installed jobs."""
        endpoint: str = "/integrations/-/jobs/-/jobInstances"
        if self.params.job_instance_id:
            endpoint += f"/{self.params.job_instance_id}"
            return self._make_request(HttpMethod.GET, endpoint)

        endpoint += f"?pageSize={_PAGE_SIZE}"
        return self._paginate_results(initial_endpoint=endpoint, root_response_key="job_instances")

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def save_or_update_job(self) -> requests.Response:
        """Save or update job data using 1P API.

        The ``job_data`` dict must contain at least:

        - **name** (``str``): The full GCP resource path of
          the job instance, e.g.::

              projects/{project}/locations/{location}/
              instances/{instance}/integrations/{integrationId}/
              jobs/{jobId}/jobInstances/{instanceId}

        - **parameters** (``list[dict]``): A list of parameter
          dicts, each containing at minimum ``name`` (or
          ``displayName``) and ``value`` keys.

        Example ``job_data``::

            {
                "name": "projects/my-proj/locations/us/"
                        "instances/abc/integrations/MyInt/"
                        "jobs/j1/jobInstances/ji1",
                "parameters": [
                    {
                        "displayName": "API Key",
                        "value": "new-value"
                    }
                ]
            }

        Raises:
            EmptyMandatoryValues: If ``job_data`` is missing
                required fields (``name``, ``parameters``).
            ParameterValidationError: If the resource path
                cannot be parsed.
        """
        job_data = self.params.job_data

        resource_path = job_data.get("name")
        if resource_path is None:
            raise EmptyMandatoryValues(
                "Job data must include a 'name' field with the resource path. "
                "Example (1P resource path): "
                "projects/{project}/locations/{location}/instances/{instance}/"
                "integrations/{integrationId}/jobs/{jobId}/"
                "jobInstances/{instanceId}. "
                "Cannot determine the PATCH endpoint without the resource path."
            )

        parameters = job_data.get("parameters")
        if parameters is None:
            raise EmptyMandatoryValues(
                "Job data is missing 'parameters' field, Nothing to update."
            )
        # The resource path is a full GCP resource name, e.g.:
        # projects/X/locations/Y/instances/Z/integrations/.../jobInstances/{id}
        # The API base URL already includes up to instances/Z, so we need
        # just the relative path starting from /integrations/...
        segment_pos = resource_path.find("integrations/")
        if segment_pos == -1:
            raise ParameterValidationError(
                param_name="name",
                value=resource_path,
                message=(
                    "Cannot parse resource path. "
                    "Expected path to contain 'integrations/'"
                ),
            )

        endpoint = f"/{resource_path[segment_pos:]}"

        return self._make_request(
            HttpMethod.PATCH,
            endpoint,
            params={"updateMask": "parameters"},
            json_payload={"parameters": parameters},
        )

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_integration_jobs(self) -> requests.Response:
        """Get jobs for a specific integration."""
        endpoint: str = f"/integrations/{self.params.integration_name}/jobs"
        return self._make_request(HttpMethod.GET, endpoint)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_integration_connectors(self) -> requests.Response:
        """Get connectors for a specific integration."""
        endpoint: str = f"/integrations/{self.params.integration_name}/connectors"
        return self._make_request(HttpMethod.GET, endpoint)

    def get_case_wall_records(self) -> requests.Response:
        """Get case wall records using 1P API.

        Expand behavior:
            - self.params.wall_expand controls expand query.
            - Uses "expand" query param (not "expand").
        """
        endpoint = f"/cases/{self.params.case_id}/caseWallRecords"

        expand = getattr(self.params, "wall_expand", None)

        params = {"pageSize": DEFAULT_1P_PAGE_SIZE}
        if expand:
            params["expand"] = ",".join(expand)

        return self._make_request(HttpMethod.GET, endpoint, params=params)

    def get_entity_expand_cards(self) -> requests.Response:
        """Get entity expand cards using 1P API.

        Expand behavior:
            - self.params.entity_expand controls "expand" query.
        """
        endpoint = f"/cases/{self.params.case_id}/caseAlerts/-/involvedEntities"

        expand = getattr(self.params, "entity_expand", None)
        params = self._build_expand_params(expand)

        return self._make_request(HttpMethod.GET, endpoint, params=params)

    def get_all_case_overview_details(self) -> SingleJson:
        """Get full case overview including:
            - Case details
            - Alert cards
            - Security events
            - Wall data
            - Entity cards.

        Expand behavior (explicit and separated):
            - self.params.case_expand   → /cases
            - self.params.alert_expand  → /caseAlerts
            - self.params.wall_expand   → /caseWallRecords
            - self.params.entity_expand → /involvedEntities

        No implicit expansion is performed.
        """
        case_data = self.get_case_overview_details()

        security_events = self._make_request(
            HttpMethod.GET, f"/cases/{self.params.case_id}/caseAlerts/-/involvedEvents:formatted"
        ).json()

        events_by_alert: SingleJson = {}
        for event in security_events:
            alert_id = event.get("alertIdentifier")
            if alert_id:
                events_by_alert.setdefault(alert_id, []).append(event)

        for alert in case_data.get("alertCards", []):
            alert["securityEventCards"] = events_by_alert.get(alert.get("identifier"), [])

        wall_response = self.get_case_wall_records()
        wall_data = safe_json_for_204(wall_response, default_for_204={})
        case_data["wallData"] = wall_data.get("caseWallRecords", [])

        entity_response = self.get_entity_expand_cards()
        entity_data = safe_json_for_204(entity_response, default_for_204={})
        case_data["involvedEntities"] = entity_data.get("involvedEntities", [])

        entity_cards_response = self.get_entity_cards()
        entity_cards_data = safe_json_for_204(entity_cards_response, default_for_204={})
        case_data["entityCards"] = entity_cards_data.get("cards", [])

        return case_data

    def _build_expand_params(self, expand: list[str] | None) -> dict | None:
        """Build explicit expand query parameters.

        Rules:
            - None or empty list → no expand query.
            - ["*"] → expand all fields.
            - ["field1", "field2"] → expand selected fields only.

        Returns:
            dict | None: {"expand": "a,b"} or None

        """
        if not expand:
            return None

        return {"expand": ",".join(expand)}

    def get_attachments_metadata(self) -> requests.Response:
        """Get attachments metadata."""
        endpoint: str = f"/cases/{self.params.case_id}/caseComments"
        query_params = {
            "$expand": "caseAttachment",
            "$filter": ("caseAttachment/fileName ne null and caseAttachment/fileType ne null and isDeleted eq false"),
        }
        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    def add_attachment_to_case_wall(self) -> requests.Response:
        """Add attachment to case wall."""
        endpoint: str = "/legacySdk:legacyAddAttachment"
        return self._make_request(
            HttpMethod.POST,
            endpoint,
            json_payload=self.params.attachment.__dict__,
            params={"format": "snake"},
        )

    def create_entity(self) -> requests.Response:
        """Create entity using ExtendCaseGraph."""
        endpoint: str = "/legacyCases:investigatorExtendCaseGraph"
        return self._make_request(
            HttpMethod.POST,
            endpoint,
            json_payload=self.params.entity_to_create.to_json(),
        )

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def import_simulator_custom_case(self) -> requests.Response:
        """Import Simulated Custom Case."""
        endpoint: str = "/legacyCases:importCustomCase"
        return self._make_request(
            HttpMethod.POST,
            endpoint,
            json_payload=self.params.simulated_case_data,
        )

    def add_or_update_case_task_v5(self) -> requests.Response:
        """Add or Update Case Task for Platform version 5."""
        endpoint: str = "/tasks"
        payload = {
            "title": self.params.title,
            "content": self.params.content,
            "dueTime": self.params.due_date_unix_in_ms,
            "assignee": self.params.owner,
            "caseId": self.params.case_id,
        }
        return self._make_request(
            HttpMethod.POST,
            endpoint,
            json_payload=payload,
        )

    def add_or_update_case_task_v6(self) -> requests.Response:
        """Add or Update Case Task for Platform version 6."""
        endpoint: str = "/legacySdk:legacyAddOrUpdateCaseTask"
        payload = {
            "owner": self.params.owner,
            "content": self.params.content,
            "dueDate": "",
            "dueDateUnixTimeMs": self.params.due_date_unix_in_ms,
            "title": self.params.title,
            "caseId": self.params.case_id,
        }
        return self._make_request(
            HttpMethod.POST,
            endpoint,
            json_payload=payload,
        )

    def attach_playbook_to_the_case(self) -> requests.Response:
        """Attach playbook to the case."""
        endpoint: str = "/legacyPlaybooks:legacyAttachWorkflowToCase"
        payload = {
            "cyberCaseId": self.params.case_id,
            "alertGroupIdentifier": self.params.alert_group_identifier,
            "alertIdentifier": self.params.alert_identifier,
            "shouldRunAutomatic": self.params.should_run_automatic,
            "wfName": self.params.playbook_name,
        }
        return self._make_request(
            HttpMethod.POST,
            endpoint,
            json_payload=payload,
            params={"format": "camel"},
        )

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def search_cases_by_everything(self) -> list[SingleJson]:
        """
        Retrieves all cases using the legacy search endpoint.

        Returns:
            list[SingleJson]: The complete set of cases found.
        """
        all_cases = []
        page_number = 0
        has_more_pages = True

        # Make a copy to avoid mutating the instance-wide search_payload
        request_payload = self.params.search_payload.copy()

        # Making sure that there is a page_size set, default to 50
        page_size = request_payload.get("pageSize", 50)

        while has_more_pages:
            request_payload.update({
                "requestedPage": page_number,
                "pageSize": page_size,
            })

            try:
                response = self._make_request(
                    HttpMethod.POST,
                    "/legacySearches:legacyCaseSearchEverything",
                    json_payload=request_payload,
                    params={"format": "camel"},
                )
                response.raise_for_status()
                payload = response.json()
            except Exception as e:
                self.chronicle_soar.LOGGER.error(f"Request failed at page {page_number}: {e}")
                return all_cases

            results = payload.get("results", [])
            if results:
                all_cases.extend(results)

            has_more_pages = bool(results) and len(all_cases) < payload.get("totalCount", 0)
            page_number += 1

        return all_cases

    def get_case_activities(self) -> requests.Response:
        """Get case activities using 1P API."""
        endpoint: str = f"/cases/{self.params.case_id}/activities"
        query_params: SingleJson = self.params.query_params or {}
        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    def get_cases_by_timestamp_filter(self) -> list[SingleJson]:
        """Get cases by timestamp filter."""
        environment = "".join(self.params.environment)
        filter_string = f"updateTime gt {self.params.start_time} and environment eq '{environment}'"
        if getattr(self.params, "case_ids", []) and self.params.case_ids:
            ids_filter: str
            ids_filter = ", ".join([str(case_id) for case_id in self.params.case_ids])
            case_ids_filter: str = f"id in ({ids_filter})"
            filter_string += f" and ({case_ids_filter})"

        base_endpoint = "/cases"
        initial_endpoint = (
            f"{base_endpoint}?$filter={filter_string}"
            "&$select=id, updateTime"
            "&$expand=tags"
            f"&pageSize={_PAGE_SIZE}"
            "&$orderBy=updateTime asc"
        )
        return self._paginate_results(initial_endpoint=initial_endpoint, root_response_key="cases")

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_system_version(self) -> requests.Response:
        """Get system version"""
        endpoint = "/legacySystem:legacyGetSystemVersion"
        return self._make_request(HttpMethod.GET, endpoint)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_environment_group_names(self) -> requests.Response:
        """Get environment group names"""
        endpoint = "/environmentGroups"
        return self._make_request(HttpMethod.GET, endpoint)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_env_dynamic_parameters(self) -> list[SingleJson]:
        """Get env dynamic parameters"""
        endpoint = f"/settings/dynamicParameters?pageSize={_PAGE_SIZE}"
        return self._paginate_results(initial_endpoint=endpoint, root_response_key="dynamicParameters")

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def add_dynamic_env_param(self) -> requests.Response:
        """Add dynamic env param"""
        endpoint = "/settings/dynamicParameters"
        payload = {
            "name": self.params.name,
            "displayName": self.params.display_name,
            "parameterType": self.params.parameter_type,
            "defaultValue": self.params.default_value,
            "optionalValuesJson": str(self.params.optional_json),
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def add_tags_to_case_in_bulks(self) -> requests.Response:
        """Add tags to case in bulk"""
        endpoint = "/cases:executeBulkAddTag"
        payload = {
            "propertiesStatus": {
                "additionalProp1": 0,
                "additionalProp2": 0,
                "additionalProp3": 0,
            },
            "displayName": self.params.name,
            "parameterType": self.params.type,
            "defaultValue": self.params.default_value,
            "optionalValuesJson": str(self.params.optional_json),
        }
        return self._make_request(HttpMethod.PATCH, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def install_integration(self) -> requests.Response:
        """Install integration"""
        endpoint = f"/marketplaceIntegrations/{self.params.integration_identifier}:install"
        payload = {
            "overrideMapping": self.params.override_mapping,
            "staging": self.params.stage,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def export_package(self) -> requests.Response:
        """Export package"""
        endpoint = (
            f"/download/integrations/{self.params.integration_identifier}:"
            "export?alt=media"
        )
        return self._make_request(HttpMethod.GET, endpoint).content

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_integration_instance_settings(self) -> requests.Response:
        """Get integration instance settings"""
        endpoint = (
            f"/integrations/{self.params.integration_identifier}/integrationInstances/"
            f"{self.params.instance_id}"
        )
        return self._make_request(HttpMethod.GET, endpoint)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def create_integrations_instance(self) -> requests.Response:
        """Create integrations instance"""
        endpoint = (
            f"/integrations/{self.params.integration_identifier}/integrationInstances"
        )
        payload = {"environment": self.params.environment}
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_domains(self) -> list[SingleJson]:
        """Get domains."""
        endpoint = f"/system/settings/domains?pageSize={_PAGE_SIZE}"
        return self._paginate_results(initial_endpoint=endpoint, root_response_key="domains")

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def update_domain(self) -> requests.Response:
        """Update domain"""
        endpoint = "/system/settings/domains"
        payload = self.params.domain_data
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_environment_names(self) -> list[str]:
        """Get environment names."""
        environments = self.get_environments()
        return [env.get("displayName") for env in environments]

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_environments(self) -> list[SingleJson]:
        """Get environments."""
        endpoint = f"/system/settings/environments?pageSize={_PAGE_SIZE}"
        return self._paginate_results(initial_endpoint=endpoint, root_response_key="environments")

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def import_environment(self) -> requests.Response:
        """Import environment"""
        endpoint = (
            "/system/settings/environments"
        )
        payload = self.params.environment_data
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def save_integration_instance_settings(self) -> requests.Response:
        """Save integration instance settings"""
        endpoint = f"/integrations/{self.params.integration_identifier}/integrationInstances/{self.params.identifier}"
        payload = self.params.integration_data
        return self._make_request(HttpMethod.PATCH, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def import_simulated_case(self) -> requests.Response:
        """Update domain"""
        endpoint = "/legacyCases:importCustomCase"
        payload = self.params.case_data
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def add_case_tag(self) -> requests.Response:
        """Add case tag"""
        endpoint = "/system/settings/caseTagDefinitions"
        payload = self.params.case_tag
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def update_case_tag(self) -> requests.Response:
        """Update case tag"""
        case_tag = self.params.case_tag
        existing_case_tag = self.params.existing_case_tag
        resource_name = existing_case_tag.get("name")
        if resource_name:
            clean_path = self._clean_resource_name(resource_name)
            endpoint = f"/{clean_path}"
            return self._make_request(
                HttpMethod.PATCH, endpoint, json_payload=case_tag
            )

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def add_case_stage(self) -> requests.Response:
        """Add case stage"""
        endpoint = "/system/settings/caseStageDefinitions"
        payload = self.params.case_stage
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_case_alert(self) -> requests.Response:
        """Get case alert"""
        endpoint = "/system/settings/caseCloseDefinitions"
        return self._make_request(HttpMethod.GET, endpoint)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def add_close_reason(self) -> requests.Response:
        """Add close reason"""
        endpoint = "/system/settings/caseCloseDefinitions"
        payload = self.params.close_reason
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_networks(self) -> list[SingleJson]:
        """Get networks."""
        endpoint = f"/system/settings/networks?pageSize={_PAGE_SIZE}"
        return self._paginate_results(initial_endpoint=endpoint, root_response_key="networks")

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def update_network(self) -> requests.Response:
        """Update network"""
        endpoint = "/system/settings/networks"
        payload = self.params.network_data
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_custom_lists(self) -> list[SingleJson]:
        """Get custom lists."""
        endpoint = f"/system/settings/customLists?pageSize={_PAGE_SIZE}"
        return self._paginate_results(initial_endpoint=endpoint, root_response_key="customLists")

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def update_custom_list(self) -> requests.Response:
        """Update custom list"""
        endpoint = "/system/settings/customLists"
        payload = self.params.tracking_list
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def update_blocklist(self) -> requests.Response:
        """Update blocklist"""
        endpoint = "/entitiesBlocklists"
        payload = self.params.blocklist_data
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def update_sla_record(self) -> requests.Response:
        """Update sla record"""
        endpoint = "/system/settings/slaDefinitions"
        payload = self.params.sla_data
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def save_playbook(self) -> requests.Response:
        """Save playbook"""
        endpoint = "/legacyPlaybooks:legacySaveWorkflowDefinitions"
        payload = self.params.playbook_data
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_playbooks_workflow_menu_cards(self) -> requests.Response:
        """Get playbooks workflow menu cards."""
        endpoint: str = "/legacyPlaybooks:legacyGetWorkflowMenuCards"
        payload: list[int] = self.params.api_payload
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_playbooks_workflow_menu_cards_with_env(self) -> requests.Response:
        """Get playbooks workflow menu cards with environment filter."""
        endpoint: str = "/legacyPlaybooks:legacyGetWorkflowMenuCardsWithEnvFilter"
        payload: list[int] = self.params.api_payload
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_playbook_workflow_menu_cards_by_identifier(self) -> requests.Response:
        """Get playbook workflow menu cards by identifier."""
        endpoint: str = (
            "/legacyPlaybooks:legacyGetWorkflowFullInfoByIdentifier"
            f"?WorkflowIdentifier={self.params.playbook_identifier}"
        )
        return self._make_request(HttpMethod.GET, endpoint)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_playbook_workflow_menu_cards_by_identifier_with_env(
            self,
    ) -> requests.Response:
        """Get playbook workflow menu cards by identifier with environment filter."""
        endpoint: str = (
            "/legacyPlaybooks:legacyGetWorkflowFullInfoWithEnvFilterByIdentifier?"
            f"WorkflowIdentifier={self.params.playbook_identifier}"
        )
        return self._make_request(HttpMethod.GET, endpoint)

    def _enrich_connector_instances_with_params(
        self,
        response_json: SingleJson
    ) -> list[SingleJson]:
        """Helper to add parameters to a list of connector instances."""
        instances = (
                response_json.get("connector_instances")
                or response_json.get("connectorInstances", [])
        )
        connector_names = [item['name'] for item in instances]

        detailed_data_list = []
        for name in connector_names:
            clean_path = self._clean_resource_name(name)
            detail_response = self._make_request(HttpMethod.GET, f"/{clean_path}")
            if detail_response.status_code == 200:
                data = detail_response.json()
                data["params"] = data["parameters"]
                detailed_data_list.append(data)
            else:
                self.chronicle_soar.LOGGER.error(f"Failed to fetch details for {name}") #QA fixes

        return detailed_data_list

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_installed_connectors(self) -> requests.Response:
        """Get installed connectors."""
        instance_id: str = getattr(self.params, "connector_instance_id", None)
        endpoint: str = "/integrations/-/connectors/-/connectorInstances"

        if instance_id:
            endpoint += f"/{instance_id}"
            return self._make_request(HttpMethod.GET, endpoint)

        endpoint_with_page_size = f"{endpoint}?pageSize={_PAGE_SIZE}"

        results = self._paginate_results(
            initial_endpoint=endpoint_with_page_size,
            root_response_key="connector_instances"
        )

        return self._enrich_connector_instances_with_params({"connector_instances": results}) #QA fixes

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_connector_params(self) -> requests.Response:
        """Get connector cards using legacy API"""
        endpoint = (
            f"/integrations/{self.params.integration_name}"
            "/connectors/-/connectorInstances"
        )
        response = self._make_request(HttpMethod.GET, endpoint)
        response.raise_for_status()
        response_json = response.json()

        instances = (
                response_json.get("connector_instances")
                or response_json.get("items")
                or response_json.get("connectorInstances", [])
        )

        for instance in instances:
            instance_name = instance.get("name")
            if instance_name:
                try:
                    details_response = self._make_request(
                        HttpMethod.GET, f"/{instance_name}"
                    )
                    if details_response.status_code == 200:
                        details = details_response.json()
                        instance["parameters"] = details.get("parameters", [])
                    else:
                        instance["parameters"] = []
                except Exception:
                    instance["parameters"] = []

        new_response = requests.Response()
        new_response.status_code = 200
        new_response.headers["Content-Type"] = "application/json"
        new_response._content = json.dumps(response_json).encode("utf-8")
        return new_response

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_visual_families(self) -> list[SingleJson]:
        """Get custom visual families."""
        endpoint = f"/ontologyRecords/-/visualFamilies?pageSize={_PAGE_SIZE}"
        return self._paginate_results(initial_endpoint=endpoint, root_response_key="visualFamilies")

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_visual_family_by_id(self) -> requests.Response:
        """Get custom visual family by ID."""
        endpoint = f"/ontologyRecords/-/visualFamilies/{self.params.family_id}"
        return self._make_request(HttpMethod.GET, endpoint)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_case_tags(self) -> list[SingleJson]:
        """Get case tags."""
        endpoint = f"/system/settings/caseTagDefinitions?pageSize={_PAGE_SIZE}"
        return self._paginate_results(initial_endpoint=endpoint, root_response_key="case_tag_definitions")

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_case_stages(self) -> list[SingleJson]:
        """Get case stages."""
        endpoint = f"/system/settings/caseStageDefinitions?pageSize={_PAGE_SIZE}"
        return self._paginate_results(initial_endpoint=endpoint, root_response_key="case_stage_definitions")

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_case_close_reasons(self) -> list[SingleJson]:
        """Get case close reasons."""
        endpoint = f"/system/settings/caseCloseDefinitions?pageSize={_PAGE_SIZE}"
        return self._paginate_results(initial_endpoint=endpoint, root_response_key="caseCloseDefinitions")

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_block_lists_details(self) -> requests.Response:
        """Get block lists details"""
        endpoint = "/system/settings/soar-block-entities"
        return self._make_request(HttpMethod.GET, endpoint)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_sla_records(self) -> list[SingleJson]:
        """Get sla records."""
        endpoint = f"/system/settings/slaDefinitions?pageSize={_PAGE_SIZE}"
        return self._paginate_results(initial_endpoint=endpoint, root_response_key="slaDefinitions")

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_all_model_block_records(self) -> requests.Response:
        """Get all model block records."""
        endpoint: str = "/entitiesBlocklists"
        return self._make_request(HttpMethod.GET, endpoint)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_company_logo(self) -> requests.Response:
        """Get company logo."""
        endpoint: str = "/moduleSettings/CompanySetting/properties"
        return self._make_request(HttpMethod.GET, endpoint)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_case_title_settings(self) -> requests.Response:
        """Get case title settings."""
        endpoint: str = "/moduleSettings/CaseTitleSettings/properties/"
        return self._make_request(HttpMethod.GET, endpoint)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def save_case_title_settings(self) -> requests.Response:
        """Save case title settings."""
        endpoint: str = (
            f"/moduleSettings/CaseTitleSettings/properties/{self.params.display_name}"
        )
        payload = {
            "name": self.params.name,
            "displayName": self.params.display_name,
            "type": self.params.type,
            "value": self.params.value,
        }
        return self._make_request(HttpMethod.PATCH, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def add_or_update_company_logo(self) -> requests.Response:
        """Add or update company logo."""
        prop_name = self.params.company_logo.get("displayName") or self.params.company_logo.get("name") or "CompanyLogo"
        endpoint: str = f"/moduleSettings/CompanySetting/properties/{prop_name}"
        payload = self.params.company_logo
        return self._make_request(HttpMethod.PATCH, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def attache_workflow_to_case(self) -> requests.Response:
        """Attache workflow to case."""
        endpoint: str = "/legacyPlaybooks:legacyAttachWorkflowToCase"
        payload = {
            "cyberCaseId": self.params.case_id,
            "alertGroupIdentifier": self.params.alert_group_identifier,
            "alertIdentifier": self.params.alert_identifier,
            "wfName": self.params.wf_name,
            "shouldRunAutomatic": True,
            "originalWorkflowDefinitionIdentifier": self.params.original_wf_identifier,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def import_custom_case(self) -> requests.Response:
        """Import custom case."""
        endpoint: str = "/legacyCases:importCustomCase"
        payload = self.params.case_data
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def case_search_everything(self) -> requests.Response:
        """Case search everything."""
        endpoint: str = "/legacySearches:legacyCaseSearchEverything"
        payload = self.params.search_data
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_environment_action_definition(self) -> requests.Response:
        """Get environment action definition."""
        endpoint: str = "/legacySoarSettings:legacyGetEnvironmentActionDefinitions"
        payload = self.params.environment_action_data
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def export_simulated_case(self) -> requests.Response:
        """Export simulated cases"""
        name = self.params.name
        endpoint = f"/legacySoarCases:exportCustomCase/{name}"
        return self._make_request(HttpMethod.GET, endpoint)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_bearer_token(self) -> requests.Response:
        """Get bearer token."""
        endpoint = "/auth/login"
        payload = {
            "password": self.params.smp_password,
            "username": self.params.smp_username,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def update_api_record(self) -> requests.Response:
        """Update api record."""
        endpoint = "/settings/addOrUpdateAPIKeyRecord"
        return self._make_request(
            HttpMethod.POST, endpoint, json_payload=self.params.api_record
        )

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_store_data(self) -> SingleJson:
        """Get store data."""
        endpoint = f"/marketplaceIntegrations?pageSize={_PAGE_SIZE}"
        results = self._paginate_results(initial_endpoint=endpoint, root_response_key="marketplaceIntegrations")
        return {"marketplaceIntegrations": results}

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def import_package(self) -> requests.Response:
        """Import package."""
        staging_val = "true" if getattr(self.params, "staging", False) else "false"
        endpoint = "/upload/integrations:import"
        url = f"{get_sdk_api_uri(self.chronicle_soar)}{endpoint}"
        url = re.sub(
            r'(https?://[^/]+/)(v[a-zA-Z0-9]+/)(.*)/upload/(.*)',
            r'\1upload/\2\3/\4',
            url
        )
        self.chronicle_soar.LOGGER.info(f"Calling API endpoint: {url}")

        params = {
            "uploadType": "media",
            "staging": staging_val,
        }
        headers = {
            "Content-Type": "application/octet-stream",
        }
        binary_data = self.params.b64_blob

        zip_filename = self.params.integration_name + ".zip"

        metadata = {
                "integration": {
                    "displayName": self.params.integration_name
                },
                "staging": getattr(self.params, "staging", False),
                "Staging": getattr(self.params, "staging", False)
            }
        m = MultipartEncoder(
            fields={
                'metadata': ('metadata', json.dumps(metadata), 'application/json; charset=UTF-8'),
                'file': (zip_filename, binary_data, 'application/zip')
            },
            boundary='----WebKitFormBoundaryYOURBOUNDARY'
        )

        headers = {
            "Content-Type": m.content_type,
        }

        return self.chronicle_soar.session.request(
            "POST",
            url,
            params=params,
            data=m,
            headers=headers,
        )

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def update_ide_item(self) -> requests.Response:
        """Update ide item."""
        endpoint = "/ide/AddOrUpdateItem"
        return self._make_request(
            HttpMethod.POST, endpoint, json_payload=self.params.input_json
        )

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_ide_cards(self) -> requests.Response:
        """Get ide cards (1P compatible)."""

        class _DictResponse:
            def __init__(self, payload: dict):
                self._payload = payload
                self.status_code = 200

            def json(self):
                """
                Must ALWAYS return: list[dict]
                so this keeps working safely:
                    for x in response.json():
                        x.get(...)
                """
                if not self._payload:
                    return []

                cards = self._payload.get("cards", [])
                if isinstance(cards, list):
                    return cards

                return []

            def raise_for_status(self):
                return None

        connectors_endpoint = "/integrations/{identifier}/connectors"
        actions_endpoint = "/integrations/{identifier}/actions"
        jobs_endpoint = "/integrations/{identifier}/jobs"
        managers_endpoint = "/integrations/{identifier}/managers"

        cards: list[dict] = []

        connectors_response = self._make_request(
            HttpMethod.GET,
            connectors_endpoint.format(identifier=self.params.integration_name),
        )
        connectors_data = safe_json_for_204(connectors_response, default_for_204={})
        cards.extend(connectors_data.get("connectors", []))

        actions_response = self._make_request(
            HttpMethod.GET,
            actions_endpoint.format(identifier=self.params.integration_name),
        )
        actions_data = safe_json_for_204(actions_response, default_for_204={})
        cards.extend(actions_data.get("actions", []))

        jobs_response = self._make_request(
            HttpMethod.GET,
            jobs_endpoint.format(identifier=self.params.integration_name),
        )
        jobs_data = safe_json_for_204(jobs_response, default_for_204={})
        cards.extend(jobs_data.get("jobs", []))

        managers_response = self._make_request(
            HttpMethod.GET,
            managers_endpoint.format(identifier=self.params.integration_name),
        )
        managers_data = safe_json_for_204(managers_response, default_for_204={})
        cards.extend(managers_data.get("managers", []))

        payload = {
            "cards": [
                {
                    "identifier": self.params.integration_name,
                    "cards": cards,
                }
            ]
        }

        return _DictResponse(payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_ide_item(self) -> requests.Response:
        """Get ide item."""
        endpoint = "/ide/GetIdeItem"
        query = {
            "itemId": self.params.item_id,
            "ideItemType": self.params.item_type,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=query)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def set_mappings_visual_family(self) -> requests.Response:
        """Set mappings visual family."""
        endpoint = "/ontologyRecords/*/mappingRules:family"
        payload = {
            "source": self.params.source,
            "product": self.params.product or "",
            "eventName": self.params.event_name,
            "visualFamily": self.params.visual_family,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def export_playbooks(self) -> requests.Response:
        """Export playbooks."""
        endpoint = "/legacyPlaybooks:legacyExportDefinitions"
        payload = {"identifiers": self.params.definitions}
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def import_playbooks(self) -> requests.Response:
        """Import playbooks."""
        endpoint = "/legacyPlaybooks:legacyImportDefinitions"
        return self._make_request(
            HttpMethod.POST, endpoint, json_payload=self.params.playbooks
        )

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def create_playbook_category(self) -> requests.Response:
        """Create playbook category."""
        endpoint = "/legacyPlaybooks:legacyAddOrUpdatePlaybookCategory"
        req = {
            "categoryState": 0,
            "id": 0,
            "isDefaultCategory": False,
            "name": self.params.name,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=req)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_playbook_categories(self) -> requests.Response:
        """Get playbook categories."""
        endpoint = "/legacyPlaybooks:legacyGetWorkflowCategories"
        return self._make_request(HttpMethod.GET, endpoint)


    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def update_connector(self) -> requests.Response:
        """Update connector (Create new instance)."""
        name = self.params.integration_name
        connector = getattr(self.params, "connector_definition_id", None) or self.params.connector_id
        connector_data = self.params.connector_data
        endpoint = f"/integrations/{name}/connectors/{connector}/connectorInstances/"
        return self._make_request(
            HttpMethod.POST, endpoint, json_payload=connector_data
        )

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def update_existing_connector(self) -> requests.Response:
        """Update existing connector."""
        connector_data = self.params.connector_data
        existing_connector = self.params.existing_connector
        resource_name = existing_connector.get("name")
        if resource_name:
            clean_path = self._clean_resource_name(resource_name)
            endpoint = f"/{clean_path}"
            return self._make_request(
                HttpMethod.PATCH, endpoint, json_payload=connector_data
            )
        raise Exception("Existing connector has no resource name")

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def add_job(self) -> requests.Response:
        """Add job."""
        integration = self.params.integration_name
        job_data = self.params.job

        job_id = getattr(self.params, "job_definition_id", None)

        if not job_id:
            job_id = job_data.get("jobDefinitionId")

        if not job_id:
            job_full_name = self.params.job_name
            try:
                job_id = job_full_name.split("jobs/")[1].split("/")[0]
            except (IndexError, AttributeError):
                job_id = job_full_name

        endpoint = f"/integrations/{integration}/jobs/{job_id}/jobInstances/"
        return self._make_request(HttpMethod.POST, endpoint, json_payload=job_data)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def update_job_instance(self) -> requests.Response:
        """Update job instance."""
        resource_name = self.params.job_instance_name
        clean_path = self._clean_resource_name(resource_name)
        endpoint = f"/{clean_path}"
        return self._make_request(HttpMethod.PATCH, endpoint, json_payload=self.params.job)


    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def add_email_template(self) -> requests.Response:
        """Add email template."""
        endpoint = "/system/settings/emailTemplates"
        return self._make_request(
            HttpMethod.POST, endpoint, json_payload=self.params.template
        )

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def update_email_template(self) -> requests.Response:
        """Update email template."""
        template = self.params.template
        existing_template = self.params.existing_template
        resource_name = existing_template.get("name")
        if resource_name:
            clean_path = self._clean_resource_name(resource_name)
            endpoint = f"/{clean_path}"
            return self._make_request(
                HttpMethod.PATCH, endpoint, json_payload=template
            )
        raise Exception("Existing email template has no resource name")

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_denylists(self) -> list[SingleJson]:
        """Get denylists."""
        endpoint = f"/system/settings/soarBlockEntities?pageSize={_PAGE_SIZE}"
        if self.params.is_expand:
            endpoint += "&expand=*"
        return self._paginate_results(initial_endpoint=endpoint, root_response_key="soar_block_entities")

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_simulated_cases(self) -> list[SingleJson]:
        """Get simulated cases."""
        endpoint = f"/legacyCases:getCustomCases?pageSize={_PAGE_SIZE}"
        response = self._make_request(HttpMethod.GET, endpoint)
        response.raise_for_status()
        try:
            response_data = response.json()
        except Exception:
            return []

        if isinstance(response_data, list):
            return response_data

        all_records = []
        current_records = response_data.get("custom_cases")
        if current_records is None:
            current_records = response_data.get("customCases", [])
        all_records.extend(current_records)

        next_token = response_data.get("nextPageToken")
        while next_token:
            endpoint_with_token = f"{endpoint}&pageToken={next_token}"
            try:
                page_response = self._make_request(HttpMethod.GET, endpoint_with_token)
                page_response.raise_for_status()
                page_data = page_response.json()
            except Exception:
                break

            current_records = page_data.get("custom_cases")
            if current_records is None:
                current_records = page_data.get("customCases", [])
            all_records.extend(current_records)
            next_token = page_data.get("nextPageToken")

        return all_records

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_installed_integrations(self) -> list[SingleJson]:
        """Get installed integrations."""
        endpoint = f"/integrations?pageSize={_PAGE_SIZE}"
        return self._paginate_results(initial_endpoint=endpoint, root_response_key="integrations")

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_case_close_comment(self, case_id: str | int) -> requests.Response:
        """Get case closure comment.

        Args:
            case_id (str | int): The ID of the case for which to retrieve the closure comment.

        Returns:
            requests.Response: The response object containing the closure comment details.

        """
        endpoint = f"/cases/{case_id}/caseWallRecords"
        params = {
            "$filter": "(activityType eq 'CASE_STATUS_CHANGE') and (activityKind eq 'CASE_CLOSED')",
            "$orderBy": "createTime desc",
            "$pageSize": 1,
        }
        return self._make_request(method=HttpMethod.GET, endpoint=endpoint, params=params)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def add_mapping_rules(self) -> requests.Response:
        """Add mapping rules."""
        endpoint = f"/ontologyRecords/{self.params.mr_id}/mappingRules:save"

        rules = self.params.mapping_rule
        if isinstance(rules, dict):
            if "mappingRules" in rules and isinstance(rules["mappingRules"], list):
                rules = rules["mappingRules"]
            elif "mapping_rules" in rules and isinstance(rules["mapping_rules"], list):
                rules = rules["mapping_rules"]
            elif "items" in rules and isinstance(rules["items"], list):
                rules = rules["items"]
            else:
                rules = [rules]
        elif not isinstance(rules, list):
            rules = [rules]

        last_response = None
        for rule_item in rules:
            rule_data = rule_item.get("mappingRule", {}) if isinstance(rule_item, dict) else {}

            if rule_data:
                payload = {
                    "securityEventFieldName": rule_data.get("securityEventFieldName"),
                    "transformationFunction": rule_data.get("transformationFunction"),
                    "transformationFunctionParam": rule_data.get("transformationFunctionParam"),
                    "rawDataPrimaryFieldMatchTerm": rule_data.get("rawDataPrimaryFieldMatchTerm") or rule_data.get("securityEventFieldName"),
                    "rawDataPrimaryFieldComparisonType": rule_data.get("rawDataPrimaryFieldComparisonType"),
                    "rawDataSecondaryFieldMatchTerm": rule_data.get("rawDataSecondaryFieldMatchTerm"),
                    "rawDataSecondaryFieldComparisonType": rule_data.get("rawDataSecondaryFieldComparisonType"),
                    "rawDataThirdFieldMatchTerm": rule_data.get("rawDataThirdFieldMatchTerm"),
                    "rawDataThirdFieldComparisonType": rule_data.get("rawDataThirdFieldComparisonType"),
                    "enrichmentFields": rule_data.get("enrichmentFields"),
                    "isArtifact": rule_data.get("isArtifact"),
                    "extractionFunctionParam": rule_data.get("extractionFunctionParam"),
                    "extractionFunction": rule_data.get("extractionFunction"),
                    "ontologyConfigurationLevel": rule_item.get("ontologyConfigurationLevel") or rule_data.get("ontologyConfigurationLevel") or "Source",
                    "targetFieldType": rule_item.get("targetFieldType") or rule_data.get("targetFieldType") or "GeneralField",
                    "eventName": rule_data.get("eventName"),
                }
            else:
                payload = rule_item.copy() if isinstance(rule_item, dict) else rule_item
                if isinstance(payload, dict):
                    if "id" in payload and payload["id"] == 0:
                        payload.pop("id")
                    if "name" in payload and (not payload["name"] or payload["name"].endswith("/0") or "mappingRules/0" in payload["name"]):
                        payload.pop("name")
                    if not payload.get("rawDataPrimaryFieldMatchTerm") and payload.get("securityEventFieldName"):
                        payload["rawDataPrimaryFieldMatchTerm"] = payload["securityEventFieldName"]

            last_response = self._make_request(
                HttpMethod.POST, endpoint, json_payload=payload
            )
            last_response.raise_for_status()

        return last_response

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_ontology_records(self) -> requests.Response:
        """Get ontology records."""
        endpoint = "/ontologyRecords"
        return self._make_request(HttpMethod.GET, endpoint)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def get_mapping_rules(self) -> requests.Response:
        """Get mapping rules."""
        endpoint = f"/ontologyRecords/{self.params.mr_id}/mappingRules"
        return self._make_request(HttpMethod.GET, endpoint)

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def add_custom_family(self) -> requests.Response:
        """Add custom visual family."""
        endpoint = f"/ontologyRecords/{self.params.mr_id}/visualFamilies"

        family_data = self.params.visual_family
        if isinstance(family_data, dict) and "visualFamilyDataModel" in family_data:
            family_data = family_data["visualFamilyDataModel"]

        if isinstance(family_data, dict) and "rules" in family_data:
            family_data["modelingRules"] = family_data.pop("rules")

        return self._make_request(
            HttpMethod.POST, endpoint, json_payload=family_data
        )

    @temporarily_remove_header(DATAPLANE_1P_HEADER)
    def update_visual_family(self) -> requests.Response:
        """Update custom visual family."""
        family_data = self.params.visual_family
        existing_vf = self.params.existing_vf
        mr_id = self.params.mr_id

        resource_name = existing_vf.get("name")
        if not resource_name:
            vf_id = existing_vf.get("id")
            if vf_id and mr_id:
                resource_name = f"projects/project/locations/location/instances/instance/ontologyRecords/{mr_id}/visualFamilies/{vf_id}"

        if resource_name:
            clean_path = self._clean_resource_name(resource_name)
            endpoint = f"/{clean_path}"

            if isinstance(family_data, dict) and "visualFamilyDataModel" in family_data:
                family_data = family_data["visualFamilyDataModel"]

            if isinstance(family_data, dict) and "rules" in family_data:
                family_data["modelingRules"] = family_data.pop("rules")

            return self._make_request(
                HttpMethod.PATCH, endpoint, json_payload=family_data
            )
        raise Exception("Existing visual family has no resource name and cannot be constructed")
