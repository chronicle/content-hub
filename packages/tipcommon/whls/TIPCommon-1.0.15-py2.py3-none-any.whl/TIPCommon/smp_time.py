
import datetime

from .consts import (
    NUM_OF_HOURS_IN_DAY,
    NUM_OF_MILLI_IN_SEC,
    DATETIME_FORMAT,
    UNIX_FORMAT,
    TIMEOUT_THRESHOLD
)

from SiemplifyUtils import (
    convert_datetime_to_unix_time,
    convert_string_to_unix_time,
    unix_now,
    utc_now
)


def validate_timestamp(
    last_run_timestamp,
    offset_in_hours,
    offset_is_in_days=False
):
    """Validates timestamp in range.

    Args:
        last_run_timestamp (datetime): The last run timestamp.
        offset_in_hours (int): The time limit in hours.
        offset_is_in_days (bool, optional): Whether the offset is in days. Defaults to False.

    Raises:
        ValueError: If the timestamp is not valid.

    Returns:
        datetime: The validated timestamp.
    """

    current_time = utc_now()

    if offset_is_in_days:
        offset_in_hours = offset_in_hours * NUM_OF_HOURS_IN_DAY

    if current_time - last_run_timestamp > datetime.timedelta(
        hours=offset_in_hours
    ):
        return current_time - datetime.timedelta(hours=offset_in_hours)
    else:
        return last_run_timestamp


def save_timestamp(
    siemplify,
    alerts,
    timestamp_key='timestamp',
    incrementation_value=0,
    log_timestamp=True,
    convert_timestamp_to_micro_time=False,
    convert_a_string_timestamp_to_unix=False
):
    """Saves last timestamp for given alerts.

    Args:
        siemplify (obj): An instance of the SDK `SiemplifyConnectorExecution` class.
        alerts (dict): The list of alerts to find the last timestamp.
        timestamp_key (str, optional): The key for getting timestamp from alert. Defaults to 'timestamp'.
        incrementation_value (int, optional): The value to increment last timestamp by milliseconds. Defaults to 0.
        log_timestamp (bool, optional): Whether log timestamp or not. Defaults to True.
        convert_timestamp_to_micro_time (bool, optional): Whether to convert timestamp to micro time. Defaults to False.
        convert_a_string_timestamp_to_unix (bool, optional): Whether to convert a string timestamp to unix. Defaults to False.

    Returns:
        bool: Whether the timestamp is updated.
    """

    if not alerts:
        siemplify.LOGGER.info(
            'Timestamp is not updated since no alerts fetched'
        )
        return False

    if convert_a_string_timestamp_to_unix:
        alerts = sorted(
            alerts,
            key=lambda alert: convert_string_to_unix_time(
                getattr(alert, timestamp_key)
            )
        )
        last_timestamp = convert_string_to_unix_time(
            getattr(alerts[-1], timestamp_key)
        ) + incrementation_value
    else:
        alerts = sorted(
            alerts,
            key=lambda alert: int(getattr(alert, timestamp_key))
        )
        last_timestamp = int(
            getattr(alerts[-1], timestamp_key)
        ) + incrementation_value

    last_timestamp = last_timestamp * NUM_OF_MILLI_IN_SEC if convert_timestamp_to_micro_time else last_timestamp
    if log_timestamp:
        siemplify.LOGGER.info('Last timestamp is :{}'.format(last_timestamp))

    siemplify.save_timestamp(new_timestamp=last_timestamp)
    return True


def get_last_success_time(
    siemplify,
    offset_with_metric,
    time_format=DATETIME_FORMAT,
    print_value=True,
    microtime=False
):
    """Get last success time datetime.

    Args:
        siemplify (obj): An instance of the SDK SiemplifyConnectorExecution class.
        offset_with_metric (dict): The metric and value. Ex: {'hours': 1}
        time_format (int): The format of the output time. Ex: DATETIME, UNIX
        print_value (bool, optional): Whether to print the value or not. Defaults to True.
        microtime (bool, optional): Whether to return unix time including microtime. Defaults to False.

    Returns:
        time: The last success time.
    """

    last_run_timestamp = siemplify.fetch_timestamp(datetime_format=True)
    offset = datetime.timedelta(**offset_with_metric)
    current_time = utc_now()
    # Check if first run
    datetime_result = current_time - offset if current_time - last_run_timestamp > offset else last_run_timestamp
    unix_result = convert_datetime_to_unix_time(datetime_result)
    unix_result = unix_result if not microtime else int(
        unix_result / NUM_OF_MILLI_IN_SEC
        )

    if print_value:
        siemplify.LOGGER.info(
            'Last success time. Date time:{}. Unix:{}'.format(
                datetime_result,
                unix_result
            )
        )
    return unix_result if time_format == UNIX_FORMAT else datetime_result


def siemplify_fetch_timestamp(siemplify, datetime_format=False, timezone=False):
    """Fetches timestamp from Siemplify.

    Args:
        siemplify (obj): An instance of the SDK `SiemplifyConnectorExecution` class.
        datetime_format (bool, optional): Whether to return the timestamp in datetime format. Defaults to False.
        timezone (bool, optional): Whether to return the timestamp in UTC timezone. Defaults to False.

    Returns:
        The timestamp.
    """
    last_time = siemplify.fetch_timestamp(
        datetime_format=datetime_format,
        timezone=timezone
    )
    if last_time == 0:
        siemplify.LOGGER.info(
            'Timestamp key does not exist in the database. Initiating with value: 0.'
        )
    return last_time


def siemplify_save_timestamp(
    siemplify,
    datetime_format=False,
    timezone=False,
    new_timestamp=unix_now()
):
    """Saves timestamp to Siemplify.

    Args:
        siemplify (obj): An instance of the SDK `SiemplifyConnectorExecution` class.
        datetime_format (bool, optional): Whether to save the timestamp in datetime format. Defaults to False.
        timezone (bool, optional): Whether to save the timestamp in UTC timezone. Defaults to False.
        new_timestamp (int): The new timestamp to save.

    Returns:
        None
 """
    siemplify.save_timestamp(
        datetime_format=datetime_format,
        timezone=timezone,
        new_timestamp=new_timestamp
    )


def is_approaching_timeout(
    connector_starting_time,
    python_process_timeout,
    timeout_threshold=TIMEOUT_THRESHOLD
):
    """Checks if a timeout is approaching.

    Args:
        connector_starting_time (int): The time the connector started.
        python_process_timeout (int): The maximum amount of time the connector is allowed to run.
        timeout_threshold (float): The threshold at which the connector is considered to be approaching a timeout. Defaults to `TIMEOUT_THRESHOLD`.

    Returns:
        `True` if the connector is approaching a timeout, `False` otherwise.
    """
    processing_time_ms = unix_now() - connector_starting_time
    return processing_time_ms > python_process_timeout * NUM_OF_MILLI_IN_SEC * timeout_threshold
