"""
exceptions
==========

A module containing all constant in use by TIPCommon package,
and common constant used in Marketplace Integrations

Usage Example::

    from TIPCommon.exceptions import ConnectorProcessingError
    raise ConnectorProcessingError('spam and eggs')
"""

class GeneralConnectorException(Exception):
    """ General Connector Exception"""
    ...


class ConnectorValidationError(GeneralConnectorException):
    """ Connector Validation Error"""
    ...


class ConnectorContextError(GeneralConnectorException):
    """ Connector Context Error"""
    ...


class ConnectorSetupError(GeneralConnectorException):
    """ Connector Initialization Error"""
    ...


class ConnectorProcessingError(GeneralConnectorException):
    """ Connector Processing Error"""
    ...

class ParameterValidationError(Exception):
    """Raised when a parameter is invalid."""

    def __init__(self, param_name, value, message, exception=None):
        msg = f"{exception}. {message}" if exception else message
        super().__init__(
            f"Invalid parameter: {param_name}, "
            f"value provided: {value}. "
            f"Error: {msg}"
        )