"""Provides the Legacy API client implementation for interacting with Chronicle SOAR."""

# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from typing import TYPE_CHECKING

from TIPCommon.rest.custom_types import HttpMethod

from .base_soar_api import BaseSoarApi

if TYPE_CHECKING:
    import requests

    from TIPCommon.types import ChronicleSOAR


class LegacySoarApi(BaseSoarApi):
    """Chronicle SOAR API client using legacy endpoints."""

    def save_attachment_to_case_wall(self) -> requests.Response:
        """Save an attachment to the case wall using legacy API."""
        endpoint = "api/external/v1/cases/AddEvidence/"
        payload = {
            "CaseIdentifier": self.params.case_id,
            "Base64Blob": self.params.base64_blob,
            "Name": self.params.name,
            "Description": self.params.description,
            "Type": self.params.file_type,
            "IsImportant": self.params.is_important,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_entity_data(self) -> requests.Response:
        """Get entity data using legacy API."""
        endpoint = "api/external/v1/entities/GetEntityData"
        payload = {
            "entityIdentifier": self.params.entity_identifier,
            "entityType": self.params.entity_type,
            "entityEnvironment": self.params.entity_environment,
            "lastCaseType": self.params.last_case_type,
            "caseDistributionType": self.params.case_distribution_type,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_full_case_details(self) -> requests.Response:
        """Get full case details using legacy API."""
        endpoint = (
            f"api/external/v1/cases/GetCaseFullDetails/{self.params.case_id}"
        )
        query_params = {"format": "snake"}
        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    def get_case_attachments(self) -> requests.Response:
        """Get case attachments using legacy API."""
        endpoint = (
            f"api/external/v1/dynamic-cases/GetWallActivitiesV2/{self.params.case_id}"
        )
        return self._make_request(HttpMethod.GET, endpoint)

    def get_installed_integrations_of_environment(self) -> requests.Response:
        """Get installed integrations of environment using legacy API."""
        endpoint = "api/external/v1/integrations/GetEnvironmentInstalledIntegrations"
        payload = {
            "name": (
                "*"
                if self.params.environment == "Shared Instances"
                else self.params.environment
            )
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_connector_cards(self) -> requests.Response:
        """Get connector cards using legacy API"""
        endpoint = "api/external/v1/connectors/cards"
        query_params = {"format": "snake"}
        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    def get_federation_cases(self) -> requests.Response:
        """Get federation cases using legacy API"""
        endpoint = "api/external/v1/federation/cases"
        params = {"continuationToken": self.params.continuation_token}

        return self._make_request(HttpMethod.GET, endpoint, params=params)

    def patch_federation_cases(self) -> requests.Response:
        """Get federation cases using legacy API"""
        endpoint = "api/external/v1/federation/cases/batch-patch"
        headers = {"AppKey": self.params.api_key} if self.params.api_key else None
        payload = {"cases": self.params.cases_payload }
        return self._make_request(
            HttpMethod.PATCH,
            endpoint,
            json_payload=payload,
            headers=headers,
        )

    def get_workflow_instance_card(self) -> requests.Response:
        """Get workflow instance card using legacy API"""
        endpoint = "api/external/v1/cases/GetWorkflowInstancesCards"
        payload = {
            "caseId": self.params.case_id,
            "alertIdentifier": self.params.alert_identifier,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def pause_alert_sla(self) -> requests.Response:
        """Pause alert sla"""
        endpoint = "api/external/v1/cases/PauseAlertSla"
        payload = {
            "caseId": self.params.case_id,
            "alertIdentifier": self.params.alert_identifier,
            "message": self.params.message,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def resume_alert_sla(self) -> requests.Response:
        """Resume alert sla"""
        endpoint = "api/external/v1/cases/ResumeAlertSla"
        payload = {
            "caseId": self.params.case_id,
            "alertIdentifier": self.params.alert_identifier,
            "message": self.params.message,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_case_overview_details(self) -> requests.Response:
        """Get case overview details"""
        case_id = self.params.case_id
        endpoint = f"api/external/v1/dynamic-cases/GetCaseDetails/{case_id}"
        return self._make_request(HttpMethod.GET, endpoint).json()

    def remove_case_tag(self) -> requests.Response:
        """Remove case tag"""
        endpoint = "api/external/v1/cases/RemoveCaseTag"
        payload = {
            "caseId": self.params.case_id,
            "tag": self.params.tag,
            "alertIdentifier": self.params.alert_identifier,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def change_case_description(self) -> requests.Response:
        """Change case description"""
        endpoint = "api/external/v1/cases/ChangeCaseDescription?format=snake"
        payload = {
            "case_id": self.params.case_id,
            "description": self.params.description,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def set_alert_priority(self) -> requests.Response:
        """Set alert priority"""
        endpoint = "api/external/v1/sdk/UpdateAlertPriority"
        payload = {
            "caseId": self.params.case_id,
            "alertIdentifier": self.params.alert_identifier,
            "priority": self.params.priority,
            "alertName": self.params.alert_name,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def set_case_score_bulk(self) -> requests.Response:
        """Set case score bulk"""
        endpoint = "api/external/v1/sdk/cases/score"
        payload = {
            "caseScores": [
                {
                    "caseId": self.params.case_id,
                    "score": self.params.score,
                }
            ],
        }
        return self._make_request(HttpMethod.PATCH, endpoint, json_payload=payload)

    def get_integration_full_details(self) -> requests.Response:
        """Get integration full details"""
        endpoint = "external/v1/store/GetIntegrationFullDetails"
        payload = {
            "integrationIdentifier": self.params.integration_identifier,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_users_profile(self) -> requests.Response:
        """Get users profile"""
        endpoint = "api/external/v1/settings/GetUserProfiles"
        payload = {
            "searchTerm": self.params.search_term,
            "filterRole": self.params.filter_by_role,
            "requestedPage": self.params.requested_page,
            "pageSize": self.params.page_siz,
            "shouldHideDisabledUsers": self.params.should_hide_disabled_users
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)
