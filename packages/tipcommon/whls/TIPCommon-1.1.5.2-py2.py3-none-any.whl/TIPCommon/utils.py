import inspect
import re
import sys
from typing import Iterable

from .consts import (
    ENTITY_OG_ID_KEY,
    FALSE_VAL_LOWER_STRINGS,
    SIEM_ID_ATTR_KEY,
    TRUE_VAL_LOWER_STRINGS,
    _CAMEL_TO_SNAKE_PATTERN1,
    _CAMEL_TO_SNAKE_PATTERN2,
)


def get_unique_items_by_difference(item_pool, items_to_remove):
    # type: (Iterable, Iterable) -> list
    """Get set difference items from two iterables (item_pool - items_to_remove)

    Args:
        item_pool (Iterable): The item pool to filter from
        items_to_remove (Iterable): The items that should be removed if exist

    Returns:
        list:
            A list containing unique items from item_pool that were not part of
            items_to_remove
    """
    return list(set(item_pool).difference(items_to_remove))


def get_entity_original_identifier(entity):
    """Helper function for getting entity original identifier

    Args:
        entity (Entity): The entity from which function will get original identifier

    Returns:
        str: The original identifier
    """
    return entity.additional_properties.get(ENTITY_OG_ID_KEY, entity.identifier)


def is_test_run(sys_argv):
    """
    Return a boolean value that indicates whether the connector's execution state.

    Args:
        sys_argv (_type_): _description_

    Returns:
        _type_: _description_
    """
    return not (len(sys_argv) < 2 or sys_argv[1] == 'True')


def is_first_run(sys_argv):
    """
    Return a boolean value that indicates whether the action is being
    executed asynchronously.

    Args:
        sys_argv: The command line arguments from the sys module: sys.argv

    Returns:
        True if the action is being executed asynchronously else False.
    """
    return len(sys_argv) < 3 or sys_argv[2] == 'True'


def clean_result(value):
    """
    Strip the value from unnecessary spaces before or after the value.

    Args:
        value (str): The value to clean.

    Returns:
        str: A cleaned version of the original value.

    """
    try:
        return value.strip()
    except Exception:
        return value


def is_python_37():
    """
    Check if the python version of the system is 3.7 or above.

    Args:
        None.

    Returns:
        bool: True if the current python version is at least 3.7.

    """
    return sys.version_info >= (3, 7)


def platform_supports_db(siemplify):
    """
    Check if the platform supports database usage.

    Args:
        siemplify (object): The siemplify SDK object.

    Returns:
        True if the siemplify SDK object has an attribute called
        "set_connector_context_property" or "set_job_context_property".

    """
    return (
        hasattr(siemplify, 'set_job_context_property') or
        hasattr(siemplify, 'set_connector_context_property')
    )


def is_empty_string_or_none(data):
    """
    Check if the data is an 'empty string' or 'None'.

    Args:
        data (str): The data to check.

    Returns:
        bool: True if the supplied data is 'None', or if it only contains an empty string "".

    """

    if data is None or data == "":
        return True
    return False


def cast_keys_to_int(data):
    """
    Cast the keys of a dictionary to integers.

    Args:
        data (dict): The data whose keys will be cast to ints.

    Returns:
        dict: A new dict with its keys as ints.

    """
    return {int(k): v for k, v in data.items()}


def none_to_default_value(value_to_check, value_to_return_if_none):
    """
    Check if the current value is None. If it is, replace it with another value. If not, return the original value.

    Args:
        value_to_check (dict/list/str): The value to check.
        value_to_return_if_none (dict/list/str): The value to return if `value_to_check` is None.

    Returns:
        dict/list/str: The original value of `value_to_check` if it is not None, or `value_to_return_if_none` if it is None.

    """
    if value_to_check is None:
        value_to_check = value_to_return_if_none
    return value_to_check


def camel_to_snake_case(string):
    """
    Convert a camel case string to snake case
    :param string: (str) the string to convert
    :return: (str) the converted string
    """
    string = string.replace(' ', '')
    string = _CAMEL_TO_SNAKE_PATTERN1.sub(r'\1_\2', string)
    return _CAMEL_TO_SNAKE_PATTERN2.sub(r'\1_\2', string).lower()


def is_overflowed(siemplify, alert_info, is_test_run):
    """
    Checks if overflowed.

    Args:
        siemplify: (obj) An instance of the SDK `SiemplifyConnectorExecution` class
        alert_info: (AlertInfo)
        is_test_run: (bool) Whether test run or not.

    Returns:
        `True` if the alert is overflowed, `False` otherwise.
    """
    params = {
        'environment': alert_info.environment,
        'alert_identifier': alert_info.ticket_id,
        'alert_name': alert_info.rule_generator,
        'product': alert_info.device_product
    }

    #   Check if 'siem_alert_id' is a valid argument in the SDK overflow method
    #   un-coupled from SDK version

    try:
        method_args = get_function_arg_names(siemplify.is_overflowed_alert)
        if SIEM_ID_ATTR_KEY in method_args:
            params[SIEM_ID_ATTR_KEY] = getattr(
                alert_info,
                SIEM_ID_ATTR_KEY,
                None
            )

    except Exception as e:
        siemplify.LOGGER.error(
            'Error {e}. {arg_} argument will not be used in Overflow check for alert {alert_id}.'.format(
                arg_=SIEM_ID_ATTR_KEY,
                e=e,
                alert_id=alert_info.ticket_id
            )
        )

    try:
        return siemplify.is_overflowed_alert(**params)

    except Exception as err:
        siemplify.LOGGER.error(
            'Error validation connector overflow, ERROR: {}'.format(err)
        )
        siemplify.LOGGER.exception(err)
        if is_test_run:
            raise

    return False


def get_function_arg_names(func):
    """Retrieves all of the argument names of a specific function.

    Args:
        func: (Callable) The function or method to analyze

    Returns:
        list: All of the argument keys defined in the given fucntion
    """
    if is_python_37():
        method_args = inspect.getfullargspec(func)[0]
    else:
        # Python 2.7 as it is the only other python version supported in
        # SOAR integrations virtual envs.

        method_args = inspect.getargspec(func)[0]
    return method_args


def safe_cast_bool_value_from_str(default_value):
    """Check if a default value is a string containing boolean value

    If it is, convert it to boolean, else return it

    Args:
        default_value: The default value to return if the casting fails

    Returns:
        The casted value or the default value
    """
    if not isinstance(default_value, str):
        return default_value

    lowered = default_value.lower()
    if lowered in TRUE_VAL_LOWER_STRINGS:
        default_value = True

    elif lowered in FALSE_VAL_LOWER_STRINGS:
        default_value = False

    return default_value


def safe_cast_int_value_from_str(default_value):
    """Check if a default value is a string containing integer value

    If it is, convert it to boolean, else return it

    Args:
        default_value: The default value to return if the casting fails

    Returns:
        The casted value or the default value
    """
    if not isinstance(default_value, str):
        return default_value

    try:
        default_value = int(default_value)
    except ValueError:
        # If it's not an int then an error will be raised in the extract
        # method
        pass

    return default_value


def is_valid_email(email_addr):
    """Check if a provided value is a valid email address.

    Args:
        email_addr (str): Email address to check

    Returns:
        bool: True if email is valid else False
    """
    return re.match(
        r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+[.][A-Za-z]{2,}$",
        email_addr
    ) is not None
