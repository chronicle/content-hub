"""Factory for creating SOAR API clients based on platform capabilities."""

# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from typing import TYPE_CHECKING

from TIPCommon.utils import platform_supports_1p_api

from .legacy_soar_api import LegacySoarApi
from .one_platform_soar_api import OnePlatformSoarApi

if TYPE_CHECKING:
    import requests

    from TIPCommon.types import ChronicleSOAR

from typing import Protocol


class SoarApiClient(Protocol):
    """Defines the interface for a SOAR API client.

    This protocol ensures that any SOAR API client implementation will have
    the necessary methods defined.
    """

    def save_attachment_to_case_wall(self) -> requests.Response:
        """Save an attachment to the case wall.

        Parameters for the attachment (like case_id, blob, name, etc.)
        are expected to be set on the client instance's `params` attribute
        before calling this method.
        """
        ...

    def get_entity_data(self) -> requests.Response:
        """Get entity data."""
        ...

    def get_full_case_details(self) -> requests.Response:
        """Get full case details."""
        ...

    def get_case_attachments(self) -> requests.Response:
        """Get case attachments."""
        ...


def get_soar_client(chronicle_soar: ChronicleSOAR) -> SoarApiClient:
    """Get the appropriate SOAR API client based on platform support.

    Args:
        chronicle_soar: The ChronicleSOAR SDK object.

    Returns:
        An instance of a SOAR API client (either OnePlatformSoarApi or LegacySoarApi).

    """
    if platform_supports_1p_api():
        return OnePlatformSoarApi(chronicle_soar)

    return LegacySoarApi(chronicle_soar)
