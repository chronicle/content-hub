# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
data_models
===========

This module contains data classes for representing:
- Data model
- Alerts
- Variable containers
- General parameters
- Connector parameters.

"""

from __future__ import annotations

import dataclasses
import email
import json
from enum import Enum
from typing import Any, Generic, TypeVar

import SiemplifyVault
from SiemplifyConnectorsDataModel import ConnectorContext
from TIPCommon.types import SingleJson


T = TypeVar("T")


class TypedContainer(Generic[T]):
    """Container for a specific type that provides type intellisense"""

    def __init__(self) -> None:
        self._params: dict[str, T] = {}

    def __get__(self, service_name: str, _=None) -> T:
        return self._params.get(service_name)

    def __set__(self, service_name: str, service: T) -> None:
        self._params[service_name] = service

    def __contains__(self, item: Any) -> bool:
        return item in self._params


class BaseDataModel:
    """Represents a base data model. It has the following properties:

    Attributes:
        raw_data: The raw data for the alert.

    The `to_json` method converts the raw data to JSON format as returned from
    `json.loads()`.

    Example:
        >>> from data_models import BaseDataModel
        >>> data = BaseDataModel({'foo': 'bar'})
        >>> data.raw_data
        {'foo': 'bar'}
        >>> data.to_json()
        {'foo': 'bar'}
    """

    def __init__(self, raw_data):
        self.raw_data = raw_data

    def __repr__(self):
        return str(self.raw_data)

    def to_json(self):
        return self.raw_data


class BaseAlert:
    """Represents a base alert. It has the following properties:

    Attributes:
        raw_data: The raw data for the alert.
        alert_id: The ID of the alert.

    The `to_json` method converts the alert to JSON format as returned from
    `json.loads()`.

    Example:
        >>> from data_models import BaseAlert
        >>> alert = BaseAlert({'foo': 'bar'}, 100)
        >>> alert.raw_data
        {'foo': 'bar'}
        >>> alert.alert_id
        100
        >>> alert.to_json()
        {'foo': 'bar'}
    """

    def __init__(self, raw_data, alert_id):
        self.raw_data = raw_data
        self.alert_id = alert_id

    def to_json(self):
        return self.raw_data


class Container:
    """Represents a container for variables.

    Examples:
        >>> from data_models import Container
        >>> container = Container()
        >>> container.one = 1
        >>> container.one
        1
    """

    def __init__(self):
        self._params = {}

    def __get__(self, ins, instype=None):
        return self._params.get(ins)

    def __set__(self, ins, value):
        self._params[ins] = value


class Parameter:
    """A Parent class representing a parameter.

    It has the following properties:

    raw_data: The raw data for the parameter.

    Example:
        >>> from data_models import Parameter
        >>> p = Parameter({'foo': 'bar'})
        >>> print(p)
        Parameter(raw_data={'foo': 'bar'})
    """

    def __init__(self, raw_param):
        self._raw_data = raw_param

    @property
    def raw_data(self):
        return self._raw_data


class ConnectorParameter(Parameter):
    """Represents a connector parameter. It has the following properties:

    name: The name of the parameter.
    value: The value of the parameter.
    type: The type of the parameter (according to `ConnectorParamTypes`).
    mode: The mode of the parameter.
    is_mandatory: Whether the parameter is mandatory.

    Example:
        >>> from data_models import ConnectorParameter, ConnectorParamTypes
        >>> p = ConnectorParameter({
            'param_name': 'api_root',
            'type': ConnectorParamTypes.STRING,
            'param_value': 'http://foo.bar',
            'is_mandatory': True,
            'mode': 0
            })
        >>> print(p)
        ConnectorParameter(name='api_root', value='http://foo.bar', type=2, mode=0, is_mandatory=True)

    """

    def __init__(self, raw_param):
        super().__init__(raw_param)
        self._name = raw_param.get("param_name", "")
        self._value = raw_param.get("param_value", "")
        self._type = ConnectorParamTypes(raw_param.get("type", -1))
        self._mode = raw_param.get("mode", "")
        self._is_mandatory = raw_param.get("is_mandatory", "")

    @property
    def name(self):
        return self._name

    @property
    def value(self):
        return self._value

    @property
    def type(self):
        return self._type

    @property
    def mode(self):
        return self._mode

    @property
    def is_mandatory(self):
        return self._is_mandatory


class ConnectorParamTypes(Enum):
    """Represents the types of connector parameters. The possible values are:

    * BOOLEAN: A Boolean parameter.
    * INTEGER: An integer parameter.
    * STRING: A string parameter.
    * PASSWORD: A password parameter.
    * IP: An IP address parameter.
    * HOST: A host name parameter.
    * URL: A URL parameter.
    * DOMAIN: A domain name parameter.
    * EMAIL: An email address parameter.
    * SCRIPT: Script parameter (legacy).
    * NULL: Invalid parameter type.
    """

    BOOLEAN = 0
    INTEGER = 1
    STRING = 2
    PASSWORD = 3
    IP = 4
    HOST = 5
    URL = 6
    DOMAIN = 7
    EMAIL = 8

    # TODO: (b/288932557)
    # This is workaround for SDK legacy code and should be removed when fixed
    SCRIPT = 12

    NULL = -1


class JobParamType(Enum):
    BOOLEAN = 0
    INTEGER = 1
    STRING = 2
    PASSWORD = 3
    IP = 4
    HOST = 5
    URL = 6
    DOMAIN = 7
    EMAIL = 8
    NULL = -1


class CaseDataStatus(Enum):
    NEW = 0
    OPENED = 1
    CLOSED = 2
    ALL = 3
    MERGED = 4
    CREATION_PENDING = 5

    @classmethod
    def _missing_(cls, value):
        """
        Custom method to handle missing values when trying to create
        an enum member. This supports direct integer values,
        'Priority' prefixed strings, and exact enum names as strings.
        """
        if isinstance(value, str):
            candidate_name = value.replace(" ", "_").upper()
            if candidate_name in cls.__members__:
                return cls.__members__[candidate_name]

        raise ValueError(f"'{value}' is not a valid {cls.__name__}")


CASE_DATA_STATUS_VAL_NAME_MAP = {
    CaseDataStatus.NEW: "New",
    CaseDataStatus.OPENED: "Opened",
    CaseDataStatus.CLOSED: "Closed",
    CaseDataStatus.ALL: "All",
    CaseDataStatus.MERGED: "Merged",
    CaseDataStatus.CREATION_PENDING: "Creation Pending",
}


class CasePriority(Enum):
    INFORMATIVE = -1
    UNCHANGED = 0
    LOW = 40
    MEDIUM = 60
    HIGH = 80
    CRITICAL = 100

    @classmethod
    def _missing_(cls, value):
        """
        Custom method to handle missing values when trying to create
        an enum member. This supports direct integer values,
        'Priority' prefixed strings, and exact enum names as strings.
        """
        if isinstance(value, str):
            candidate_name = (
                value[len("Priority") :].replace("Info", "Informative").upper()
            )
            candidate_name = candidate_name.replace("UNSPECIFIED", "UNCHANGED")
            if candidate_name in cls.__members__:
                return cls.__members__[candidate_name]

        raise ValueError(f"'{value}' is not a valid {cls.__name__}")


CASE_PRIORITY_VAL_NAME_MAP = {
    CasePriority.INFORMATIVE: "Informative",
    CasePriority.UNCHANGED: "Unchanged",
    CasePriority.LOW: "Low",
    CasePriority.MEDIUM: "Medium",
    CasePriority.HIGH: "High",
    CasePriority.CRITICAL: "Critical",
}


class AlertPriority(Enum):
    INFORMATIVE = -1
    UNCHANGED = 0
    LOW = 40
    MEDIUM = 60
    HIGH = 80
    CRITICAL = 100


ALERT_PRIORITY_VAL_NAME_MAP = {
    AlertPriority.INFORMATIVE: "Informative",
    AlertPriority.UNCHANGED: "Unchanged",
    AlertPriority.LOW: "Low",
    AlertPriority.MEDIUM: "Medium",
    AlertPriority.HIGH: "High",
    AlertPriority.CRITICAL: "Critical",
}


class ConnectorConnectivityStatusEnum(Enum):
    LIVE = 0
    NO_CONNECTIVITY = 1


class DatabaseContextType(Enum):
    GLOBAL = 0
    CASE = 1
    ALERT = 2
    JOB = 3
    CONNECTOR = 4


@dataclasses.dataclass
class ScriptContext:
    target_entities: str = ""
    case_id: int | str | None = None
    alert_id: str = ""
    environment: str = ""
    workflow_id: str = ""
    workflow_instance_id: str | None = None
    parameters: SingleJson = dataclasses.field(default_factory=dict)
    integration_identifier: str = ""
    integration_instance: str = ""
    action_definition_name: str = ""
    original_requesting_user: str = ""
    execution_deadline_unix_time_ms: int = 0
    async_polling_interval_in_sec: int = 0
    async_total_duration_deadline: int = 0
    script_timeout_deadline: int = 0
    default_result_value: str = ""
    use_proxy_settings: bool = False
    max_json_result_size: int = 15
    vault_settings: SiemplifyVault | None = None
    environment_api_key: str | None = None
    unique_identifier: str = ""
    job_api_key: str = ""
    connector_context: ConnectorContext | None = None

    def __post_init__(self) -> None:
        if self.connector_context is None:
            self.connector_context: ConnectorContext = ConnectorContext(
                {"params": [], "allow_list": []}
            )

    def update(self, attributes: SingleJson) -> None:
        vars(self).update(attributes)

    def to_json(self) -> SingleJson:
        return {
            "target_entities": self.target_entities,
            "case_id": self.case_id,
            "alert_id": self.alert_id,
            "environment": self.environment,
            "workflow_id": self.workflow_id,
            "workflow_instance_id": self.workflow_instance_id,
            "parameters": self.parameters,
            "integration_identifier": self.integration_identifier,
            "integration_instance": self.integration_instance,
            "action_definition_name": self.action_definition_name,
            "original_requesting_user": self.original_requesting_user,
            "execution_deadline_unix_time_ms": self.execution_deadline_unix_time_ms,
            "async_polling_interval_in_sec": self.async_polling_interval_in_sec,
            "async_total_duration_deadline": self.async_total_duration_deadline,
            "script_timeout_deadline": self.script_timeout_deadline,
            "default_result_value": self.default_result_value,
            "use_proxy_settings": self.use_proxy_settings,
            "max_json_result_size": self.max_json_result_size,
            "vault_settings": (
                self.vault_settings
                if self.vault_settings is None
                else {
                    "vault_api_root": self.vault_settings.api_root,
                    "vault_verify_ssl": self.vault_settings.verify_ssl,
                    "vault_username": self.vault_settings.username,
                    "vault_password": self.vault_settings.password,
                    "vault_client_ca_certificate": (
                        self.vault_settings.client_ca_certificate
                    ),
                    "vault_client_certificate": self.vault_settings.client_certificate,
                    "vault_client_certificate_passphrase": (
                        self.vault_settings.client_certificate_passphrase
                    ),
                }
            ),
            "environment_api_key": self.environment_api_key,
            "unique_identifier": self.unique_identifier,
            "job_api_key": self.job_api_key,
            "connector_info": {
                "environment": self.connector_context.connector_info.environment,
                "integration": self.connector_context.connector_info.integration,
                "connector_definition_name": (
                    self.connector_context.connector_info.connector_definition_name
                ),
                "identifier": self.connector_context.connector_info.identifier,
                "display_name": self.connector_context.connector_info.display_name,
                "description": self.connector_context.connector_info.description,
                "result_data_type": (
                    self.connector_context.connector_info.result_data_type
                ),
                "params": self.connector_context.connector_info.params,
                "allow_list": self.connector_context.connector_info.white_list,
            },
        }


class FieldItem:
    def __init__(self, original_name, name, value):
        # type: (str, str, str) -> None
        self.original_name = original_name
        self.name = name
        self.value = value

    @classmethod
    def from_json(cls, field_json):
        # type: (SingleJson) -> FieldItem
        return cls(
            original_name=field_json["originalName"],
            name=field_json["name"],
            value=field_json["value"],
        )


class EventPropertyField:
    def __init__(self, order, group_name, is_integration, is_highlight, items):
        # type: (int, str, bool, bool, list[FieldItem]) -> None
        self.order = order
        self.group_name = group_name
        self.is_integration = is_integration
        self.is_highlight = is_highlight
        self.items = items

    @classmethod
    def from_json(cls, event_property_field):
        # type: (SingleJson) -> EventPropertyField
        return cls(
            order=event_property_field["order"],
            group_name=event_property_field["groupName"],
            is_integration=event_property_field["isIntegration"],
            is_highlight=event_property_field["isHighlight"],
            items=[FieldItem.from_json(item) for item in event_property_field["items"]],
        )


class AlertEvent:
    def __init__(
        self,
        fields,
        identifier,
        case_id,
        alert_identifier,
        name,
        product,
        port,
        source_system_name,
        outcome,
        time,
        type_,
        artifact_entities,
    ):
        # type: (list[EventPropertyField], str, int, str, str, str | None, str, str | None, int, str, list[str]) -> None
        self.fields = fields
        self.identifier = identifier
        self.case_id = case_id
        self.alert_identifier = alert_identifier
        self.name = name
        self.product = product
        self.port = port
        self.source_system_name = source_system_name
        self.outcome = outcome
        self.time = time
        self.type_ = type_
        self.artifact_entities = artifact_entities

    @classmethod
    def from_json(cls, event_json):
        # type: (SingleJson) -> AlertEvent
        return cls(
            fields=[
                EventPropertyField.from_json(field) for field in event_json["fields"]
            ],
            identifier=event_json["identifier"],
            case_id=event_json["caseId"],
            alert_identifier=event_json["alertIdentifier"],
            name=event_json["name"],
            product=event_json["product"],
            port=event_json["port"],
            source_system_name=event_json["sourceSystemName"],
            outcome=event_json["outcome"],
            time=event_json["time"],
            type_=event_json["type"],
            artifact_entities=event_json["artifactEntities"],
        )


class FieldGroupItem:
    def __init__(self, original_name, name, value):
        # type: (str, str, str) -> None
        self.original_name = original_name
        self.name = name
        self.value = value

    @classmethod
    def from_json(cls, field_group_json):
        # type: (SingleJson) -> FieldGroupItem
        return cls(
            original_name=field_group_json["originalName"],
            name=field_group_json["name"],
            value=field_group_json["value"],
        )

    def to_json(self) -> SingleJson:
        return {
            "originalName": self.original_name,
            "name": self.name,
            "value": self.value,
        }


class FieldsGroup:
    def __init__(self, order, group_name, is_integration, is_highlight, items):
        # type: (int, str, bool, bool, list[FieldGroupItem]) -> None
        self.order = order
        self.group_name = group_name
        self.is_integration = is_integration
        self.is_highlight = is_highlight
        self.items = items

    @classmethod
    def from_json(cls, field_group_json):
        # type: (SingleJson) -> FieldsGroup
        return cls(
            order=field_group_json["order"],
            group_name=field_group_json["groupName"],
            is_integration=field_group_json["isIntegration"],
            is_highlight=field_group_json["isHighlight"],
            items=[
                FieldGroupItem.from_json(item_json)
                for item_json in field_group_json["items"]
            ],
        )

    def to_json(self) -> SingleJson:
        items_json = [item.to_json() for item in self.items] if self.items else []
        return {
            "order": self.order,
            "groupName": self.group_name,
            "isIntegration": self.is_integration,
            "isHighlight": self.is_highlight,
            "items": items_json,
        }


class SLA:
    def __init__(
        self,
        sla_expiration_time,
        critical_expiration_time,
        expiration_status,
        remaining_time_since_last_pause,
    ):
        # type: (int | None, int | None, int, int | None) -> None
        self.sla_expiration_time = sla_expiration_time
        self.critical_expiration_time = critical_expiration_time
        self.expiration_status = expiration_status
        self.remaining_time_since_last_pause = remaining_time_since_last_pause

    @classmethod
    def from_json(cls, sla_json):
        # type: (SingleJson) -> SLA
        return cls(
            sla_expiration_time=sla_json.get(
                "expirationTime", sla_json.get("slaExpirationTime", -1)
            ),
            critical_expiration_time=sla_json.get("criticalExpirationTime", -1),
            expiration_status=sla_json.get("expirationStatus", -1),
            remaining_time_since_last_pause=sla_json.get(
                "remainingTimeSinceLastPause", -1
            ),
        )

    def to_json(self) -> SingleJson:
        """Converts the SLA object to a JSON-serializable dictionary."""
        return {
            "slaExpirationTime": self.sla_expiration_time,
            "criticalExpirationTime": self.critical_expiration_time,
            "expirationStatus": self.expiration_status,
            "remainingTimeSinceLastPause": self.remaining_time_since_last_pause,
        }


class AlertCard:
    def __init__(
        self,
        id_,
        creation_time_unix_time_ms,
        modification_time_unix_time_ms,
        identifier,
        status,
        name,
        priority,
        workflow_status,
        sla_expiration_unix_time,
        sla_critical_expiration_unix_time,
        start_time,
        end_time,
        alert_group_identifier,
        events_count,
        title,
        rule_generator,
        device_product,
        device_vendor,
        playbook_attached,
        playbook_run_count,
        is_manual_alert,
        sla,
        fields_groups,
        source_url,
        source_rule_url,
        siem_alert_id,
        additional_properties,
        case_id,
        closure_details,
    ):
        # type: (int, int, int, str, int, str, AlertPriority, int, int | None, int | None, int, int, str, int, str, str, str, str | None, int, bool, SLA, list[FieldsGroup], str | None, str | None, str | None) -> None
        self.id_ = id_
        self.creation_time_unix_time_ms = creation_time_unix_time_ms
        self.modification_time_unix_time_ms = modification_time_unix_time_ms
        self.identifier = identifier
        self.status = status
        self.name = name
        self.priority = priority
        self.workflow_status = workflow_status
        self.sla_expiration_unix_time = sla_expiration_unix_time
        self.sla_critical_expiration_unix_time = sla_critical_expiration_unix_time
        self.start_time = start_time
        self.end_time = end_time
        self.alert_group_identifier = alert_group_identifier
        self.events_count = events_count
        self.title = title
        self.rule_generator = rule_generator
        self.device_product = device_product
        self.device_vendor = device_vendor
        self.playbook_attached = playbook_attached
        self.playbook_run_count = playbook_run_count
        self.is_manual_alert = is_manual_alert
        self.sla = sla
        self.fields_groups = fields_groups
        self.source_url = source_url
        self.source_rule_url = source_rule_url
        self.siem_alert_id = siem_alert_id
        self.additional_properties = additional_properties
        self.case_id = case_id
        self.closure_details = closure_details

    @classmethod
    def from_json(cls, alert_card_json):
        # type: (SingleJson) -> AlertCard
        return cls(
            id_=alert_card_json.get("id", 0),
            creation_time_unix_time_ms=(
                alert_card_json.get("creationTimeUnixTimeInMs", 0)
            ),
            modification_time_unix_time_ms=(
                alert_card_json.get("modificationTimeUnixTimeInMs", 0)
            ),
            identifier=alert_card_json.get("identifier", ""),
            status=alert_card_json.get("status", 0),
            name=alert_card_json.get("displayName", alert_card_json.get("name", "")),
            priority=(
                AlertPriority(alert_card_json.get("priority"))
                if isinstance(alert_card_json.get("priority"), int)
                else alert_card_json.get("priority")
            ),
            workflow_status=alert_card_json.get("workflowsStatus", ""),
            sla_expiration_unix_time=alert_card_json.get("slaExpirationUnixTime", 0),
            sla_critical_expiration_unix_time=(
                alert_card_json.get("slaCriticalExpirationUnixTime", 0)
            ),
            start_time=alert_card_json.get("startTime", 0),
            end_time=alert_card_json.get("endTime", 0),
            alert_group_identifier=alert_card_json.get("alertGroupIdentifier", ""),
            events_count=alert_card_json.get("eventsCount", 0),
            title=alert_card_json.get("displayName", alert_card_json.get("title", "")),
            rule_generator=alert_card_json.get("ruleGenerator", ""),
            device_product=alert_card_json.get(
                "product", alert_card_json.get("deviceProduct")
            ),
            device_vendor=alert_card_json.get(
                "vendor", alert_card_json.get("deviceVendor")
            ),
            playbook_attached=alert_card_json.get("playbookAttached", ""),
            playbook_run_count=alert_card_json.get("playbookAttached", ""),
            is_manual_alert=alert_card_json.get("isManualAlert"),
            sla=(
                SLA.from_json(alert_card_json.get("sla"))
                if alert_card_json.get("sla")
                else None
            ),
            fields_groups=[
                FieldsGroup.from_json(field_group_json)
                for field_group_json in alert_card_json.get("fieldsGroups", [])
            ],
            source_url=alert_card_json.get("sourceUrl", ""),
            source_rule_url=alert_card_json.get("sourceRuleUrl", ""),
            siem_alert_id=alert_card_json.get("siemAlertId", 0),
            additional_properties=alert_card_json.get("additionalProperties", None),
            case_id=alert_card_json.get("caseId"),
            closure_details = alert_card_json.get("closureDetails")
        )

    def to_json(self) -> SingleJson:
        """Converts the AlertCard object to a JSON-serializable dictionary."""
        priority_value = (
            self.priority.value if isinstance(self.priority, Enum) else self.priority
        )
        sla_json = self.sla.to_json() if self.sla else None
        fields_groups_json = (
            [fg.to_json() for fg in self.fields_groups] if self.fields_groups else []
        )

        return {
            "id": self.id_,
            "creationTimeUnixTimeInMs": self.creation_time_unix_time_ms,
            "modificationTimeUnixTimeInMs": self.modification_time_unix_time_ms,
            "identifier": self.identifier,
            "status": self.status,
            "name": self.name,
            "priority": priority_value,
            "workflowsStatus": self.workflow_status,
            "slaExpirationUnixTime": self.sla_expiration_unix_time,
            "slaCriticalExpirationUnixTime": self.sla_critical_expiration_unix_time,
            "startTime": self.start_time,
            "endTime": self.end_time,
            "alertGroupIdentifier": self.alert_group_identifier,
            "eventsCount": self.events_count,
            "title": self.title,
            "ruleGenerator": self.rule_generator,
            "deviceProduct": self.device_product,
            "deviceVendor": self.device_vendor,
            "caseId": self.case_id,
            "playbookAttached": self.playbook_attached,
            "playbookRunCount": self.playbook_run_count,
            "isManualAlert": self.is_manual_alert,
            "sla": sla_json,
            "fieldsGroups": fields_groups_json,
            "sourceUrl": self.source_url,
            "sourceRuleUrl": self.source_rule_url,
            "siemAlertId": self.siem_alert_id,
            "closureDetails": self.closure_details
        }


class CaseDetails:
    def __init__(
        self,
        id_,
        creation_time_unix_time_ms,
        modification_time_unix_time_ms,
        name,
        priority,
        is_important,
        is_incident,
        start_time_unix_time_ms,
        end_time_unix_time_ms,
        assigned_user,
        description,
        is_test_case,
        type_,
        stage,
        environment,
        status,
        incident_id,
        tags,
        alerts,
        is_overflow_case,
        is_manual_case,
        sla_expiration_unix_time,
        sla_critical_expiration_unix_time,
        stage_sla_expiration_unix_time_ms,
        stage_sla__critical_expiration_unix_time_in_ms,
        can_open_incident,
        sla,
        stage_sla,
        alerts_sla,
    ):
        # type: (int, int, int, str, CasePriority, bool, bool, int, int, str, str | None, bool, int, str, str, CaseDataStatus, int | None, list[str], list[AlertCard], bool, bool, int | None, int | None, int | None, int | None, bool, SLA, SLA) -> None
        self.id_ = id_
        self.creation_time_unix_time_ms = creation_time_unix_time_ms
        self.modification_time_unix_time_ms = modification_time_unix_time_ms
        self.name = name
        self.priority = priority
        self.is_important = is_important
        self.is_incident = is_incident
        self.start_time_unix_time_ms = start_time_unix_time_ms
        self.end_time_unix_time_ms = end_time_unix_time_ms
        self.assigned_user = assigned_user
        self.description = description
        self.is_test_case = is_test_case
        self.type_ = type_
        self.stage = stage
        self.environment = environment
        self.status = status
        self.incident_id = incident_id
        self.tags = tags
        self.alerts = alerts
        self.is_overflow_case = is_overflow_case
        self.is_manual_case = is_manual_case
        self.sla_expiration_unix_time = sla_expiration_unix_time
        self.sla_critical_expiration_unix_time = sla_critical_expiration_unix_time
        self.stage_sla_expiration_unix_time_ms = stage_sla_expiration_unix_time_ms
        self.stage_sla__critical_expiration_unix_time_in_ms = (
            stage_sla__critical_expiration_unix_time_in_ms
        )
        self.can_open_incident = can_open_incident
        self.sla = sla
        self.stage_sla = stage_sla
        self.alerts_sla = alerts_sla

    @property
    def is_open(self):
        # type: () -> bool
        return self.status == CaseDataStatus.OPENED

    @property
    def is_closed(self):
        # type: () -> bool
        return self.status == CaseDataStatus.CLOSED

    @classmethod
    def from_json(cls, case_details_json):
        # type: (SingleJson) -> CaseDetails
        return cls(
            id_=case_details_json.get("id"),
            creation_time_unix_time_ms=(
                case_details_json.get("creationTimeUnixTimeInMs")
                or case_details_json.get("createTime")
            ),
            modification_time_unix_time_ms=(
                case_details_json.get("modificationTimeUnixTimeInMs")
                or case_details_json.get("updateTime")
            ),
            name=case_details_json.get("displayName", case_details_json.get("name")),
            priority=CasePriority(case_details_json.get("priority", 0)),
            is_important=case_details_json.get(
                "important",
                case_details_json.get("isImportant", False),
            ),
            is_incident=case_details_json.get(
                "incident",
                case_details_json.get("isIncident", False),
            ),
            start_time_unix_time_ms=(
                case_details_json.get("startTimeUnixTimeInMs")
                or case_details_json.get("createTime")
            ),
            end_time_unix_time_ms=(
                case_details_json.get("endTimeUnixTimeInMs")
                or case_details_json.get("endTime")
            ),
            assigned_user=(
                case_details_json.get("assignedUser")
                or case_details_json.get("assignee")
            ),
            description=case_details_json.get("description", ""),
            is_test_case=case_details_json.get("isTestCase", False),
            type_=case_details_json.get("type"),
            stage=case_details_json.get("stage"),
            tags=case_details_json.get("tags", []),
            environment=case_details_json.get("environment"),
            status=CaseDataStatus(case_details_json.get("status", 0)),
            incident_id=case_details_json.get("incidentId", ""),
            alerts=[
                AlertCard.from_json(alert_card_json)
                for alert_card_json in (case_details_json.get("alertCards", []))
            ],
            is_overflow_case=case_details_json.get("isOverflowCase", False),
            is_manual_case=case_details_json.get("isManualCase", False),
            sla_expiration_unix_time=case_details_json.get("slaExpirationUnixTime"),
            sla_critical_expiration_unix_time=(
                case_details_json.get("slaCriticalExpirationUnixTime")
            ),
            stage_sla_expiration_unix_time_ms=(
                case_details_json.get("stageSlaExpirationUnixTimeInMs")
            ),
            stage_sla__critical_expiration_unix_time_in_ms=(
                case_details_json.get("stageSlaCriticalExpirationUnixTimeInMs")
            ),
            can_open_incident=case_details_json.get("canOpenIncident", False),
            sla=SLA.from_json(case_details_json.get("sla", {})),
            stage_sla=(
                SLA.from_json(
                    case_details_json.get("stageSla", case_details_json.get("sla", {}))
                )
            ),
            alerts_sla=SLA.from_json(case_details_json.get("alertsSla", {})),
        )

    def to_json(self) -> SingleJson:
        """Converts the CaseDetails object to a JSON-serializable dictionary."""
        priority_value = self.priority.value
        status_value = self.status.value

        alerts_json = [alert.to_json() for alert in self.alerts]
        sla_json = self.sla.to_json()
        stage_sla_json = self.stage_sla.to_json()
        tags = [
            tag["displayName"] if "displayName" in tag else tag for tag in self.tags
        ]

        return {
            "id": self.id_,
            "creationTimeUnixTimeInMs": self.creation_time_unix_time_ms,
            "modificationTimeUnixTimeInMs": self.modification_time_unix_time_ms,
            "name": self.name,
            "priority": priority_value,
            "isImportant": self.is_important,
            "isIncident": self.is_incident,
            "startTimeUnixTimeInMs": self.start_time_unix_time_ms,
            "endTimeUnixTimeInMs": self.end_time_unix_time_ms,
            "assignedUser": self.assigned_user,
            "description": self.description,
            "isTestCase": self.is_test_case,
            "type": self.type_,
            "stage": self.stage,
            "environment": self.environment,
            "status": status_value,
            "incidentId": self.incident_id,
            "tags": self.tags,
            "alertCards": alerts_json,
            "isOverflowCase": self.is_overflow_case,
            "isManualCase": self.is_manual_case,
            "slaExpirationUnixTime": self.sla_expiration_unix_time,
            "slaCriticalExpirationUnixTime": self.sla_critical_expiration_unix_time,
            "stageSlaExpirationUnixTimeInMs": self.stage_sla_expiration_unix_time_ms,
            "stageSlaCriticalExpirationUnixTimeInMs": (
                self.stage_sla__critical_expiration_unix_time_in_ms
            ),
            "canOpenIncident": self.can_open_incident,
            "sla": sla_json,
            "stageSla": stage_sla_json,
            "alertSla": self.alerts_sla.to_json(),
        }


class UserProfileCard:
    def __init__(
        self,
        raw_data,
        first_name,
        last_name,
        user_name,
        account_state,
    ):
        # type: (dict, str, str, str, int) -> None
        self.raw_data = raw_data
        self.first_name = first_name
        self.last_name = last_name
        self.user_name = user_name
        self.account_state = account_state

    @classmethod
    def from_json(cls, user_profile_card_response):
        # type: (dict) -> UserProfileCard
        return cls(
            raw_data=user_profile_card_response,
            first_name=user_profile_card_response["firstName"],
            last_name=user_profile_card_response["lastName"],
            user_name=user_profile_card_response.get(
                "userName",
                user_profile_card_response.get("displayName"),
            ),
            account_state=user_profile_card_response["accountState"],
        )


class ConnectorCard:
    def __init__(
        self,
        integration: str,
        display_name: str,
        identifier: str,
        is_enabled: bool,
        is_remote: bool,
        status: ConnectorConnectivityStatusEnum,
    ) -> None:
        self.integration = integration
        self.display_name = display_name
        self.identifier = identifier
        self.is_enabled = is_enabled
        self.is_remote = is_remote
        self.status = status

    @classmethod
    def from_json(cls, connector_card_json: SingleJson) -> ConnectorCard:
        return cls(
            integration=connector_card_json["integration"],
            display_name=connector_card_json.get("display_name")
            or connector_card_json.get("displayName"),
            identifier=connector_card_json["identifier"],
            is_enabled=(
                connector_card_json.get("is_enabled")
                or connector_card_json.get("enabled")
            ),
            is_remote=connector_card_json.get("is_remote")
            or connector_card_json.get("remote"),
            status=ConnectorConnectivityStatusEnum(
                connector_card_json.get("status", 1)
            ),
        )


class InstalledIntegrationInstance:
    def __init__(
        self,
        instance: SingleJson,
        identifier: str,
        integration_identifier: str,
        instance_description: str,
        environment_identifier: str,
        instance_name: str,
        is_configured: bool,
    ) -> None:
        self.instance = instance
        self.identifier = identifier
        self.integration_identifier = integration_identifier
        self.instance_description = instance_description
        self.environment_identifier = environment_identifier
        self.instance_name = instance_name
        self.is_configured = is_configured

    @classmethod
    def from_json(
        cls,
        integration_env_json: SingleJson,
    ) -> InstalledIntegrationInstance:
        """Parses JSON data into an IntegrationEnvironment object.

        Args:
            integration_env_json (SingleJson): JSON data containing integration
                environment information.

        Returns:
            InstalledIntegrationInstance: An instance of the specified class
            initialized with data from `raw_data`.
        """
        return cls(
            instance=integration_env_json,
            identifier=integration_env_json.get("identifier", ""),
            integration_identifier=integration_env_json.get("integrationIdentifier", ""),
            instance_description=integration_env_json.get("instanceDescription", ""),
            environment_identifier=(
                integration_env_json.get("environmentIdentifier")
                or integration_env_json.get("environment")
            ),
            instance_name=(
                integration_env_json.get("instanceName")
                or integration_env_json.get("displayName")
            ),
            is_configured=integration_env_json.get(
                "isConfigured",
                integration_env_json.get("configured", False)
            ),
        )

    def to_json(self) -> SingleJson:
        """Serializes data model into dict.

        Returns:
            Service Account Json dict
        """
        return {
            "environmentIdentifier": self.instance.get(
                "environmentIdentifier", self.instance.get("environment")
            ),
            "identifier": self.instance.get("identifier"),
            "instanceDescription": self.instance.get(
                "instanceDescription", self.instance.get("displayName")
            ),
            "instanceName": self.instance.get(
                "instanceName", self.instance.get("displayName")
            ),
            "integrationIdentifier": self.instance.get(
                "integrationIdentifier", self.instance.get("integration")
            ),
            "isConfigured": self.instance.get(
                "isConfigured", self.instance.get("configured")
            ),
            "isRemote": self.instance.get("isRemote", None),
            "isSystemDefault": self.instance.get(
                "isSystemDefault", self.instance.get("systemDefault")
            ),
        }


class GoogleServiceAccount:
    def __init__(
        self,
        account_type,
        project_id,
        private_key_id,
        private_key,
        client_email,
        client_id,
        auth_uri,
        token_uri,
        auth_provider_x509_url,
        client_x509_cert_url,
    ):
        # type: (str, str, str, str, str, str, str, str, str, str) -> None
        self.account_type = account_type
        self.project_id = project_id
        self.private_key_id = private_key_id
        self.private_key = private_key
        self.client_email = client_email
        self.client_id = client_id
        self.auth_uri = auth_uri
        self.token_uri = token_uri
        self.auth_provider_x509_url = auth_provider_x509_url
        self.client_x509_cert_url = client_x509_cert_url

    def to_dict(self):
        # type: () -> dict
        """Serializes data model into dict.

        Returns:
            Service Account Json dict
        """
        return {
            "account_type": self.account_type,
            "project_id": self.project_id,
            "private_key_id": self.private_key_id,
            "private_key": self.private_key,
            "client_email": self.client_email,
            "client_id": self.client_id,
            "auth_uri": self.auth_uri,
            "token_uri": self.token_uri,
            "auth_provider_x509_cert_url": self.auth_provider_x509_url,
            "client_x509_cert_url": self.client_x509_cert_url,
        }


@dataclasses.dataclass(slots=True)
class CaseWallAttachment:
    name: str
    file_type: str
    base64_blob: str
    is_important: bool
    case_id: int | None = None


class CustomFieldScope(Enum):
    CASE = "Case"
    ALERTS = "Alert"

    def build_parent_path(self, identifier: int) -> str:
        if self == CustomFieldScope.CASE:
            return f"cases/{identifier}"
        return f"cases/-/alerts/{identifier}"


@dataclasses.dataclass(slots=True)
class CustomField:
    id: int
    display_name: str
    description: str
    type: str
    scopes: list[CustomFieldScope]

    @classmethod
    def from_json(cls, json_data: SingleJson) -> CustomField:
        return cls(
            id=json_data["id"],
            display_name=json_data["displayName"],
            description=json_data["description"],
            type=json_data["type"],
            scopes=[
                CustomFieldScope(sc.strip()) for sc in json_data["scopes"].split(",")
            ],
        )


@dataclasses.dataclass(slots=True)
class CustomFieldValue:
    custom_field_id: int
    values: list[str]
    scope: CustomFieldScope
    identifier: int

    @classmethod
    def from_json(cls, json_data: SingleJson) -> CustomFieldValue:
        return cls(
            custom_field_id=json_data["customFieldId"],
            values=json_data["values"],
            scope=CustomFieldScope(json_data["scope"]),
            identifier=json_data["identifier"],
        )


class SmimeType(Enum):
    ENCRYPTED = "encrypted"
    SIGNED = "signed"


@dataclasses.dataclass(slots=True)
class SmimeEmailConfig:
    email: email.message.Message
    private_key_b64: str
    certificate_b64: str
    ca_certificate_b64: str


@dataclasses.dataclass(slots=True)
class DynamicParameter:
    key: str
    value: str

    @classmethod
    def from_json(cls, json_data: SingleJson) -> DynamicParameter:
        return cls(
            key=json_data.get("key", json_data.get("dynamicParameterId", "")),
            value=json_data.get("value", ""),
        )

    def to_json(self) -> SingleJson:
        return {"key": self.key, "value": self.value}


@dataclasses.dataclass(slots=True)
class EnvironmentData:
    environment: str
    dynamic_parameters: list[DynamicParameter] = dataclasses.field(default_factory=list)
    base64_image: str | None = None
    platform: int | None = None

    @classmethod
    def from_json(cls, json_data: SingleJson) -> EnvironmentData:
        return cls(
            environment=json_data["environment"],
            dynamic_parameters=[
                DynamicParameter.from_json(p)
                for p in json_data.get("dynamicParameters", [])
            ],
            base64_image=json_data.get("base64Image"),
            platform=json_data.get("platform"),
        )


@dataclasses.dataclass(slots=True)
class CaseSLAInfo:
    expiration_time_ms: int | None = None
    critical_expiration_time_ms: int | None = None
    expiration_status: int | None = None
    last_pause_remaining_time_ms: int | None = None

    @classmethod
    def from_json(cls, json_data: SingleJson) -> CaseSLAInfo:
        return cls(
            expiration_time_ms=json_data.get("expirationTimeMs"),
            critical_expiration_time_ms=json_data.get("criticalExpirationTimeMs"),
            expiration_status=json_data.get("expirationStatus"),
            last_pause_remaining_time_ms=json_data.get("lastPauseRemainingTimeMs"),
        )


@dataclasses.dataclass(slots=True)
class CaseOverviewInfo:
    id: int
    create_time_ms: int
    update_time_ms: int
    display_id: str
    display_name: str
    alert_count: int
    stage: str
    priority: CasePriority
    important: bool
    description: str | None = None
    type: int | None = None
    assignee_full_name: str | None = None
    environment_data: EnvironmentData | None = None
    status: CaseDataStatus | None = None
    score: int | None = None
    case_sla: CaseSLAInfo | None = None
    alerts_sla: CaseSLAInfo | None = None
    incident: bool | None = None
    has_suspicious_entity: bool | None = None
    workflow_status: int | None = None
    tags: list[str] = dataclasses.field(default_factory=list)
    products: list[str] = dataclasses.field(default_factory=list)
    touched: bool | None = None
    merged: bool | None = None
    has_incident: bool | None = None
    alert_names: list[str] = dataclasses.field(default_factory=list)

    @classmethod
    def from_json(cls, json_data: SingleJson) -> CaseOverviewInfo:
        env_data_json = json_data.get("environmentData")
        case_sla_json = json_data.get("caseSla")
        alerts_sla_json = json_data.get("alertsSla")

        return cls(
            id=json_data["id"],
            create_time_ms=json_data["createTimeMs"],
            update_time_ms=json_data["updateTimeMs"],
            display_id=json_data["displayId"],
            display_name=json_data["displayName"],
            alert_count=json_data["alertCount"],
            stage=json_data["stage"],
            priority=CasePriority(json_data["priority"]),
            important=json_data["important"],
            description=json_data.get("description"),
            type=json_data["type"],
            assignee_full_name=json_data.get("assigneeFullName"),
            environment_data=(
                EnvironmentData.from_json(env_data_json) if env_data_json else None
            ),
            status=CaseDataStatus(json_data["status"]),
            score=json_data.get("score"),
            case_sla=CaseSLAInfo.from_json(case_sla_json) if case_sla_json else None,
            alerts_sla=(
                CaseSLAInfo.from_json(alerts_sla_json) if alerts_sla_json else None
            ),
            incident=json_data.get("incident"),
            has_suspicious_entity=json_data.get("hasSuspiciousEntity"),
            workflow_status=json_data.get("workflowStatus"),
            tags=json_data.get("tags", []),
            products=json_data.get("products", []),
            touched=json_data.get("touched"),
            merged=json_data.get("merged"),
            has_incident=json_data.get("hasIncident"),
            alert_names=json_data.get("alertNames", []),
        )


@dataclasses.dataclass(slots=True)
class EventCard:
    case_id: int
    alert_identifier: str
    event_id: str
    name: str
    time: int
    product: str
    port: str
    outcome: str
    artifact_entities: list[SingleJson]
    fields: list[SingleJson]

    @classmethod
    def from_json(cls, event_data: SingleJson) -> EventCard:
        return cls(
            case_id=event_data.get("caseId", event_data.get("case_id")),
            alert_identifier=event_data.get(
                "alertIdentifier", event_data.get("alert_identifier")
            ),
            event_id=event_data.get("identifier", event_data.get("event_id")),
            name=event_data.get("name", event_data.get("eventName")),
            time=event_data["time"],
            product=event_data["product"],
            port=event_data["port"],
            outcome=event_data["outcome"],
            artifact_entities=event_data.get("artifactEntities", [])
            or event_data.get("artificats"),
            fields=event_data.get("fields", []),
        )

    def to_json(self) -> SingleJson:
        return {
            "caseId": self.case_id,
            "alertIdentifier": self.alert_identifier,
            "eventId": self.event_id,
            "name": self.name,
            "time": self.time,
            "product": self.product,
            "artifactEntities": self.artifact_entities,
        }


@dataclasses.dataclass(slots=True)
class EntityCard:
    identifier: str
    entity_type: str
    is_suspicious: str
    linked_entities: list[str]

    @classmethod
    def from_json(cls, entity_data: SingleJson) -> EntityCard:
        return cls(
            identifier=entity_data["identifier"],
            entity_type=entity_data.get("type", entity_data.get("entity_type")),
            is_suspicious=entity_data.get(
                "suspicious", entity_data.get("is_suspicious")
            ),
            linked_entities=entity_data.get(
                "linkedEntities", entity_data.get("linked_entities")
            ),
        )

    def to_json(self) -> SingleJson:
        return {
            "identifier": self.identifier,
            "type": self.entity_type,
            "suspicious": self.is_suspicious,
            "linkedEntities": self.linked_entities,
        }


class DataAccessContext:
    def __init__(self, global_access: bool, assigned_scopes: list[Any]):
        # type: (bool, List[Any]) -> None
        self.global_access = global_access
        self.assigned_scopes = assigned_scopes

    @classmethod
    def from_json(cls, json_data: SingleJson) -> "DataAccessContext":
        return cls(
            global_access=json_data.get("globalAccess", False),
            assigned_scopes=json_data.get("assignedScopes", []),
        )

    def to_json(self) -> dict:
        return {
            "globalAccess": self.global_access,
            "assignedScopes": self.assigned_scopes,
        }


class UserDetails:
    def __init__(
        self,
        id_: int,
        creation_time_unix_time_in_ms: int,
        modification_time_unix_time_in_ms: int,
        permission_group: str,
        permission_groups: list[str],
        soc_roles: list[str],
        is_disabled: bool,
        login_identifier: str,
        first_name: str,
        last_name: str,
        permission_type: int,
        role: int,
        soc_role_id: int,
        soc_role_ids: list[int],
        email: str,
        user_name: str,
        user_type: int,
        identity_provider: int,
        provider_name: str,
        advanced_reports_access: int,
        account_state: int,
        last_login_time: int,
        previous_login_time: int,
        last_password_change_time: int,
        last_password_change_notification_time: int,
        login_wrong_password_count: int,
        is_deleted: bool,
        deletion_time_unix_time_in_ms: int,
        environments: list[str],
        allowed_platforms: list[int],
        data_access_context: DataAccessContext,
        soc_role: str | None,
        image_base64: str | None,
    ):
        self.id_ = id_
        self.creation_time_unix_time_in_ms = creation_time_unix_time_in_ms
        self.modification_time_unix_time_in_ms = modification_time_unix_time_in_ms
        self.permission_group = permission_group
        self.permission_groups = permission_groups
        self.soc_role = soc_role
        self.soc_roles = soc_roles
        self.is_disabled = is_disabled
        self.login_identifier = login_identifier
        self.first_name = first_name
        self.last_name = last_name
        self.permission_type = permission_type
        self.role = role
        self.soc_role_id = soc_role_id
        self.soc_role_ids = soc_role_ids
        self.email = email
        self.user_name = user_name
        self.image_base64 = image_base64
        self.user_type = user_type
        self.identity_provider = identity_provider
        self.provider_name = provider_name
        self.advanced_reports_access = advanced_reports_access
        self.account_state = account_state
        self.last_login_time = last_login_time
        self.previous_login_time = previous_login_time
        self.last_password_change_time = last_password_change_time
        self.last_password_change_notification_time = (
            last_password_change_notification_time
        )
        self.login_wrong_password_count = login_wrong_password_count
        self.is_deleted = is_deleted
        self.deletion_time_unix_time_in_ms = deletion_time_unix_time_in_ms
        self.environments = environments
        self.allowed_platforms = allowed_platforms
        self.data_access_context = data_access_context

    @classmethod
    def from_json(cls, user_details_json: SingleJson) -> "UserDetails":
        data_access_context_json = user_details_json.get("dataAccessContext", {})
        data_access_context = DataAccessContext.from_json(data_access_context_json)

        return cls(
            id_=user_details_json.get("id"),
            creation_time_unix_time_in_ms=user_details_json.get(
                "creationTimeUnixTimeInMs", 0
            ),
            modification_time_unix_time_in_ms=user_details_json.get(
                "modificationTimeUnixTimeInMs", 0
            ),
            permission_group=user_details_json.get("permissionGroup", ""),
            permission_groups=user_details_json.get("permissionGroups", []),
            soc_role=user_details_json.get("socRole", None),
            soc_roles=user_details_json.get("socRoles", []),
            is_disabled=user_details_json.get("isDisabled", False),
            login_identifier=user_details_json.get("loginIdentifier"),
            first_name=user_details_json.get("firstName"),
            last_name=user_details_json.get("lastName"),
            permission_type=user_details_json.get("permissionType", 0),
            role=user_details_json.get("role", None),
            soc_role_id=user_details_json.get("socRoleId", None),
            soc_role_ids=user_details_json.get("socRoleIds", []),
            email=user_details_json.get("email"),
            user_name=user_details_json.get(
                "userName", user_details_json.get("displayName")
            ),
            image_base64=user_details_json.get("imageBase64", None),
            user_type=user_details_json.get("userType", None),
            identity_provider=user_details_json.get("identityProvider", None),
            provider_name=user_details_json.get("providerName"),
            advanced_reports_access=user_details_json.get("advancedReportsAccess", 0),
            account_state=user_details_json.get("accountState"),
            last_login_time=user_details_json.get("lastLoginTime"),
            previous_login_time=user_details_json.get("previousLoginTime", None),
            last_password_change_time=user_details_json.get(
                "lastPasswordChangeTime", None
            ),
            last_password_change_notification_time=user_details_json.get(
                "lastPasswordChangeNotificationTime", None
            ),
            login_wrong_password_count=user_details_json.get(
                "loginWrongPasswordCount", None
            ),
            is_deleted=user_details_json.get("isDeleted", False),
            deletion_time_unix_time_in_ms=user_details_json.get(
                "deletionTimeUnixTimeInMs", None
            ),
            environments=user_details_json.get("environments", []),
            allowed_platforms=user_details_json.get("allowedPlatforms", []),
            data_access_context=data_access_context,
        )

    def to_json(self) -> SingleJson:
        return {
            "id": self.id_,
            "creationTimeUnixTimeInMs": self.creation_time_unix_time_in_ms,
            "modificationTimeUnixTimeInMs": self.modification_time_unix_time_in_ms,
            "permissionGroup": self.permission_group,
            "permissionGroups": self.permission_groups,
            "socRole": self.soc_role,
            "socRoles": self.soc_roles,
            "isDisabled": self.is_disabled,
            "loginIdentifier": self.login_identifier,
            "firstName": self.first_name,
            "lastName": self.last_name,
            "permissionType": self.permission_type,
            "role": self.role,
            "socRoleId": self.soc_role_id,
            "socRoleIds": self.soc_role_ids,
            "email": self.email,
            "userName": self.user_name,
            "imageBase64": self.image_base64,
            "userType": self.user_type,
            "identityProvider": self.identity_provider,
            "providerName": self.provider_name,
            "advancedReportsAccess": self.advanced_reports_access,
            "accountState": self.account_state,
            "lastLoginTime": self.last_login_time,
            "previousLoginTime": self.previous_login_time,
            "lastPasswordChangeTime": self.last_password_change_time,
            "lastPasswordChangeNotificationTime": (
                self.last_password_change_notification_time
            ),
            "loginWrongPasswordCount": self.login_wrong_password_count,
            "isDeleted": self.is_deleted,
            "deletionTimeUnixTimeInMs": self.deletion_time_unix_time_in_ms,
            "environments": self.environments,
            "allowedPlatforms": self.allowed_platforms,
            "dataAccessContext": self.data_access_context.to_json(),
        }


class InternalDomain:
    def __init__(
        self,
        alias_name: str,
        id_: int,
        domain_display_name: str,
        environments_json: str,
        creation_time_unix_time_in_ms: int,
        modification_time_unix_time_in_ms: int,
    ):
        self.alias_name = alias_name
        self.id_ = id_
        self.domain_display_name = domain_display_name
        self.environments_json = environments_json
        self.creation_time_unix_time_in_ms = creation_time_unix_time_in_ms
        self.modification_time_unix_time_in_ms = modification_time_unix_time_in_ms

    @classmethod
    def from_json(cls, json_data: SingleJson) -> "InternalDomain":
        """Creates an InternalDomain object from a JSON dictionary.

        Args:
            json_data (SingleJson):  A dictionary containing the internal domain data.

        Returns:
            An InternalDomain object.
        """
        return cls(
            alias_name=json_data.get("name", json_data.get("alias")),
            id_=json_data.get("id"),
            domain_display_name=json_data.get("displayName", json_data.get("domain")),
            environments_json=json_data.get(
                "environmentsJson", json_data.get("environments", [])
            ),
            creation_time_unix_time_in_ms=json_data.get("creationTimeUnixTimeInMs", 0),
            modification_time_unix_time_in_ms=json_data.get(
                "modificationTimeUnixTimeInMs", 0
            ),
        )

    def to_json(self) -> SingleJson:
        """
        Converts the InternalDomain object to a JSON-serializable dictionary.
        """
        return {
            "alias": self.alias_name,
            "id": self.id_,
            "domain": self.domain_display_name,
            "environments": self.environments_json,
            "creationTimeUnixTimeInMs": self.creation_time_unix_time_in_ms,
            "modificationTimeUnixTimeInMs": self.modification_time_unix_time_in_ms,
        }


@dataclasses.dataclass(slots=True)
class EmailTemplate:
    """
    Represents an email template.
    """

    template_type: int | str
    name: str
    content: str
    creator_user_name: str
    for_migration: bool
    environments: list[str]
    _id: int
    creation_time_unix_time_in_ms: int
    modification_time_unix_time_in_ms: int

    def to_json(self) -> dict:
        """
        Converts the EmailTemplate object to a JSON-serializable dictionary.
        """
        return {
            "type": self.template_type,
            "name": self.name,
            "content": self.content,
            "creatorUserName": self.creator_user_name,
            "forMigration": self.for_migration,
            "environments": self.environments,
            "id": self._id,
            "creationTimeUnixTimeInMs": self.creation_time_unix_time_in_ms,
            "modificationTimeUnixTimeInMs": self.modification_time_unix_time_in_ms,
        }

    @classmethod
    def from_json(cls, data: SingleJson) -> "EmailTemplate":
        """Creates an EmailTemplate object from a JSON dictionary.

        Args:
            data (SingleJson): A dictionary containing the email template data.

        Returns:
            An EmailTemplate object.
        """
        return cls(
            template_type=data.get("type", data.get("templateType")),
            name=data.get("displayName", data.get("name")),
            content=data.get("content", "{}"),
            creator_user_name=data.get("creatorUserName", data.get("author")),
            for_migration=data.get("forMigration", False),
            environments=data.get("environments", []),
            _id=data.get("id"),
            creation_time_unix_time_in_ms=data.get("creationTimeUnixTimeInMs"),
            modification_time_unix_time_in_ms=data.get("modificationTimeUnixTimeInMs"),
        )

@dataclasses.dataclass(slots=True)
class Environment:
    _id: int
    name: str
    description: str
    contactName: str | None
    contactEmails: str
    contactEmailsList: list[str] | None
    contactPhone: str | None
    allowedActions: list[str] | None
    remediationDurationInDays: int
    shouldAllowRemediationActions: bool
    shouldNotifyOnRemediationActions: bool
    retentionDurationInMonths: int
    retentionDurationInMonthsInternal: int | None
    base64Image: str | None
    forDBMigration: bool
    environmentAllowedForAllUsers: bool
    dynamicParameters: list[DynamicParameter]
    properties: dict
    isSystem: bool
    aliases: list[str]
    instanceUrl: str | None
    dataAccessScopes: list[str]

    @classmethod
    def from_json(cls, json_data: SingleJson) -> "Environment":
        return cls(
            _id=json_data.get("id"),
            name=json_data.get("name"),
            description=json_data.get("description"),
            contactName=json_data.get("contactName"),
            contactEmails=json_data.get("contactEmails"),
            contactEmailsList=json_data.get("contactEmailsList"),
            contactPhone=json_data.get("contactPhone"),
            allowedActions=json_data.get("allowedActions"),
            remediationDurationInDays=json_data.get("remediationDurationInDays"),
            shouldAllowRemediationActions=json_data.get("shouldAllowRemediationActions"),
            shouldNotifyOnRemediationActions=json_data.get("shouldNotifyOnRemediationActions"),
            retentionDurationInMonths=json_data.get("retentionDurationInMonths"),
            retentionDurationInMonthsInternal=json_data.get("retentionDurationInMonthsInternal"),
            base64Image=json_data.get("base64Image"),
            forDBMigration=json_data.get("forDBMigration"),
            environmentAllowedForAllUsers=json_data.get("environmentAllowedForAllUsers"),
            dynamicParameters=[
                DynamicParameter.from_json(p)
                for p in json_data.get("dynamicParameters", [])
            ],
            properties=json_data.get("properties"),
            isSystem=json_data.get("isSystem"),
            aliases=json_data.get("aliases"),
            instanceUrl=json_data.get("instanceUrl"),
            dataAccessScopes=json_data.get("dataAccessScopes"),
        )

    def to_json(self) -> SingleJson:
        return {
            "id": self._id,
            "name": self.name,
            "description": self.description,
            "contactName": self.contactName,
            "contactEmails": self.contactEmails,
            "contactEmailsList": self.contactEmailsList,
            "contactPhone": self.contactPhone,
            "allowedActions": self.allowedActions,
            "remediationDurationInDays": self.remediationDurationInDays,
            "shouldAllowRemediationActions": self.shouldAllowRemediationActions,
            "shouldNotifyOnRemediationActions": self.shouldNotifyOnRemediationActions,
            "retentionDurationInMonths": self.retentionDurationInMonths,
            "retentionDurationInMonthsInternal": self.retentionDurationInMonthsInternal,
            "base64Image": self.base64Image,
            "forDBMigration": self.forDBMigration,
            "environmentAllowedForAllUsers": self.environmentAllowedForAllUsers,
            "dynamicParameters": [p.to_json() for p in self.dynamicParameters],
            "properties": self.properties,
            "isSystem": self.isSystem,
            "aliases": self.aliases,
            "instanceUrl": self.instanceUrl,
            "dataAccessScopes": self.dataAccessScopes,
        }


@dataclasses.dataclass(slots=True)
class IntegrationSetting:
    """Represents a single setting from an integration instance."""
    display_name: str
    property_name: str
    value: Any
    property_type: str
    _id: int
    property_description: str
    is_password: bool
    is_mandatory: bool

    @classmethod
    def from_json(cls, data: SingleJson) -> IntegrationSetting:
        """Parses a setting JSON object."""
        is_password = data.get("propertyType") == 3 or data.get("type") == "Password"

        return cls(
            display_name=data.get("displayName", data.get("propertyDisplayName", "")),
            property_name=data.get("propertyName", ""),
            value=data.get("value"),
            property_type=data.get("type", data.get("propertyType", "")),
            _id=data.get("id"),
            property_description=data.get(
                "propertyDescription",
                data.get("description", ""),
            ),
            is_password=is_password,
            is_mandatory=data.get("mandatory", data.get("isMandatory", False)),
        )



@dataclasses.dataclass(slots=True)
class VisualFamily:
    _id: Any
    family: str
    description: str = ""
    image_base64: str = ""
    is_custom: bool = False
    rules: list[dict] = dataclasses.field(default_factory=list)
    creation_time: int = 0
    modification_time: int = 0

    @classmethod
    def from_json(cls, data: SingleJson) -> VisualFamily:
        return cls(
            _id=data.get("id"),
            family=data.get("family"),
            description=data.get("description", ""),
            image_base64=data.get("imageBase64", ""),
            is_custom=data.get("custom", data.get("isCustom", False)),
            rules=data.get("modelingRules", data.get("rules", [])),
            creation_time=data.get("creationTimeUnixTimeInMs", 0),
            modification_time=data.get("modificationTimeUnixTimeInMs", 0),
        )

    def to_json(self) -> SingleJson:
        return {
            "id": self._id,
            "family": self.family,
            "description": self.description,
            "imageBase64": self.image_base64,
            "isCustom": self.is_custom,
            "rules": self.rules,
            "creationTimeUnixTimeInMs": self.creation_time,
            "modificationTimeUnixTimeInMs": self.modification_time,
        }


@dataclasses.dataclass(slots=True)
class OntologyRecord:
    _id: Any
    source: str
    family_name: str = ""
    family_id: int | None = None
    product: str | None = None
    event_name: str | None = None
    mapping_status: str | None = None
    change_source: Any = None
    example_event_fields: list[dict] = dataclasses.field(default_factory=list)

    @classmethod
    def from_json(cls, data: SingleJson) -> OntologyRecord:
        return cls(
            _id=data.get("id"),
            source=data.get("source"),
            family_name=data.get("visualFamily", data.get("familyName", "")),
            family_id=data.get("familyId"),
            product=data.get("product"),
            event_name=data.get("eventName"),
            mapping_status=data.get("mappingStatus"),
            change_source=data.get("changeSource"),
            example_event_fields=data.get("exampleEventFields", [])
        )


    def to_json(self) -> SingleJson:
        return {
            "id": self._id,
            "source": self.source,
            "familyName": self.family_name,
            "familyId": self.family_id,
            "product": self.product,
            "eventName": self.event_name,
            "mappingStatus": self.mapping_status,
            "changeSource": self.change_source,
            "exampleEventFields": self.example_event_fields,
        }

@dataclasses.dataclass(slots=True)
class CaseTag:
    """Represents a single case tag."""
    value: str
    name: str
    property_name: str
    priority: int
    is_potential_case_name: bool
    environments: list[Any]
    kind: int
    compare_type: int
    identifier: int
    creation_time_unix_time_in_ms: int
    modification_time_unix_time_in_ms: int

    @classmethod
    def from_json(cls, data: SingleJson) -> CaseTag:
        """Parses a case tag JSON object."""
        return cls(
            value=data.get("value", ""),
            name=data.get("name", data.get("displayName")),
            property_name=data.get("propertyName", ""),
            priority=data.get("priority", ""),
            is_potential_case_name=data.get("isPotentialCaseName", data.get("canBeCaseTitle")),
            environments=data.get("environments", []),
            kind=data.get("type", data.get("matchCriteria")),
            compare_type=data.get("compareType", data.get("comparisonType")),
            identifier=data.get("id", None),
            creation_time_unix_time_in_ms=data.get("creationTimeUnixTimeInMs", None),
            modification_time_unix_time_in_ms=data.get("modificationTimeUnixTimeInMs", None),
        )

    def to_json(self) -> SingleJson:
        """Converts the CaseTag object to a JSON-serializable dictionary."""
        return {
            "value": self.value,
            "name": self.name,
            "propertyName": self.property_name,
            "priority": self.priority,
            "isPotentialCaseName": self.is_potential_case_name,
            "environments": self.environments,
            "type": self.kind,
            "compareType": self.compare_type,
            "id": self.identifier,
            "creationTimeUnixTimeInMs": self.creation_time_unix_time_in_ms,
            "modificationTimeUnixTimeInMs": self.modification_time_unix_time_in_ms,
        }

    def to_json_1p(self) -> SingleJson:
        return {
            "displayName": self.name,
            "matchCriteria": self.kind,
            "value": self.value,
            "propertyName": self.property_name,
            "comparisonType": self.compare_type,
            "priority": self.priority,
            "canBeCaseTitle": self.is_potential_case_name,
        }


@dataclasses.dataclass(slots=True)
class Domain:
    domain: str
    alias: str | None
    environments: list[Any]
    identifier: int
    creation_time_unix_time_in_ms: int
    modification_time_unix_time_in_ms: int

    @classmethod
    def from_legacy_or_1p(cls, data: SingleJson) -> "Domain":
        if "environments" in data:
            envs = data.get("environments") or []
        else:
            raw = data.get("environmentsJson", "[]") or "[]"
            try:
                envs = json.loads(raw)
            except Exception:
                envs = []

        return cls(
            domain=data.get("domain", data.get("displayName", "")),
            alias=data.get("alias"),
            environments=envs,
            identifier=data.get("id"),
            creation_time_unix_time_in_ms=data.get("creationTimeUnixTimeInMs", 0),
            modification_time_unix_time_in_ms=data.get("modificationTimeUnixTimeInMs", 0),
        )

    def to_legacy(self) -> SingleJson:
        return {
            "domain": self.domain,
            "alias": self.alias,
            "environments": self.environments,
            "id": self.identifier,
            "creationTimeUnixTimeInMs": self.creation_time_unix_time_in_ms,
            "modificationTimeUnixTimeInMs": self.modification_time_unix_time_in_ms,
        }

    def to_1p(self) -> SingleJson:
        return {
            "displayName": self.domain,
            "environmentsJson": json.dumps(self.environments),
        }


@dataclasses.dataclass(slots=True)
class CaseStage:
    name: str
    order: int
    identifier: int
    creation_time_unix_time_in_ms: int
    modification_time_unix_time_in_ms: int

    @classmethod
    def from_legacy_or_1p(cls, data: SingleJson) -> "CaseStage":
        return cls(
            name=data.get("name", data.get("displayName", "")),
            order=data.get("order", 0),
            identifier=data.get("id"),
            creation_time_unix_time_in_ms=data.get("creationTimeUnixTimeInMs"),
            modification_time_unix_time_in_ms=data.get("modificationTimeUnixTimeInMs"),
        )

    def to_legacy(self) -> SingleJson:
        return {
            "name": self.name,
            "order": self.order,
            "id": self.identifier,
            "creationTimeUnixTimeInMs": self.creation_time_unix_time_in_ms,
            "modificationTimeUnixTimeInMs": self.modification_time_unix_time_in_ms,
        }

    def to_1p(self) -> SingleJson:
        return {
            "displayName": self.name,
            "order": self.order,
        }

@dataclasses.dataclass(slots=True)
class CaseCloseReasons:
    identifier: int
    root_cause: str
    close_reason: str | None
    creation_time_unix_time_in_ms: int | None
    modification_time_unix_time_in_ms: int | None

    @classmethod
    def from_legacy_or_1p(cls, data: dict) -> "CaseCloseReasons":
        return cls(
            identifier=data.get("id"),
            root_cause=data.get("rootCause", ""),
            close_reason=data.get("forCloseReason", 0) 
                         or data.get("closeReason", 0),
            creation_time_unix_time_in_ms=data.get("creationTimeUnixTimeInMs"),
            modification_time_unix_time_in_ms=data.get("modificationTimeUnixTimeInMs"),
        )

    def to_legacy(self) -> dict:
        return {
            "rootCause": self.root_cause,
            "forCloseReason": self.close_reason,
            "id": self.identifier,
            "creationTimeUnixTimeInMs": self.creation_time_unix_time_in_ms,
            "modificationTimeUnixTimeInMs": self.modification_time_unix_time_in_ms,
        }

    def to_1p(self) -> dict:
        return {
            "id": self.identifier,
            "rootCause": self.root_cause,
            "closeReason": self.close_reason,
        }

@dataclasses.dataclass(slots=True)
class CustomList:
    entity_identifier: str
    category: str
    for_db_migration: bool | None
    environments: list[Any]
    identifier: int
    creation_time_unix_time_in_ms: int
    modification_time_unix_time_in_ms: int

    @classmethod
    def from_legacy_or_1p(cls, data: SingleJson) -> "CustomList":
        return cls(
            entity_identifier=data.get("entityIdentifier", ""),
            category=data.get("category", ""),
            for_db_migration=data.get("forDBMigration"),
            environments=data.get("environments", []),
            identifier=data.get("id"),
            creation_time_unix_time_in_ms=data.get("creationTimeUnixTimeInMs"),
            modification_time_unix_time_in_ms=data.get("modificationTimeUnixTimeInMs"),
        )

    def to_legacy(self) -> SingleJson:
        return {
            "entityIdentifier": self.entity_identifier,
            "category": self.category,
            "forDBMigration": self.for_db_migration,
            "environments": self.environments,
            "id": self.identifier,
            "creationTimeUnixTimeInMs": self.creation_time_unix_time_in_ms,
            "modificationTimeUnixTimeInMs": self.modification_time_unix_time_in_ms,
        }

    def to_1p(self) -> SingleJson:
        return {
            "category": self.category,
            "entityIdentifier": self.entity_identifier,
            "environments": ",".join(self.environments) if self.environments else "",
        }


@dataclasses.dataclass(slots=True)
class Blacklist:
    entity_identifier: str
    entity_type: str
    action: int
    environments: list[Any]
    scope: int | None
    identifier: int

    @classmethod
    def from_legacy_or_1p(cls, data: SingleJson) -> "Blacklist":
        return cls(
            entity_identifier=data.get("entityIdentifier", ""),
            entity_type=data.get("entityType", ""),
            action=data.get("elementType", data.get("action", 0)),
            environments=data.get("environments", []),
            scope=data.get("scope"),
            identifier=data.get("id"),
        )

    def to_legacy(self) -> SingleJson:
        return {
            "id": self.identifier,
            "entityIdentifier": self.entity_identifier,
            "entityType": self.entity_type,
            "elementType": self.action,
            "scope": self.scope,
            "environments": self.environments,
        }

    def to_1p(self) -> SingleJson:
        return {
            "entityIdentifier": self.entity_identifier,
            "entityType": self.entity_type,
            "action": self.action,
            "environmentsJson": ",".join(self.environments) if self.environments else "",
        }


@dataclasses.dataclass(slots=True)
class Network:
    name: str
    address: str
    priority: int
    environments: list[Any]
    identifier: int
    creation_time_unix_time_in_ms: int | None
    modification_time_unix_time_in_ms: int | None

    @classmethod
    def from_legacy_or_1p(cls, data: dict) -> "Network":
        # environments can come from legacy (list) or 1p (string → JSON list)
        envs = data.get("environments")
        if envs is None:
            envs_json = data.get("environmentsJson")
            if isinstance(envs_json, str):
                try:
                    envs = json.loads(envs_json)
                except Exception:
                    envs = []
            else:
                envs = []

        return cls(
            name=data.get("name", data.get("displayName", "")),
            address=data.get("address", ""),
            priority=data.get("priority", 0),
            environments=envs,
            identifier=data.get("id"),
            creation_time_unix_time_in_ms=data.get("creationTimeUnixTimeInMs"),
            modification_time_unix_time_in_ms=data.get("modificationTimeUnixTimeInMs"),
        )

    def to_legacy(self) -> dict:
        return {
            "address": self.address,
            "name": self.name,
            "priority": self.priority,
            "environments": self.environments,
            "id": self.identifier,
            "creationTimeUnixTimeInMs": self.creation_time_unix_time_in_ms,
            "modificationTimeUnixTimeInMs": self.modification_time_unix_time_in_ms,
        }

    def to_1p(self) -> dict:
        return {
            "name": f"projects/project/locations/location/instances/instance/internalNetworks/{self.identifier}",
            "id": self.identifier,
            "displayName": self.name,
            "address": self.address,
            "environmentsJson": json.dumps(self.environments),
            "priority": self.priority,
        }


@dataclasses.dataclass(slots=True)
class SlaDefinition:
    identifier: int
    value_type: int
    value: str
    sla_period_type: int
    sla_period: float
    critical_period_type: int
    critical_period: float
    environments: list[Any]
    alert_type: int
    values: list[str]

    @classmethod
    def from_legacy_or_1p(cls, data: dict) -> "SlaDefinition":
        return cls(
            identifier=data.get("id"),
            value_type=data.get("valueType", 0),
            value=data.get("value", ""),
            sla_period_type=data.get("slaPeriodType", 0),
            sla_period=data.get("slaPeriod", 0.0),
            critical_period_type=data.get("criticalPeriodType", 0),
            critical_period=data.get("criticalPeriod", 0.0),
            environments=data.get("environments", []),
            alert_type=data.get("alertType", 0),
            values=data.get("values", []),
        )

    def to_legacy(self) -> dict:
        return {
            "id": self.identifier,
            "valueType": self.value_type,
            "value": self.value,
            "slaPeriodType": self.sla_period_type,
            "slaPeriod": self.sla_period,
            "criticalPeriodType": self.critical_period_type,
            "criticalPeriod": self.critical_period,
            "environments": self.environments,
            "alertType": self.alert_type,
            "values": self.values,
        }

    def to_1p(self) -> dict:
        return {
            "name": f"projects/project/locations/location/instances/instance/slaDefinitions/{self.identifier}",
            "id": self.identifier,

            "slaType": "AlertRuleGenerator",
            "alertType": "AllAlerts",

            "slaTypeValue": self.value,
            "slaPeriod": self.sla_period,
            "slaPeriodTimeUnit": "Minutes",

            "criticalSlaPeriod": self.critical_period,
            "criticalSlaPeriodTimeUnit": "Minutes",

            "environments": self.environments,
        }
