from __future__ import annotations

import copy
import json
from abc import abstractmethod
from typing import Iterable, Mapping, TypeVar

from Siemplify import CASE_FILTER_MAX_RESULTS
from SiemplifyDataModel import (
    CaseFilterOperatorEnum,
    CaseFilterSortByEnum,
    CaseFilterSortOrderEnum,
    CaseFilterStatusEnum,
)
from SiemplifyUtils import validate_property_value

from .consts import (
    CASE_SLO_DAYS_INTERVALS,
    CASE_TICKET_MAP_DB_KEY,
    CASE_TICKET_MAP_FILE_NAME,
    EXTERNAL_SCC_TICKET_INFO,
)
from .data_models import (
    CaseIterationResult,
    CaseIterationSetup,
    ExternalSCCTicketInfo,
    ITSMTicketDetailsForSCC,
    SOARCaseDetailsForSCC,
    TicketIterationSetup,
)
from ...base.action.data_models import CloseCaseOrAlertMaintenanceRootCauses
from ...data_models import CaseDetails
from ...base.job import Job
from ...soar_ops import (
    create_slo_message,
    get_soar_case_comments,
    is_slo_comment,
    remove_prefix_from_comments,
)
from ...consts import NUM_OF_MILLI_IN_SEC, SOAR_COMMENT_PREFIX, UNIX_FORMAT
from ...data_models import CaseDataStatus
from ...exceptions import GeneralJobException, InternalJSONDecoderError
from ...rest.soar_api import get_case_overview_details
from ...smp_io import read_ids, write_ids_with_timestamp
from ...smp_time import get_last_success_time, siemplify_save_timestamp
from ...utils import get_unique_items_by_difference, none_to_default_value


CLOSE_CASE_ROOT_CAUSE = CloseCaseOrAlertMaintenanceRootCauses.OTHER.value
CLOSE_CASE_REASON = 'Maintenance'
CLOSE_CASE_COMMENT = 'Closed by Chronicle SOAR - SCC <-> ITSM Sync Job'

DEFAULT_HOURS_BACKWARDS = 0

_T = TypeVar('_T')
Manager = TypeVar('Manager')


class SyncCommentError(GeneralJobException):
    """Sync comments error"""


class SyncSoarITSM(Job):
    def __init__(self, script_name: str, integration_name: str) -> None:
        super().__init__(script_name)
        self.itsm_comment_prefix = f'{integration_name}: '

    # ==================== Abstract Methods ==================== #

    @abstractmethod
    def _get_ticket_id_to_comments_map(
            self,
            manager: Manager,
            ticket: _T,
    ) -> Mapping[str, list[str]]:
        """Creates a map of ticket ID -> ticket comments for a single ticket

        The mapping should follow this structure:
        {
            "ticket_id": [
                "comment 1",
                "comment 2",
                "comment 3"
            ]
        }

        Args:
            manager: The integration's manager
            ticket:
                A ticket containing the relevant ticket details.
                (The type of ticket is the same type the following
                _get_ticket_id_to_details_map and
                _get_bulk_ticket_id_to_details_map methods return as the
                values for each ticket ID)

        Raises:
            NotImplementedError: If not overridden

        Returns:
            A mapping that takes a specific ticket ID to its comments
        """
        raise NotImplementedError

    @abstractmethod
    def _get_bulk_ticket_id_to_comments_map(
            self,
            manager: Manager,
            tickets: Iterable[_T],
    ) -> Mapping[str, list[str]]:
        """Creates a map of ticket ID -> ticket comments for multiple ticket IDs

        The mapping should follow this structure:
        {
            "ticket_id 1": [
                "comment 1",
                "comment 2",
                "comment 3"
            ],
            "ticket_id 2": [
                "comment 1",
                "comment 2",
                "comment 3"
            ]
        }

        Args:
            manager: The integration's manager
            tickets:
                An iterable obj containing tickets with ticket details.
                (The type of each ticket is the same type that the following
                _get_ticket_id_to_details_map and
                _get_bulk_ticket_id_to_details_map methods return as the
                values for each ticket ID)

        Raises:
            NotImplementedError: If not overridden

        Returns:
            A mapping that takes each specific ticket ID to its comments
        """
        raise NotImplementedError

    @abstractmethod
    def _get_ticket_id_to_details_map(
            self,
            manager: Manager,
            ticket_id: str,
    ) -> Mapping[str, _T]:
        """Creates a map of ticket ID -> ticket details for a single ticket ID

        The type of the values in the returned mapping could be anything,
        and is the value that will be passed and is expected from the following
        _get_ticket_id_to_comments_map() and
        _get_bulk_ticket_id_to_comments_map() methods as their argument.
        Please make sure they are aligned

        Args:
            manager: The integration's manager
            ticket_id: The ticket ID whose details should be requested

        Raises:
            NotImplementedError: If not overridden

        Returns:
            A mapping that takes a specific ticket ID to its correlating details
        """
        raise NotImplementedError

    @abstractmethod
    def _get_bulk_ticket_id_to_details_map(
            self,
            manager: Manager,
            ticket_ids: Iterable[str],
    ) -> Mapping[str, _T]:
        """Creates a map of ticket ID -> ticket details for multiple ticket IDs

        The type of the values in the mapping could be anything, and is the
        value that will be passed and is expected from the
        _get_ticket_id_to_comments_map and
        _get_bulk_ticket_id_to_comments_map methods as an argument.
        Please make sure they are aligned

        Args:
            manager: The integration's manager
            ticket_ids:
                An iterable object containing the IDs that their details should
                be requested in bulk

        Raises:
            NotImplementedError: If not overridden

        Returns:
            A mapping that takes all ticket IDs to their correlating details
        """
        raise NotImplementedError

    @abstractmethod
    def _add_comment_to_ticket(
            self,
            manager: Manager,
            comment: str,
            ticket_id: str,
    ) -> None:
        """Send a comment to a ticket by the ticket ID

        Args:
            manager: The integration's manager
            comment: The comment to add to the ticket
            ticket_id: The ticket ID that the comment should be added to

        Raises:
            NotImplementedError: If not overridden
        """
        raise NotImplementedError

    @abstractmethod
    def _parse_ticket_details_for_scc(
            self,
            ticket: _T,
    ) -> ITSMTicketDetailsForSCC:
        """Parse a ticket to it's correlating ITSMTicketDetailsForSCC object

        This is done to update the external SCC info with new updates about
        the ticket details.

        Args:
            ticket:
            The ticket that has the ticket's relevant data
            (The type of ticket is the same type that the following
            _get_ticket_id_to_details_map and
            _get_bulk_ticket_id_to_details_map methods return as the
            values for each ticket ID)

        Raises:
            NotImplementedError: If not overridden

        Returns:
            An object that will be used for updating external SCC info
        """
        raise NotImplementedError

    @abstractmethod
    def _close_ticket(
            self,
            manager: Manager,
            ticket_id: str,
    ) -> None:
        """Close a ticket by its ticket ID

        Args:
            manager: The integration's manager_
            ticket_id: The ID of the ticket that should be closed

        Raises:
            NotImplementedError: If not overridden
        """
        raise NotImplementedError

    @abstractmethod
    def _get_ticket_status(self, ticket: _T) -> str:
        """Extract the ticket status from the ticket object

        Args:
            ticket:
                The ticket that has the ticket's relevant data
                (The type of ticket is the same type that the following
                _get_ticket_id_to_details_map and
                _get_bulk_ticket_id_to_details_map methods return as the
                values for each ticket ID)

        Raises:
            NotImplementedError: If not overridden

        Returns:
            The ticket's status - should match the statuses format in the
            "Closing Statuses" parameter values
        """
        raise NotImplementedError

    @abstractmethod
    def _get_ticket_possible_close_statuses(self) -> Iterable[str]:
        """Get the ticket possible closed statuses

        Raises:
            NotImplementedError: If not overridden

        Returns:
            An iterable object with the possible closing statuses of the ticket
        """
        raise NotImplementedError

    @abstractmethod
    def _get_environment_for_case_filter(self) -> str | None:
        """Get an environment to filter cases by.

        If None is returned, it will not filter by environments

        Raises:
            NotImplementedError: If not overridden

        Returns:
            A str representing the environment if a case filter by env is needed
            Return None if noe case filter by env is needed
        """
        raise NotImplementedError

    @abstractmethod
    def _get_max_hours_backwards(self) -> int | None:
        """Get the job's max hours backwards.

        If None is returned, it will use 0 for hours backward time lookup

        Raises:
            NotImplementedError: If not overridden

        Returns:
            The max hours backwards to look for cases
        """
        raise NotImplementedError

    # ==================== Job protected Methods ==================== #

    def _perform_job(self, manager: Manager) -> None:
        """Perform the main flow of an SCC <-> ITSM job

        Args:
            manager: The integration's manager object
        """
        ticket_close_statuses = self._get_ticket_possible_close_statuses()

        max_hours_backwards = none_to_default_value(
            value_to_check=self._get_max_hours_backwards(),
            value_to_return_if_none=DEFAULT_HOURS_BACKWARDS,
        )

        last_run_timestamp = get_last_success_time(
            self.soar_job,
            offset_with_metric={'hours': max_hours_backwards},
            time_format=UNIX_FORMAT,
        )
        self.logger.info(
            f'Last successful execution timestamp: {last_run_timestamp}'
        )

        self.logger.info('Reading IDs')
        case_id_to_ticket_ids_mapping: dict[str, str] = read_ids(
            self.soar_job,
            db_key=CASE_TICKET_MAP_DB_KEY,
            ids_file_name=CASE_TICKET_MAP_FILE_NAME,
            default_value_to_return={}
        )

        case_iter_setup = self._case_iteration_setup(
            manager=manager,
            last_run_timestamp=last_run_timestamp,
            cached_ticket_ids=case_id_to_ticket_ids_mapping.values(),
        )

        checked_tickets = set()
        case_iter_result = self._case_iteration(
            manager=manager,
            case_iter_setup=case_iter_setup,
            checked_tickets=checked_tickets,
            ticket_close_statuses=ticket_close_statuses,
            case_id_to_ticket_ids_mapping=case_id_to_ticket_ids_mapping,
        )

        # Sync tickets that are correlated to cases that weren't modified
        ticket_iter_setup = self._ticket_iteration_setup(
            manager=manager,
            checked_tickets=checked_tickets,
            case_id_to_ticket_ids_mapping=case_id_to_ticket_ids_mapping,
        )

        closed_cases = self._ticket_iteration(
            manager=manager,
            ticket_iter_setup=ticket_iter_setup,
            ticket_close_statuses=ticket_close_statuses,
            case_id_to_ticket_ids_mapping=case_id_to_ticket_ids_mapping,
        )

        self.logger.info('----------------- Finished Syncing -----------------')
        self.logger.info('Saving timestamp')
        siemplify_save_timestamp(
            self.soar_job,
            new_timestamp=self.job_start_time,
        )

        closed_cases = closed_cases or case_iter_result.closed_cases
        if case_iter_result.added_cases or closed_cases:
            self.logger.info('Writing IDs as cases were added or removed')

            write_ids_with_timestamp(
                self.soar_job,
                ids=case_id_to_ticket_ids_mapping,
                db_key=CASE_TICKET_MAP_DB_KEY,
                ids_file_name=CASE_TICKET_MAP_FILE_NAME,
            )

    def _ticket_iteration_setup(
            self,
            manager: Manager,
            checked_tickets: set[str],
            case_id_to_ticket_ids_mapping: Mapping[str, str]
    ) -> TicketIterationSetup:
        # Sync tickets that are correlated to cases that weren't modified
        ticket_id_to_case_id_map = {
            ticket_id: case_id
            for case_id, ticket_id in case_id_to_ticket_ids_mapping.items()
            if ticket_id not in checked_tickets
        }

        self.logger.info(
            f'Found {len(ticket_id_to_case_id_map)} cached tickets which their '
            'correlated case was not updated'
        )

        ticket_id_to_details = {}
        ticket_id_to_comments = {}
        if ticket_id_to_case_id_map:
            self.logger.info('Getting bulk ticket details')
            ticket_id_to_details = self._get_bulk_ticket_id_to_details_map(
                manager=manager,
                ticket_ids=ticket_id_to_case_id_map.keys(),
            )
            self.logger.info('Getting bulk ticket comments')
            ticket_id_to_comments = self._get_bulk_ticket_id_to_comments_map(
                manager=manager,
                tickets=ticket_id_to_details.values(),
            )

        return TicketIterationSetup(
            ticket_id_to_case_id=ticket_id_to_case_id_map,
            ticket_id_to_details=ticket_id_to_details,
            ticket_id_to_comments=ticket_id_to_comments,
        )

    def _case_iteration_setup(
            self,
            manager: Manager,
            cached_ticket_ids: Iterable[str],
            last_run_timestamp: int,
    ) -> CaseIterationSetup:
        ticket_id_to_ticket_details = {}
        ticket_id_to_ticket_comments = {}
        if cached_ticket_ids:
            self.logger.info('Fetching bulk ITSM tickets details')
            ticket_id_to_ticket_details = (
                self._get_bulk_ticket_id_to_details_map(
                    manager=manager,
                    ticket_ids=cached_ticket_ids,
                )
            )

            self.logger.info("Fetching bulk ITSM tickets comments")
            ticket_id_to_ticket_comments = (
                self._get_bulk_ticket_id_to_comments_map(
                    manager=manager,
                    tickets=ticket_id_to_ticket_details.values(),
                )
            )

        self.logger.info('Fetching filtered SOAR case IDs')
        case_ids: list[int] = self.soar_job.get_cases_ids_by_filter(
            status=CaseFilterStatusEnum.BOTH,
            update_time_from_unix_time_in_ms=last_run_timestamp,
            start_time_from_unix_time_in_ms=last_run_timestamp,
            operator=CaseFilterOperatorEnum.OR,
            sort_by=CaseFilterSortByEnum.UPDATE_TIME,
            sort_order=CaseFilterSortOrderEnum.ASC,
            max_results=CASE_FILTER_MAX_RESULTS,
            # tags=[EXTERNAL_SCC_TICKET_INFO]
            # environment=[self.environment]
        )
        self.logger.info(f'Fetched {len(case_ids)} cases that were modified')

        return CaseIterationSetup(
            case_ids=case_ids,
            ticket_id_to_ticket_details=ticket_id_to_ticket_details,
            ticket_id_to_ticket_comments=ticket_id_to_ticket_comments,
        )

    def _ticket_iteration(
            self,
            manager: Manager,
            ticket_close_statuses: Iterable[str],
            ticket_iter_setup: TicketIterationSetup,
            case_id_to_ticket_ids_mapping: dict[str, str]
    ) -> bool:
        # FIXME: Note that it can go over all cached tickets.
        #        Would it be better to fetch all recently updated ticket ids
        #        and filter them by take only the ones in cache to have only
        #        cached updated tickets? It will require an additional call
        #        to fetch all the numbers in bulk instead of going over all
        #        cached tickets and either trying to sync them, or at least
        #        checking their last mod time and skip the current one if
        #        it wasn't updated recently
        closed_cases = False
        for ticket_id, ticket in ticket_iter_setup.ticket_id_to_details.items():
            try:
                self.logger.info(f'==> Going over ticket ID {ticket_id}')

                case_id = str(ticket_iter_setup.ticket_id_to_case_id[ticket_id])

                self.logger.info('Reading case context property')
                case_context_property_json = self._get_case_context_property(
                    case_id=case_id,
                    property_key=EXTERNAL_SCC_TICKET_INFO
                )

                case_context_property_json = self._parse_case_context(
                    case_context_property_json
                )
                ext_scc_ticket_info = ExternalSCCTicketInfo.from_json(
                    case_context_property_json
                )
                og_ext_scc_info = ExternalSCCTicketInfo.from_obj(
                    ext_scc_ticket_info
                )

                # Sync ticket comments
                self.logger.info(f'Getting comments for case No {case_id}')
                case_comments = get_soar_case_comments(self.soar_job, case_id)

                self.logger.info(
                    f'Syncing comments for case with ID {case_id} and ticket '
                    f'with ID {ticket_id}'
                )
                ticket_comments = (
                    ticket_iter_setup.ticket_id_to_comments[ticket_id]
                )
                self._sync_soar_case_and_itsm_ticket_comments(
                    manager=manager,
                    case_id=case_id,
                    itsm_ticket_id=ticket_id,
                    soar_comments=[c.comment for c in case_comments],
                    itsm_comments=ticket_comments,
                )

                self.logger.info('Fetching case overview details')
                case_details = get_case_overview_details(self.soar_job, case_id)

                # Check correlated case SLO
                self._check_and_send_slo_warning(
                    manager=manager,
                    case_details=case_details,
                    itsm_ticket_id=ticket_id,
                    itsm_comments=ticket_comments,
                )

                # Check if ticket status is changed
                ticket_status = self._get_ticket_status(ticket)
                if (
                        ticket_status in ticket_close_statuses and
                        case_details.status == CaseDataStatus.OPENED
                ):
                    self.logger.info(
                        'The ticket is closed but the case is still open, '
                        'closing the correlated case'
                    )
                    self.soar_job.close_case(
                        case_id=case_id,
                        comment=CLOSE_CASE_COMMENT,
                        reason=CLOSE_CASE_REASON,
                        root_cause=CLOSE_CASE_ROOT_CAUSE,
                        alert_identifier=case_details.alerts[0].identifier,
                    )
                    ext_scc_ticket_info.case.sync_case = False
                    case_id_to_ticket_ids_mapping.pop(case_id, None)
                    closed_cases = True

                # Check if ticket SCC data was updated
                self.logger.info('Checking for updated ticket data')
                scc_ticket_details = self._parse_ticket_details_for_scc(ticket)

                ext_scc_ticket_info.update_by_ticket_details(scc_ticket_details)

                self._update_ext_info(og_ext_scc_info, ext_scc_ticket_info)

                # TODO: After close cases will update the case mod time,
                #  check if we actually need to look for
                #  closed case - opened ticket
                #  or is this case covered in the prev for loop
                #  (Should be covered but the bug makes it untestable)

            except Exception as e:
                self.logger.error('------- Failed to sync ticket -------')
                self.logger.error(
                    f'Failed to sync ticket {ticket_id} with its correlating '
                    'case'
                )
                self.logger.error(f'Error: {e}')
                self.logger.exception(e)

        return closed_cases

    def _case_iteration(
            self,
            manager: Manager,
            ticket_close_statuses: Iterable[str],
            case_iter_setup: CaseIterationSetup,
            case_id_to_ticket_ids_mapping: dict[str, str],
            checked_tickets: set[str],
    ) -> CaseIterationResult:
        closed_cases = False
        added_cases = False
        for case_id in case_iter_setup.case_ids:
            try:
                case_id = str(case_id)
                self.logger.info(f'==> Going over case No. {case_id}')

                # TODO: When bulks are ready,
                #  use this only when case not in stored IDs
                self.logger.info('Fetching case overview details')
                case_details = get_case_overview_details(self.soar_job, case_id)

                # FIXME: Filter tag -
                #            this should be part of requesting the cases
                # FIXME: Filter env -
                #            this should be part of requesting the cases
                if EXTERNAL_SCC_TICKET_INFO not in case_details.tags:
                    self.logger.info(
                        "Skipping the case because it doesn't have the correct "
                        f'tag.\nRequired tag: {EXTERNAL_SCC_TICKET_INFO}, '
                        f'Existing tags: {case_details.tags}'
                    )
                    continue

                env = self._get_environment_for_case_filter()
                if env is not None and case_details.environment != env:
                    self.logger.info(
                        "Skipping the case because it doesn't belong to the "
                        'correct environment.\n'
                        f'Required environment: {env}, '
                        f'Case environment: {case_details.environment}'
                    )
                    continue

                self.logger.info('Reading case context property')
                case_context_property_json = self._get_case_context_property(
                    case_id=case_id,
                    property_key=EXTERNAL_SCC_TICKET_INFO
                )

                if not case_context_property_json:
                    self.logger.info('No case context was found. Skipping...')
                    case_id_to_ticket_ids_mapping.pop(case_id, None)
                    continue

                case_context_property_json = self._parse_case_context(
                    case_context_property_json
                )

                ext_scc_ticket_info = ExternalSCCTicketInfo.from_json(
                    case_context_property_json
                )
                og_ext_scc_info = ExternalSCCTicketInfo.from_obj(
                    ext_scc_ticket_info
                )

                if not ext_scc_ticket_info.case.sync_case:
                    self.logger.info(
                        'Case context is marked with sync_case=False. '
                        'Skipping...'
                    )
                    case_id_to_ticket_ids_mapping.pop(case_id, None)
                    continue

                self.logger.info('Getting case comments')
                case_comments = get_soar_case_comments(self.soar_job, case_id)

                itsm_ticket_id = ext_scc_ticket_info.ticket.id_
                self.logger.info(f'Correlated ticket ID: {itsm_ticket_id}')

                # Get case/ticket details and comments if missing in bulk
                if case_id not in case_id_to_ticket_ids_mapping:
                    copy_ids = copy.deepcopy(case_id_to_ticket_ids_mapping)
                    copy_ids[case_id] = itsm_ticket_id
                    if validate_property_value(copy_ids):
                        self.logger.info(
                            'Case ID was not in the stored IDs. '
                            'Fetching its ticket details and comments and '
                            'adding to the stored IDs'
                        )
                        added_cases = True
                        case_id_to_ticket_ids_mapping[case_id] = itsm_ticket_id

                    else:
                        self.logger.info(
                            'Case ID was not in the stored IDs, but IDs cache '
                            'is full and cannot store more IDs'
                        )

                    ticket_details_map = self._get_ticket_id_to_details_map(
                        manager=manager,
                        ticket_id=itsm_ticket_id,
                    )
                    ticket_details = ticket_details_map[itsm_ticket_id]

                    itsm_comments_map = self._get_ticket_id_to_comments_map(
                        manager=manager,
                        ticket=ticket_details,
                    )
                    itsm_comments = itsm_comments_map[itsm_ticket_id]

                else:  # Taking ticket details and comments from bulk data
                    self.logger.info(
                        'Case ID was found in stored IDs, taking ticket '
                        'details and comments from the fetched bulk data'
                    )
                    ticket_details = (
                        case_iter_setup.ticket_id_to_ticket_details[
                            itsm_ticket_id
                        ]
                    )
                    itsm_comments = (
                        case_iter_setup.ticket_id_to_ticket_comments[
                            itsm_ticket_id
                        ]
                    )

                ticket_status = self._get_ticket_status(ticket_details)
                ticket_is_closed = ticket_status in ticket_close_statuses
                case_is_closed = case_details.status == CaseDataStatus.CLOSED

                if ticket_is_closed and case_is_closed:
                    self.logger.info(
                        'Both the case and the ticket are closed. '
                        "Deleting the case ID from the stored IDs if it's "
                        'there. Skipping case...'
                    )
                    ext_scc_ticket_info.case.sync_case = False
                    case_id_to_ticket_ids_mapping.pop(case_id, None)
                    continue

                self.logger.info(
                    f'Syncing comments for case with ID {case_id} and ticket '
                    f'with ID {itsm_ticket_id}'
                )
                soar_comments = [comment.comment for comment in case_comments]
                self._sync_soar_case_and_itsm_ticket_comments(
                    manager=manager,
                    case_id=case_id,
                    itsm_ticket_id=itsm_ticket_id,
                    soar_comments=soar_comments,
                    itsm_comments=itsm_comments,
                )

                if not ticket_is_closed and case_is_closed:
                    self.logger.info(
                        'The case status is closed, but the ticket is not, '
                        'closing the correlated ticket '
                        'and removing it from case IDs cache'
                    )
                    self._close_ticket(
                        manager=manager,
                        ticket_id=itsm_ticket_id,
                    )
                    ext_scc_ticket_info.case.sync_case = False
                    case_id_to_ticket_ids_mapping.pop(case_id, None)
                    closed_cases = True

                else:
                    self._check_and_send_slo_warning(
                        manager=manager,
                        case_details=case_details,
                        itsm_ticket_id=itsm_ticket_id,
                        itsm_comments=itsm_comments,
                    )

                case_is_opened = case_details.status == CaseDataStatus.OPENED
                if ticket_is_closed and case_is_opened:
                    self.logger.info(
                        'The ticket is closed but the case is still opened, '
                        'closing the correlated case'
                    )
                    self.soar_job.close_case(
                        case_id=case_id,
                        root_cause=CLOSE_CASE_ROOT_CAUSE,
                        reason=CLOSE_CASE_REASON,
                        comment=CLOSE_CASE_COMMENT,
                        alert_identifier=case_details.alerts[0].identifier
                    )
                    ext_scc_ticket_info.case.sync_case = False
                    case_id_to_ticket_ids_mapping.pop(case_id, None)
                    closed_cases = True

                self.logger.info('Checking for updated case data')
                scc_case_details = self._parse_case_details_for_scc(
                    case=case_details,
                    current_ext_scc_case_info=ext_scc_ticket_info.case,
                )
                self.logger.info('Checking for updated ticket data')
                scc_ticket_details = self._parse_ticket_details_for_scc(
                    ticket=ticket_details,
                )

                ext_scc_ticket_info.update_by_case_details(scc_case_details)
                ext_scc_ticket_info.update_by_ticket_details(scc_ticket_details)

                self._update_ext_info(og_ext_scc_info, ext_scc_ticket_info)

                checked_tickets.add(itsm_ticket_id)

            except Exception as e:
                self.logger.error('------- Failed to sync case -------')
                self.logger.error(
                    f'Failed to sync case {case_id} with its correlating ticket'
                )
                self.logger.error(f'Error: {e}')
                self.logger.exception(e)

        return CaseIterationResult(
            added_cases=added_cases,
            closed_cases=closed_cases,
        )

    def _sync_soar_case_and_itsm_ticket_comments(
            self,
            manager: Manager,
            case_id: str,
            itsm_ticket_id: str,
            soar_comments: list[str],
            itsm_comments: list[str],
    ) -> None:
        """Sync comments of SOAR case and ITSM ticket

        Args:
            manager: The manager of the ITSM integration
            case_id: The ID of the case to be synced
            itsm_ticket_id: The ID of the ticket to be synced
            soar_comments: All SOAR case comments
            itsm_comments: All ITSM ticket comments

        Raises:
            SyncCommentError: If failed to sync due to  any error that may occur
        """
        try:
            # Remove prefix for comment comparison
            soar_comments = remove_prefix_from_comments(
                comments=soar_comments,
                prefix=self.itsm_comment_prefix,
            )
            itsm_comments = remove_prefix_from_comments(
                comments=itsm_comments,
                prefix=SOAR_COMMENT_PREFIX,
            )

            # Filter SLO comments from the ticket
            # SLO comment is considered without the prefix
            itsm_comments = [
                comment for comment in itsm_comments
                if not is_slo_comment(comment)
            ]

            new_soar_case_comments = get_unique_items_by_difference(
                item_pool=soar_comments,
                items_to_remove=itsm_comments,
            )
            new_itsm_ticket_comments = get_unique_items_by_difference(
                item_pool=itsm_comments,
                items_to_remove=soar_comments,
            )

            if new_soar_case_comments:
                self.soar_job.LOGGER.info(
                    f'Found {len(new_soar_case_comments)} comments to add '
                    f'to ITSM ticket {itsm_ticket_id}.\nAdding comments'
                )
                self._send_soar_comments_to_itsm(
                    manager=manager,
                    new_soar_comments=new_soar_case_comments,
                    ticket_id=itsm_ticket_id,
                )

            if new_itsm_ticket_comments:
                self.soar_job.LOGGER.info(
                    f'Found {len(new_itsm_ticket_comments)} comments to '
                    f'add Chronicle SOAR case {case_id}.\nAdding comments'
                )
                self._send_itsm_comments_to_soar(
                    case_id=case_id,
                    new_itsm_comments=new_itsm_ticket_comments,
                )

        except Exception as e:
            raise SyncCommentError(
                'Failed tp sync comments between case '
                f'{case_id} and ticket {itsm_ticket_id}'
            ) from e

    def _send_soar_comments_to_itsm(
            self,
            manager: Manager,
            new_soar_comments: Iterable[str],
            ticket_id: str,
            soar_comment_prefix: str = SOAR_COMMENT_PREFIX,
    ) -> None:
        """Add comments to ITSM ticket

        Args:
            manager: The ITSM integration's manager
            new_soar_comments: Case comments to add to the ticket
            ticket_id: The ticket ID
            soar_comment_prefix:
                Prefix for comments. Defaults to SOAR_COMMENT_PREFIX.
        """
        for comment in new_soar_comments:
            try:
                prefixed_comment = f'{soar_comment_prefix}{comment}'
                self._add_comment_to_ticket(
                    manager=manager,
                    comment=prefixed_comment,
                    ticket_id=ticket_id,
                )

            except Exception as e:
                self.logger.error(
                    f'Failed to add comment to ITSM ticket No. {ticket_id}'
                )
                self.logger.exception(e)

    def _send_itsm_comments_to_soar(
            self,
            case_id: str,
            new_itsm_comments: Iterable[str],
    ) -> None:
        """Add comments to case

        Args:
            case_id: The ID for the case to add comments to
            new_itsm_comments: The comments to add
        """
        for comment in new_itsm_comments:
            try:
                comment_with_prefix = f'{self.itsm_comment_prefix}{comment}'
                self.soar_job.add_comment(
                    comment=comment_with_prefix,
                    case_id=case_id,
                    alert_identifier=None,
                )

            except Exception as e:
                self.logger.error(
                    f'Failed to add comment to case {case_id}, Reason: {e}'
                )
                self.logger.exception(e)

    def _check_and_send_slo_warning(
            self,
            manager: Manager,
            case_details: CaseDetails,
            itsm_ticket_id: str,
            itsm_comments: list[str]
    ) -> None:
        """Check if an SLO message should be sent, and send it if needed

        Args:
            manager: The integration's manager
            case_details: The current case overview details object
            itsm_ticket_id: The case's correlating ticket
            itsm_comments: List of all comments from ticket itsm_ticket_id
        """
        if case_details.stage_sla.sla_expiration_time is not None:
            self.logger.info(
                'Found SLO for the current case. '
                'Checking whether a time based warning should be sent'
            )
            slo_comment = create_slo_message(
                slo=case_details.stage_sla.sla_expiration_time,
                interval_days=CASE_SLO_DAYS_INTERVALS,
                existing_comments=remove_prefix_from_comments(
                    comments=itsm_comments,
                    prefix=SOAR_COMMENT_PREFIX,
                ),
            )

            if slo_comment is not None:
                self.logger.info(
                    'A warning about the SLO is added to the case.\n'
                    f'Comment "{slo_comment}"'
                )
                self._send_soar_comments_to_itsm(
                    manager=manager,
                    ticket_id=itsm_ticket_id,
                    new_soar_comments=[slo_comment],
                )

            else:
                self.logger.info(
                    'No new SLO warning should be added to the case'
                )

    def _update_ext_info(
            self,
            original_ext_scc_info_copy: ExternalSCCTicketInfo,
            updated_ext_scc_ticket_info: ExternalSCCTicketInfo,
    ) -> None:
        """Update case context if there's new updated data to update

        Args:
            original_ext_scc_info_copy: The original context
            updated_ext_scc_ticket_info: The updated context
        """
        if original_ext_scc_info_copy != updated_ext_scc_ticket_info:
            self.logger.info(
                'Found data to update in external info. '
                'Setting case context property with updated data'
            )
            ext_json_str = json.dumps(
                updated_ext_scc_ticket_info.to_full_json()
            )
            self._set_case_context_property(
                case_id=updated_ext_scc_ticket_info.case.external_uid,
                property_key=EXTERNAL_SCC_TICKET_INFO,
                property_value=ext_json_str,
            )

        else:
            self.logger.info(
                'No SCC relevant data was changed in neither the case '
                'and ticket'
            )

    @staticmethod
    def _parse_case_details_for_scc(
            case: CaseDetails,
            current_ext_scc_case_info: SOARCaseDetailsForSCC,
    ) -> SOARCaseDetailsForSCC:
        """Parse a new external info case object to update the current data

        Args:
            case: All case details that the ext data will be updated from
            current_ext_scc_case_info:
                The current case ext data to take values that shouldn't change

        Returns:
            A new SOARCaseDetailsForSCC object to update the ext scc data with
        """
        mod_time = case.modification_time_unix_time_ms // NUM_OF_MILLI_IN_SEC
        sla = case.stage_sla.sla_expiration_time // NUM_OF_MILLI_IN_SEC
        return SOARCaseDetailsForSCC(
            sync_case=current_ext_scc_case_info.sync_case,
            name=current_ext_scc_case_info.name,  # No updating ext system name
            assignees=case.assigned_user,
            external_uid=str(case.id_),
            status=case.status.value,
            external_system_update_time=mod_time,
            case_uri='NO CASE URL',  # FIXME: Get case URL
            case_sla=sla,
            case_priority=str(case.priority),
        )

    @staticmethod
    def _parse_case_context(case_context_property_json: str | dict):
        if isinstance(case_context_property_json, str):
            try:
                return json.loads(
                    case_context_property_json
                )
            except json.JSONDecodeError as e:
                raise InternalJSONDecoderError(
                    f'Failed to parse {EXTERNAL_SCC_TICKET_INFO} as '
                    'a JSON'
                ) from e

        if isinstance(case_context_property_json, (dict, list)):
            return case_context_property_json

        raise GeneralJobException(
            f'{EXTERNAL_SCC_TICKET_INFO} has invalid type: '
            f'{type(case_context_property_json)}'
        )
