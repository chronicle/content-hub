from __future__ import annotations

from collections import namedtuple
import dataclasses

from ...transformation import rename_dict_key
from ...types import SingleJson


CaseIterationSetup = namedtuple(
    'CaseIterationSetup',
    ['case_ids', 'ticket_id_to_ticket_details', 'ticket_id_to_ticket_comments']
)

TicketIterationSetup = namedtuple(
    'CaseIterationSetup',
    [
        'ticket_id_to_case_id',
        'ticket_id_to_details',
        'ticket_id_to_comments',
    ]
)

CaseIterationResult = namedtuple(
    'CaseIterationResult',
    ['closed_cases', 'added_cases']
)


class SOARCaseDetailsForSCC:
    """SOAR case data that is saved to support SCC <-> ITSM sync jobs

    Attributes:
        name:
            The case name
            "organizations/123/sources/456/findings/123456/externalSystems/jira"
        assignees: The ticket assignee
        external_uid: Chronicle case uid
        status: Chronicle case status
        external_system_update_time: Chronicle case update time
        case_uri: Chronicle case url
        case_sla: Chronicle case SLA
        case_priority: Chronicle case priority
    """

    def __init__(
            self,
            name: str,
            assignees: str,
            external_uid: str,
            status: str,
            external_system_update_time: int,
            case_uri: str,
            case_priority: str,
            case_sla: int,
            sync_case: bool = True,
            **additional_keys,
    ) -> None:
        self.name = name
        self.assignees = assignees
        self.external_uid = external_uid
        self.status = status
        self.external_system_update_time = external_system_update_time
        self.case_uri = case_uri
        self.case_priority = case_priority
        self.case_sla = case_sla
        self.sync_case = sync_case
        self.additional_keys = additional_keys

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, SOARCaseDetailsForSCC):
            return False

        return (
                self.name == other.name and
                self.assignees == other.assignees and
                self.external_uid == other.external_uid and
                self.status == other.status and
                self.external_system_update_time == (
                    other.external_system_update_time
                ) and
                self.case_uri == other.case_uri and
                self.case_priority == other.case_priority and
                self.case_sla == other.case_sla and
                self.sync_case == other.sync_case and
                self.additional_keys == other.additional_keys
        )


class ITSMTicketDetailsForSCC:
    """ITSM ticket data that is saved to support SCC <-> ITSM sync jobs

    Attributes:
        id: ITSM ticket id
        assignee: The ticket assignee
        description: ITSM ticket description
        uri: ITSM ticket url
        status: ITSM ticket status
        update_time: ITSM ticket update time
    """

    def __init__(
            self,
            id_: str,
            assignee: str,
            description: str,
            uri: str,
            status: str,
            update_time: int,
            **additional_keys,
    ) -> None:
        self.id_ = id_
        self.assignee = assignee
        self.description = description
        self.uri = uri
        self.status = status
        self.update_time = update_time
        self.additional_keys = additional_keys

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ITSMTicketDetailsForSCC):
            return False

        return (
                self.id_ == other.id_ and
                self.assignee == other.assignee and
                self.description == other.description and
                self.uri == other.uri and
                self.status == other.status and
                self.update_time == other.update_time and
                self.additional_keys == other.additional_keys
        )


@dataclasses.dataclass
class ExternalSCCTicketInfo:
    """External data structure that is saved to support SCC <-> ITSM sync jobs

    This can be composed of SOARCaseDetailsForSCC and ITSMTicketDetailsForSCC.

    Attributes:
        case: A SOARCaseDetailsForSCC object
        ticket: A ITSMTicketDetailsForSCC

    Methods:
        from_json:
            A second constructor that builds the object from the SCC
            JSON context data
        to_json: Transform the object to the specific SCC JSON format
        update_by_case_details:
            Update the object's fields based on a SOARCaseDetailsForSCC object
        update_by_ticket_details:
            Update the object's fields based on an ITSMTicketDetailsForSCC
            object
    """
    case: SOARCaseDetailsForSCC
    ticket: ITSMTicketDetailsForSCC

    @classmethod
    def from_json(cls, scc_json: SingleJson) -> ExternalSCCTicketInfo:
        """Create an ExternalSCCTicketInfo object from an SCC external info JSON

        Args:
            scc_json: The JSON to build the object from

        Returns:
            A new ExternalSCCTicketInfo object
        """
        case_json = scc_json['case']
        case = SOARCaseDetailsForSCC(**case_json)

        ticket_json = scc_json['ticket']
        rename_dict_key(ticket_json, 'id', 'id_')
        ticket = ITSMTicketDetailsForSCC(**ticket_json)

        return cls(case, ticket)

    @classmethod
    def from_obj(
            cls,
            ext_scc_info: ExternalSCCTicketInfo
    ) -> ExternalSCCTicketInfo:
        return cls(case=ext_scc_info.case, ticket=ext_scc_info.ticket)

    def update_by_case_details(
            self,
            soar_case_details: SOARCaseDetailsForSCC,
    ) -> None:
        """Update the object based on fields from a SOARCaseDetailsForSCC object

        Args:
            soar_case_details: The SOARCaseDetailsForSCC object
        """
        self.case = soar_case_details

    def update_by_ticket_details(
            self,
            itsm_ticket_details: ITSMTicketDetailsForSCC,
    ) -> None:
        """Update the object based on fields from a ITSMTicketDetailsForSCC
            object

        Args:
            itsm_ticket_details: The ITSMTicketDetailsForSCC object
        """
        self.ticket = itsm_ticket_details

    def to_full_json(self) -> SingleJson:
        """Return the object as a JSON format SCC expects

        Returns:
            The object as an SCC External Info JSON
        """
        full_json = {
            'case': dict(vars(self.case)),
            'ticket': dict(vars(self.ticket)),
        }
        rename_dict_key(full_json['ticket'], 'id_', 'id')

        full_json['case'].pop('additional_keys', None)
        full_json['ticket'].pop('additional_keys', None)

        full_json['case'].update(**self.case.additional_keys)
        full_json['ticket'].update(**self.ticket.additional_keys)

        return full_json

    def to_scc_case_json(self) -> SingleJson:
        return {
            'name': self.case.name,
            'assignees': self.case.assignees,
            'external_uid': self.case.external_uid,
            'status': self.case.status,
            'external_system_update_time':
                self.case.external_system_update_time,
            'case_uri': self.case.case_uri,
            'case_sla': self.case.case_priority,
            'case_priority ': self.case.case_sla,
        }

    def to_scc_ticket_json(self) -> SingleJson:
        return {
            'id': self.ticket.id_,
            'assignee': self.ticket.assignee,
            'description': self.ticket.description,
            'uri': self.ticket.uri,
            'status': self.ticket.status,
            'update_time': self.ticket.update_time,
        }
