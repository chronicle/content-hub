from __future__ import annotations

import dataclasses

from TIPCommon.types import SingleJson

from ..data_models import CaseDataStatus


@dataclasses.dataclass(frozen=True)
class CaseDetails:
    id_: int
    creation_time_unix_time_ms: int
    modification_time_unix_time_ms: int
    name: str
    priority: int
    is_important: bool
    is_incident: bool
    start_time_unix_time_ms: int
    end_time_unix_time_ms: int
    assigned_user: str
    description: str | None
    is_test_case: bool
    type_: int
    stage: str
    environment: str
    status: CaseDataStatus
    incident_id: int | None
    tags: list[str]
    alerts: list[AlertCard]
    is_overflow_case: bool
    is_manual_case: bool
    sla_expiration_unix_time: int | None
    sla_critical_expiration_unix_time: int | None
    stage_sla_expiration_unix_time_ms: int | None
    stage_sla__critical_expiration_unix_time_in_ms: int | None
    can_open_incident: bool
    sla: SLA
    stage_sla: SLA

    @classmethod
    def from_json(cls, case_details_json: SingleJson) -> CaseDetails:
        return cls(
            id_=case_details_json['id'],
            creation_time_unix_time_ms=(
                case_details_json['creationTimeUnixTimeInMs']
            ),
            modification_time_unix_time_ms=(
                case_details_json['modificationTimeUnixTimeInMs']
            ),
            name=case_details_json['name'],
            priority=case_details_json['priority'],
            is_important=case_details_json['isImportant'],
            is_incident=case_details_json['isIncident'],
            start_time_unix_time_ms=case_details_json['startTimeUnixTimeInMs'],
            end_time_unix_time_ms=case_details_json['endTimeUnixTimeInMs'],
            assigned_user=case_details_json['assignedUser'],
            description=case_details_json['description'],
            is_test_case=case_details_json['isTestCase'],
            type_=case_details_json['type'],
            stage=case_details_json['stage'],
            environment=case_details_json['environment'],
            status=CaseDataStatus(case_details_json['status']),
            incident_id=case_details_json['incidentId'],
            tags=case_details_json['tags'],
            alerts=[
                AlertCard.from_json(alert_card_json)
                for alert_card_json in case_details_json['alertCards']
            ],
            is_overflow_case=case_details_json['isOverflowCase'],
            is_manual_case=case_details_json['isManualCase'],
            sla_expiration_unix_time=case_details_json['slaExpirationUnixTime'],
            sla_critical_expiration_unix_time=(
                case_details_json['slaCriticalExpirationUnixTime']
            ),
            stage_sla_expiration_unix_time_ms=(
                case_details_json['stageSlaExpirationUnixTimeInMs']
            ),
            stage_sla__critical_expiration_unix_time_in_ms=(
                case_details_json['stageSlaCriticalExpirationUnixTimeInMs']
            ),
            can_open_incident=case_details_json['canOpenIncident'],
            sla=SLA.from_json(case_details_json['sla']),
            stage_sla=SLA.from_json(case_details_json['stageSla']),
        )


@dataclasses.dataclass(frozen=True)
class AlertCard:
    id_: int
    creation_time_unix_time_ms: int
    modification_time_unix_time_ms: int
    identifier: str
    status: int
    name: str
    priority: int
    workflow_status: int
    sla_expiration_unix_time: int | None
    sla_critical_expiration_unix_time: int | None
    start_time: int
    end_time: int
    alert_group_identifier: str
    events_count: int
    title: str
    rule_generator: str
    device_product: str
    playbook_attached: str | None
    playbook_run_count: int
    is_manual_alert: bool
    sla: SLA
    fields_groups: list[FieldsGroup]
    source_url: str | None
    source_rule_url: str | None
    siem_alert_id: str | None

    @classmethod
    def from_json(cls, alert_card_json: SingleJson) -> AlertCard:
        return cls(
            id_=alert_card_json['id'],
            creation_time_unix_time_ms=(
                alert_card_json['creationTimeUnixTimeInMs']
            ),
            modification_time_unix_time_ms=(
                alert_card_json['modificationTimeUnixTimeInMs']
            ),
            identifier=alert_card_json['identifier'],
            status=alert_card_json['status'],
            name=alert_card_json['name'],
            priority=alert_card_json['priority'],
            workflow_status=alert_card_json['workflowsStatus'],
            sla_expiration_unix_time=alert_card_json['slaExpirationUnixTime'],
            sla_critical_expiration_unix_time=(
                alert_card_json['slaCriticalExpirationUnixTime']
            ),
            start_time=alert_card_json['startTime'],
            end_time=alert_card_json['endTime'],
            alert_group_identifier=alert_card_json['alertGroupIdentifier'],
            events_count=alert_card_json['eventsCount'],
            title=alert_card_json['title'],
            rule_generator=alert_card_json['ruleGenerator'],
            device_product=alert_card_json['deviceProduct'],
            playbook_attached=alert_card_json['playbookAttached'],
            playbook_run_count=alert_card_json['playbookAttached'],
            is_manual_alert=alert_card_json['isManualAlert'],
            sla=SLA.from_json(alert_card_json['sla']),
            fields_groups=[
                FieldsGroup.from_json(field_group_json)
                for field_group_json in alert_card_json['fieldsGroups']
            ],
            source_url=alert_card_json['sourceUrl'],
            source_rule_url=alert_card_json['sourceRuleUrl'],
            siem_alert_id=alert_card_json['siemAlertId'],
        )


@dataclasses.dataclass(frozen=True)
class FieldsGroup:
    order: int
    group_name: str
    is_integration: bool
    is_highlight: bool
    items: list[FieldGroupItem]

    @classmethod
    def from_json(cls, field_group_json: SingleJson) -> FieldsGroup:
        return cls(
            order=field_group_json['order'],
            group_name=field_group_json['groupName'],
            is_integration=field_group_json['isIntegration'],
            is_highlight=field_group_json['isHighlight'],
            items=[
                FieldGroupItem.from_json(item_json)
                for item_json in field_group_json['items']
            ],
        )


@dataclasses.dataclass(frozen=True)
class FieldGroupItem:
    original_name: str
    name: str
    value: str

    @classmethod
    def from_json(cls, field_group_json: SingleJson) -> FieldGroupItem:
        return cls(
            original_name=field_group_json['originalName'],
            name=field_group_json['name'],
            value=field_group_json['value'],
        )


@dataclasses.dataclass(frozen=True)
class SLA:
    sla_expiration_time: int | None
    critical_expiration_time: int | None
    expiration_status: int
    remaining_time_since_last_pause: int | None

    @classmethod
    def from_json(cls, sla_json: SingleJson) -> SLA:
        return cls(
            sla_expiration_time=sla_json.get('slaExpirationTime', -1),
            critical_expiration_time=sla_json.get('criticalExpirationTime', -1),
            expiration_status=sla_json.get('expirationStatus', -1),
            remaining_time_since_last_pause=sla_json.get(
                'remainingTimeSinceLastPause',
                -1
            ),
        )
