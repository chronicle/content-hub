import json

from requests import HTTPError, Response

from ..data_models import AlertEvent, CaseDetails
from ..exceptions import InternalJSONDecoderError
from ..types import ChronicleSOAR, SingleJson
from ..utils import is_python_37

if is_python_37():
    from urllib.parse import urljoin
else:
    from urlparse import urljoin


def validate_response(response, validate_json=False):
    # type: (Response, bool) -> None
    """Validate response and get it as a JSON

    Args:
        response (requests.Response): The response to validate

    Raises:
        HTTPError: If the response status code is pointing on some failure
    """
    try:
        response.raise_for_status()

        if validate_json:
            response.json()

    except HTTPError as he:
        raise HTTPError('An error happened while requesting API, {}'.format(he))

    except json.JSONDecodeError as je:
        raise InternalJSONDecoderError(
            'Failed to parse response as JSON.\nError: {0}\nRaw response: {1}'
            .format(je, response.text)
        )



##### GET #####
def get_case_overview_details(chronicle_soar, case_id):
    # type: (ChronicleSOAR, int | str) -> CaseDetails
    """Get case overview details by case ID

    Args:
        chronicle_soar (ChronicleSOAR): A chronicle soar SDK object
        case_id (int | str) The case id to fetch its overview data

    Returns:
        (CaseDetails): The case details object

    Raises:
        requests.HTTPError: If failed to request or request status is not 200
        json.JSONDecoderError: If parsing the the response fails
    """
    endpoint = 'api/external/v1/dynamic-cases/GetCaseDetails/{}'.format(case_id)
    url = urljoin(chronicle_soar.API_ROOT, endpoint)

    chronicle_soar.LOGGER.info(
        'Calling endpoint {} to get case overview details'.format(endpoint)
    )

    response = chronicle_soar.session.get(url=url)
    validate_response(response, validate_json=True)

    return CaseDetails.from_json(response.json())


def get_installed_jobs(chronicle_soar):
    # type: (ChronicleSOAR) -> list[SingleJson]
    """Retrieve a list of environment action definition files.

    Args:
        chronicle_soar (ChronicleSOAR): A chronicle soar SDK object

    Returns:
        (list[SingleJson]): A list of `SingleJson` objects representing
        the action definition files.

    Raises:
        requests.HTTPError:
        json.JSONDecodeError:
    """
    endpoint = 'api/external/v1/jobs/GetInstalledJobs'
    url = urljoin(chronicle_soar.API_ROOT, endpoint)

    chronicle_soar.LOGGER.info(
        f'Calling endpoint "{endpoint}" to get all job installed instances'
    )
    response = chronicle_soar.session.get(url)
    validate_response(response, validate_json=True)

    return response.json()


##### POST #####
def get_alert_events(chronicle_soar, case_id, alert_identifier):
    # type: (ChronicleSOAR, str | int, str) -> list[AlertEvent]
    """Get specific alert's events

    Args:
        chronicle_soar (ChronicleSOAR): _description_
        case_id (str | int): Case ID. Example: 13, "41"
        alert_identifier (str):
            The alert's identifier (='{alert.name}_{alert.id}'). Example:
            alert.name=SERVICE_ACCOUNT_USED
            alert.id=c3b80f09-38d3-4328-bddb-b938ccee0256
            identifier=SERVICE_ACCOUNT_USED_c3b80f09-38d3-4328-bddb-b938ccee0256

    Returns:
        list[SingleJson]: The request's response JSON. A list of events' JSONs

    Raises:
        requests.HTTPError: If server returns a non-success status code
        json.JSONDecodeError: If the returned value is not a valid JSON
    """
    endpoint = 'api/external/v1/dynamic-cases/GetAlertEvents'
    url = urljoin(chronicle_soar.API_ROOT, endpoint)
    payload = {
        'caseId': case_id,
        'alertIdentifier': alert_identifier,
    }

    chronicle_soar.LOGGER.info(
        'Calling endpoint {} to user profile cards'.format(endpoint)
    )
    response = chronicle_soar.session.post(url, json=payload)
    validate_response(response)

    return [AlertEvent.from_json(event) for event in response.json()]


def get_env_action_def_files(chronicle_soar):
    # type: (ChronicleSOAR) -> list[SingleJson]
    """Retrieve a list of environment action definition files.

    Args:
        chronicle_soar (ChronicleSOAR): A chronicle soar SDK object

    Returns:
        (list[SingleJson]): A list of `SingleJson` objects representing
        the action definition files.

    Raises:
        requests.HTTPError:
        json.JSONDecodeError:
    """
    endpoint = 'external/v1/settings/GetEnvironmentActionDefinitions'
    url = urljoin(chronicle_soar.API_ROOT, endpoint)
    payload = [chronicle_soar.environment]

    chronicle_soar.LOGGER.info(
        'Calling endpoint {} to get all actions def files'.format(endpoint)
    )
    response = chronicle_soar.session.post(url, json=payload)
    validate_response(response, validate_json=True)

    return response.json()


def get_integration_full_details(chronicle_soar, integration_identifier):
    # type: (ChronicleSOAR, str) -> SingleJson
    """Retrieves the full-details file of the integration.

    Args:
        chronicle_soar (ChronicleSOAR): A chronicle soar SDK object
        integration_identifier (str): The integration's ID (e.g. VirusTotalV3)


    Returns:
        (SingleJSON): The response JSON containing the full details of the
        integration.

    Raises:
        requests.HTTPError:
        json.JSONDecodeError:
    """
    # FIXME: Might not work on custom integrations
    endpoint = 'external/v1/store/GetIntegrationFullDetails'
    url = urljoin(chronicle_soar.API_ROOT, endpoint)
    payload = {
        "integrationIdentifier": integration_identifier
    }

    chronicle_soar.LOGGER.info(
        'Calling endpoint {} to get the integration '.format(endpoint) +
        'configuration parameters'
    )
    response = chronicle_soar.session.post(url, json=payload)
    validate_response(response, validate_json=True)

    return response.json()
