from typing import Any, Callable, Dict, List, TypeVar, Union

from SiemplifyAction import SiemplifyAction
from SiemplifyConnectors import SiemplifyConnectorExecution
from SiemplifyJob import SiemplifyJob
from SiemplifyDataModel import DomainEntityInfo

ChronicleSOAR = Union[
    SiemplifyAction,
    SiemplifyConnectorExecution,
    SiemplifyJob
]

Entity = DomainEntityInfo

SingleJson = Dict[str, Any]

JSON = Union[SingleJson, List[SingleJson]]

GeneralFunction = Callable[..., Any]
ApiManager = TypeVar('ApiManager')
